import Init
namespace MathScope.M4.ClosureInjected
axiom freshUserAxiom : (0 : Nat) = 1
theorem dependentTheorem : (0 : Nat) = 1 := freshUserAxiom
end MathScope.M4.ClosureInjected

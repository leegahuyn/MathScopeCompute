import MathScope.M4.FiniteAcceptance
open MathScope.M4.FiniteAcceptance
example : (deltaNumerator 3 3 % 16) / 2 = deltaTwo 3 3 % 16 := by decide

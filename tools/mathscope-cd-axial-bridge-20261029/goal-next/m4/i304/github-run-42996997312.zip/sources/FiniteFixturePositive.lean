import MathScope.M4.FiniteAcceptance
open MathScope.M4 MathScope.M4.FiniteAcceptance
example : deltaTwo 3 (-3) = -9 := by decide
example : (deltaNumerator 3 3 % 32) / 2 = 9 := by decide
example : primeTrial 29 = true := by decide

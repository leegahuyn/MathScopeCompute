from hashlib import sha256
from pathlib import Path
from gzip import open as gzip_open
import json
import sys


def main():
    bundle, narrow, output = map(Path, sys.argv[1:])
    original = (bundle/"original-active-mode-two-witness.json").read_bytes()
    assert sha256(original).hexdigest()=="a35bd111ef2f60b0e779a85433571db8caa00061616da91372782a28a16859e9"
    witness=json.loads(original)
    archived=narrow.read_bytes()
    assert sha256(archived).hexdigest()=="710b6373a53bd87b5a23fd5ae10c22425b22b5c59847f7c124ab495b1bf10397"
    selected = json.loads(archived)
    intervals=[(0,3710),(17726800,17789100),(21380000,21475000),(21660000,21680000)]
    data={}
    h=sha256()
    with gzip_open(bundle/"original-source-nodes.jsonl.gz","rb") as file:
        first=file.readline()
        h.update(first)
        assert json.loads(first)["node_count"] == 21681493
        cursor=0
        for i,line in enumerate(file):
            h.update(line)
            while cursor<len(intervals) and i>intervals[cursor][1]:
                cursor+=1
            if cursor<len(intervals) and intervals[cursor][0]<=i:
                data[i]=json.loads(line)
    assert i+1==21681493
    assert h.hexdigest()==witness["snapshot"]["node_stream_sha256"]
    assert all(data.get(int(i),row)==row for i,row in selected["nodes"].items())
    selected["nodes"].update({str(i):row for i,row in data.items()})
    with output.open("x",encoding="utf-8",newline="\n") as file:
        json.dump(selected,file,separators=(",",":"))
        file.write("\n")


if __name__=="__main__":
    main()

from functools import cache
from hashlib import sha256
from pathlib import Path
import json
import sys


def fingerprints(nodes, mapping, floor, *, associative=True):
    lookup=nodes.get
    def apply(label, operands):
        vals=list(operands)
        if associative and label in {"add","multiply"}:
            ungrouped=[]
            for val in vals:
                if val[0]==label:
                    ungrouped.extend(val[1])
                else:
                    ungrouped.append(val)
            vals=sorted(ungrouped)
        return label,tuple(vals)
    def tag(label,arg):
        return label,tuple(arg)
    @cache
    def expression(i):
        if i in mapping:
            return rhs(mapping[i])
        if i<floor:
            return "prefix", (i,)
        nd=lookup(str(i))
        if not nd:
            raise ValueError(f"Unretained original operand {i}")
        op,a=nd["op"],nd["args"]
        if op in {"coordinate","rational","source_parameter"}:
            return tag(op,(*a,i) if op=="coordinate" else a)
        if op in {"add","multiply","inverse","exp","sqrt_positive","log_positive","ceiling","floor","smooth_piecewise","minimum","maximum","sine","cosine"}:
            return apply(op,(expression(x) for x in a))
        if op=="integer_power":
            return tag(op,(expression(a[0]),a[1]))
        if op=="actual_expression_partial":
            return tag(op,(a[0],tuple(expression(x) for x in a[1]),tuple(a[2])))
        if op=="actual_monotone_root":
            return tag(op,(a[0],*(expression(x) for x in a[1:])))
        raise ValueError(f"Unrecognized original operand {i} {op}")
    if mapping:
        rhs=fingerprints(nodes,{},floor,associative=associative)
    return expression


def main():
    wide, original, output=map(Path,sys.argv[1:])
    raw=wide.read_bytes()
    assert sha256(raw).hexdigest()=="f19b4b31e06faee4a554be55ccf27a7d93dc4c21b6ab990b4d70ab535b27d821"
    rec=json.loads(raw)
    assert rec["graphSHA256"]=="831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a"
    assert rec["registrySHA256"]=="364425db9d5bbd317f8aaad681fdfdd3206f97e0f46d2beb78b6e7d5a30a3111" 
    nodes=rec["nodes"]
    old_raw=original.read_bytes()
    assert sha256(old_raw).hexdigest()=="54604d663ca3dddbE8b0f7df95610bf4a187914cb5e6b10c0d5e6b96d90f9c98".lower()
    old=json.loads(old_raw)
    checks=[]
    for forced, archived, registered in zip(rec["rowInputs"],old["native"],rec["forced"],strict=True):
        assert forced["system"]==archived["system"]==registered["id"]
        assert archived["matrix"]==registered["matrix"]
        assert registered["left"]==0 and all(set(x.values())=={0} for x in registered["initial"])
        assert registered["finitePartialSumIsExactSolution"] is False
        assert registered["variable"]==forced["path"]["w"]
        assert registered["length"]==forced["length"]
        assert registered["directions"][:3]==[17732748,17732749,17732750]
        assert forced["key"]==archived["key"]
        mapping={int(i):j for i,j in archived["normalFrameFormalActual"].items()}
        assert sorted(mapping)==[17732751,17732753,17732754,17732755]
        assert mapping[17732751]==forced["path"]["w"]
        assert [mapping[i] for i in sorted(mapping)[1:]]==[rec["representative"][x] for x in ("X","eta","s")]
        floor=min(mapping)
        formal_fp=fingerprints(nodes,mapping,floor)
        actual_fp=fingerprints(nodes,{},floor)
        groups={
          "normal":([17733136,17733138,17733142],forced["normal"]["value"]),
          "normalDerivative":([17733143,0,17733145],forced["normal"]["derivative"]),
          "normalSquared":([17733150],[forced["normal"]["squared"]]),
          "K":([0,17733152,0,17733154,0,0,17733121,0,0],[i for row in forced["K"] for i in row]),
          "carrierAndScale":([17732747,17732744,17733029],[forced["k"],forced["epsilon"],forced["length"]]),
          "Fc":([17733113,17733103],[17735984,17735992]),
        }
        proof={key:[] for key in groups}
        for key,(formals,actuals) in groups.items():
            for a,b in zip(formals,actuals,strict=True):
                status=False
                try:
                    status=formal_fp(a)==actual_fp(b)
                    if not status:
                        print("UNMATCHED",forced["key"],key,a,b,flush=True)
                except ValueError as error:
                    print("UNRETAINED",forced["key"],key,a,b,error,flush=True)
                proof[key].append({"formal":a,"actual":b,"identity":status})
        wrong_rep=dict(mapping)
        wrong_rep[17732754]=mapping[17732753]
        wrong_pulse=dict(mapping)
        wrong_pulse[17732751]=rec["rowInputs"][1 if forced["key"]=="0:1" else 0]["path"]["w"]
        tests={
          "wrongFrozenEtaRejected": fingerprints(nodes,wrong_rep,floor)(17733113)!=actual_fp(17735984),
          "otherPulseVariableRejected": fingerprints(nodes,wrong_pulse,floor)(17733136)!=actual_fp(forced["normal"]["value"][0]),
          "wrongDerivativeComponentRejected": formal_fp(17733143)!=actual_fp(forced["normal"]["derivative"][2]),
        }
        assert all(tests.values())
        checks.append({"key":forced["key"],"system":forced["system"],"mapping":mapping,"checks":proof,
          "negativeControls":tests,"registeredMatrix":registered["matrix"],"registeredForcing":registered["forcing"],
          "originalZeroData":True,"unchangedSlowDirections":registered["directions"][:3]})
    passed = all(row["identity"] for pair in checks for g in pair["checks"].values() for row in g)
    assert passed
    result={"schema":"MathScope.N7.ArchivedModeTwoFrameSubstitution/1","graph":rec["graphSHA256"],
      "regionSHA256":sha256(raw).hexdigest(),"previousFrameSHA256":sha256(old_raw).hexdigest(),
      "checked":checks,"passed":passed,
      "identityRule":"Exact simultaneous representative/pulse replacement, literal binder IDs and orders, and associative/commutative normalization of sums and products."}
    with output.open("x",encoding="utf-8",newline="\n") as file:
        json.dump(result,file,indent=2)
        file.write("\n")
    print("frame substitution closure",passed,flush=True)


if __name__=="__main__":
    main()

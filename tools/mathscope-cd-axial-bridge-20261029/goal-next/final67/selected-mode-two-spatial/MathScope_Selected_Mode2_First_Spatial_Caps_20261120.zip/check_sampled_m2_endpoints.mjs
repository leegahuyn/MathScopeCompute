import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const [goalArg,workArg,output]=process.argv.slice(2);
assert.equal(process.argv.length,5);
const goal=resolve(goalArg),work=resolve(workArg);
const modes=resolve(goal,'primary-forced-join/active-n3-c5-binding');
const sha=b=>createHash('sha256').update(b).digest('hex');
const pins={};
async function load(label,path,pin){
  const bytes=await readFile(path);
  assert.equal(sha(bytes),pin,label);
  pins[label]=pin;
  return JSON.parse(bytes);
}
const projected=await load('projectedModeTwo',resolve(modes,'n3-mode-two-degrees-pulled.json'),
  'adcabe6055fed4483e3052101e3f8fa4cf8422f9a603a44809b33c9bb923c0d1');
const inverse=await load('activeInverse',resolve(modes,'active-inverse/n3-active-inverse-degrees.json'),
  '09b98add880b6a7dbc13a6854f1234f79c7a26f38ce89b6080219b7d446d90fa');
const endpoints=await load('sameFamilyEndpoint',resolve(modes,'endpoint/n3-same-family-active-endpoint.json'),
  '5abe63bc103e29e14694528d5bac4733b84f217344679ddfdff0b65727e18d85');
const coefficient=await load('physicalModeTwoTransport',resolve(modes,'endpoint/time-phase/n3-time-carrier-and-physical.json'),
  'ed1773d48e36dcc629f93d5b54fc77cd85ff123d24cb6de50b0e85dfe4d5efc2');
const radial=await load('annularPole',resolve(modes,'endpoint/annular-bound/annular-absorption-complete.json'),
  'd59485b9b27d40fe620e06e2e361a36e999f46bdd5d4d9ad6f0c3574765c2502');
const frames=await load('archivedFrame',resolve(modes,'endpoint/annular-bound/archived-frame-substitution-cached.json'),
  '54604d663ca3dddbE8b0f7df95610bf4a187914cb5e6b10c0d5e6b96d90f9c98'.toLowerCase());
const closure=await load('archivedFrameSubstitution',resolve(dirname(fileURLToPath(import.meta.url)),'frame-closure-final.json'),
  'a86370d462bbe9944aba78c0d61b8a8df2a3d9ae4b9b4ab3a0aae2987be0dfb2');
const operator=await load('localOperator',resolve(work,'continuation64/forced-local/local-forced-cost-final.json'),
  'e73562668961cf16705f59f2e4dd9fc4269d1b5bec5de958f9d6fc4307972fac');
const frozen=await load('frozenC8',resolve(work,'continuation63/frozen-n4/final/frozen-n4-bridge.json'),
  '4459d1098e5e44b09ac395054f031b0cc6130f1c09878ebad1214ddf23fdf410');
const live=await load('liveC8',resolve(work,'continuation61/c8-slab/final/c8-slab.json'),
  'e26c62baf924c4209bbac2ebd944bd17a992bfe4599fd1a8fab2cb8c91d7c02b');
const gate=await load('referenceSpatialCap',resolve(goal,'final67/active-n3-cap-transport/source-cap/cap-transport.json'),
  '387863daedfc9fd37f7c1d43db430235238f94d23b767424baffa5d2f3348955');

assert.equal(inverse.inputSHA256,pins.projectedModeTwo);
assert.equal(coefficient.sourcePins.endpoint,pins.sameFamilyEndpoint);
assert.equal(radial.inputPins.physicalDerivatives,pins.physicalModeTwoTransport);
assert.equal(inverse.sourceK,18310069);
assert.equal(coefficient.normRoots.K,inverse.sourceK);
assert.deepEqual(coefficient.sourceSlots.map(row=>row.key),['0:1','1:1']);
assert.deepEqual(frames.native.map(row=>row.system),[1,5]);
assert.equal(coefficient.activeFrameBoundChecked,false);
assert.equal(inverse.scope.liveFrameBoundChecked,false);
assert.ok(frames.native.every(row=>row.pendingSubexpressionPairs.flat().length>0));
assert.equal(closure.passed,true);
assert.equal(closure.graph,endpoints.graphSHA256);
assert.deepEqual(closure.checked.map(({key,system})=>[key,system]),endpoints.rows.map(({key,system})=>[key,system]));
assert.equal(closure.previousFrameSHA256,pins.archivedFrame);
assert.deepEqual(closure.checked.map(row=>row.system),[1,5]);
assert.ok(closure.checked.every(row=>row.originalZeroData&&Object.values(row.negativeControls).every(Boolean)
  &&Object.values(row.checks).flat().every(check=>check.identity)));
assert.equal(operator.scope.actualStageCapsClosed,0);
assert.ok(frozen.localBackgroundBudget.includes('2^128'));
assert.equal(live.gates.smallGrowth128!==undefined,true);
assert.equal(radial.commonPole,42);
assert.equal(radial.nativeRoots.Bnorm,14220485);

// Keep half of the original radial exponent. The maximum of
// x^42 exp(-t1^2 x^2/2) is (42/e)^21 t1^-42. Use e>8/3.
const capNumerator=(42n*3n)**21n,capDenominator=8n**21n;
assert(capNumerator<((1n<<84n)*capDenominator));
const t1ReciprocalDegree=120,halfPoleDegree=84+t1ReciprocalDegree*42;
assert.equal(halfPoleDegree,5124);
assert(5124<25_600_000);

// Logarithms are budgeted in multiples of H/2^128. C64 supplies
// log(Kloc), log(S) < H/2^128. E=1+3 Lmax*S/r0 <= 37*S < 2^6*S.
// H> Bnorm^511/2 and Bnorm>=2^128 guarantee log 2 < H/2^128.
const rows=[];
for(const [field,group] of [['velocity',['U','G_U']],['potential',['A','G_A']]]){
  for(let j=0;j<=1;j++){
    const row=coefficient.conditionalPhysicalDerivativeRows[field][j];
    assert.equal(row.order,j);
    assert.ok(row.pole<=42);
    const sourceExpUnits=row.epsilonUnits;
    assert.ok(sourceExpUnits>=49999 && sourceExpUnits<200000);
    // Two labels, own-to-reference factor at most 4^2=16,
    // possible rotation onto the requested covariant gradient at most 4,
    // and epsilon^a <= 4*tau0^(h*a) on Qown/tau0<=4.
    const additional=2*16*4*4;
    const constant=BigInt(row.signedPairIntegerFactor)*BigInt(additional);
    const constantPower=(constant-1n).toString(2).length;
    const logCost=2*row.KSExponent+7*row.endpointFactorExponent+1+constantPower;
    assert(logCost<2**18);
    // a - logCost/2^128 > 1/3, using exact integers.
    assert((3n*BigInt(sourceExpUnits)-100000n)*(1n<<128n)>300000n*BigInt(logCost));
    rows.push({field,group:group[j],order:j,sourceExpUnits,originalPole:row.pole,
      KSExponent:row.KSExponent,endpointFactorExponent:row.endpointFactorExponent,
      integerFactor:constant.toString(),integerFactorPower:constantPower,
      logCostUnitsHOver2Pow128:logCost});
  }
}
const module=resolve(goal,'final67/energy-1013-sharp/correction-budget/spatial-gauge/weighted-velocity/evaluate_mean_bulk_energy.mjs');
const {prepareMeanBulkEnergy}=await import(pathToFileURL(module).href);
const historical=resolve(work,'whole-k-prefix/historical-scale-arithmetic-input.json');
const {N,closed,q,hLogTau}=await prepareMeanBulkEnergy(goal,resolve(work,'annular-numeric-24/pinned-original-runtime'),historical,
  resolve(goal,'final67/energy-1013-sharp/correction-budget/spatial-gauge/weighted-velocity/weighted-velocity-coefficients.json'));
const sampleUpper=closed(N.exp(N.mul(q('1/3'),hLogTau)));
const gateClosed=live.gates.normalizedStageOne;
const compare=(a,b)=>N.compareEndpoints(a,b);
const endpointComparison=compare(sampleUpper.upper,gateClosed.lower);
assert.equal(endpointComparison,-1);
assert.equal(compare(sampleUpper.upper,{rational:'1'}),-1);
assert.equal(compare(gateClosed.lower,{rational:'1'}),1);
const result={
  schema:'MathScope.N7.SelectedM2FirstSpatialCapsLocalized/1',sourcePins:pins,
  observedSource:{selectedRows:['0:1','1:1'],systems:[1,5],includedConjugates:true,K:inverse.sourceK,Bnorm:radial.nativeRoots.Bnorm,
    archivedFormalActualFrameVerified:true,archiveGraph:closure.graph},
  quantitativeScope:'Conditional bound for the sum of the two selected original Forced mode-two outputs and their conjugates in the four reference-normalized first spatial groups on their admitted active charts.',
  sameSourcePremises:[
    'Reapply the original positive source primitive and active inverse derivative recurrences to local K, keeping original target, determinant, positivity and cutoff hypotheses. Actual H_w holds R,Z,T fixed and the local supporting charts must be admitted.',
    'The local moving-frame inputs are covered by the original live or frozen bounds and all untouched K operands. Source guard/seam extension and same-reference output binding and fresh-stage transport require their original ownership.',
  ],
  halfPole:{weighted:'delta_*^-42 zeta P(v) <= Bnorm sqrt(zeta) P(v)',
    positiveInnerPower:t1ReciprocalDegree*42,dimensionlessCoefficient:'<2^84',CSelectedPower:halfPoleDegree,
    sourceUpper:'CSelected^5124 < Renv <= Bnorm <= W^8 <= Kloc',commonPole:42},
  geometry:{QownOverTau0:['1/4','4'],QrefOverTau0:['1/2','1'],ownToReferenceFactor:16,
    cylindricalConversionFactor:4,epsilonGainConversionFactor:4,endpointFactorBound:'1+3 Lmax*S/r0 <= 37*S < 2^6*S'},
  rows,
  conditionalNormalizedBound:'Each group and component across these two signed contributions is bounded by exp(-H/3). On any individual contributing branch the corresponding weight sqrt(zeta) P(v) can be retained.',
  strictEndpoint:{sampleUpper,gateLower:gateClosed.lower,comparison:endpointComparison},
  gate:'Stage-one sufficient shared W_cap gate is 2^-28 Xb^-2 exp(H); this independent comparison applies only to the sampled contribution.',
  actual24Closed:0,allForcedClosed:false,signedStressClosed:false,meanCapsClosed:false,N706:'OPEN',N805:'OPEN',finalJets:0,release:'HOLD',
};
await writeFile(output,JSON.stringify(result,null,2)+String.fromCharCode(10),{flag:'wx'});
console.log(JSON.stringify({rows:rows.map(x=>[x.group,x.sourceExpUnits,x.logCostUnitsHOver2Pow128]),endpointComparison}));

"""Check the native P0 and Jz0 Haar projections of the isolated Temporal time path."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json

PINS = {
    'registry': '364425db9d5bbd317f8aaad681fdfdd3206f97e0f46d2beb78b6e7d5a30a3111',
    'directional': '02c7b2d7ea24f43f90444952a03b31eba0a187b0675f765247c931df41ff2001',
    'prehaar': 'a749056e325accfb2582b6814c1e335cfbcdd46ec1bc8fb911c24e4741ae8ccc',
    'source-full-mean-equations.mjs': '2f44315a940fc959f1c86c2a8fd5b1a252521cbb8e2565dc42fc07b139773d76',
    'source-global-current.mjs': '93f86661d67e6bc7b916218cd7af3db72f348ba7fdc876e3618ba3a49edff760',
    'source-global-pressure.mjs': 'fd93001ad4bbc002d329cba54d1c884cc5e7bfd93444b1d72bd9c331a67b966d',
    'source-global-temporal.mjs': 'd5e20e78c119b678b61df35c1bf0f560826e7dddb74e70edd0c17a67d18a9759',
    'source-updated-mean-pressure.mjs': '6ea6cb85cddd54b0421203e8fc37d24bdfcb8d3c6e62f78c5dada3dab8bd0c07',
    'source-global-initial-mean.mjs': '513779930558d044076318f39396060465b6518184b952482a0d973ac16bd411',
    'source-pressure.mjs': 'fcdbbcddc5e16649f771bb53e1b0889ee1641a62dec3440d18611488ce35c66f',
    'source-temporal-potential.mjs': 'c0754a9afc0c41e731488523c030a317e69407e3ec01d2fe9bed8eb2f414a6f8',
}


def check_tokens(sources):
    clauses = {
        'source-full-mean-equations.mjs': [
            'time=x=>G.add(G.neg(G.mul(epsilon,G.derivative(x,T))),G.mul(ci,N(x)))',
            'gr=G.add(G.neg(time(beta))', 'G.mul(beta,gamma),W.rz',
            'fluxZ=G.mul(R,G.add(G.mul(q(2),G0,gamma),G.pow(gamma,2),W.zz))',
        ],
        'source-global-current.mjs': [
            "innerRadius=G.sqrt(G.parameter('Xa')),outerRadius=G.mul(q(2),G.sqrt(band.chart.Xb))",
            'global-radial-envelope-fixed-in-slow-calculus',
        ],
        'source-global-pressure.mjs': [
            'G.neg(Dz(W.rz))', 'whole_global_pressure_Z',
            'G.mul(epsilon,pZ)', 'fixed-reference-radial-primitive',
            'fixed-reference-time-coefficient',
        ],
        'source-global-temporal.mjs': [
            'sourceBodyRoots:{theta:pressure.residual.Etheta,z:pressure.residual.Ez}',
            'original-slow-factors-constant-in-auxiliary-coordinates',
            'exactZeroMode:G.zero', 'finiteSumReplacesExactLimit:false',
            'Every finite inverse sum has zero Haar mean.',
        ],
        'source-updated-mean-pressure.mjs': [
            'return Y.reduce((value,y)=>G.integral(value,y,G.zero,G.one),body)',
            "P=scalar(G,whole(haarGr),tag+'_P')",
            "Jz=scalar(G,G.sub(whole(exactNormalizedHaar(G,raw.fluxZ,Y)),G.mul(G.q(1,2),whole(G.mul(G.pow(R,2),haarGr)))),tag+'_Jz')",
            'G.derivative(innerRadius,Z)', 'G.derivative(outerRadius,Z)',
        ],
        'source-global-initial-mean.mjs': [
            "velocity:temporal.potential.velocity,tag:'GlobalInitializationAfterTemporal'",
            'actualInputDefects={P:afterTemporal.mean.P,Jtheta:afterTemporal.mean.Jtheta,Jz:afterTemporal.mean.Jz}',
        ],
        'source-pressure.mjs': [
            'shift=G.sub(G.substitute(radialPrimitive,R,r),radialPrimitive)',
            'shiftedY=Y.map((y,j)=>G.add(y,G.mul(shift,vr[j])))',
            'left=G.integral(integrand,r,innerRadius,R),whole=G.integral(integrand,r,innerRadius,outerRadius)',
        ],
        'source-temporal-potential.mjs': [
            'gammaDesired=G.neg(G.div(inverseZ,ci)),weighted=G.mul(R,gammaDesired)',
            'rawPsi=G.div(G.sub(integrals.left,G.mul(chi,integrals.whole)),R)',
            'beta=G.neg(Dz(psi)),gamma=De(psi,1)',
            'Normalized Haar translation invariance and Fubini',
        ],
    }
    for source, tokens in clauses.items():
        for token in tokens:
            assert token in sources[source], (source, token)


def read_native(registry, nodes):
    reg = registry['base']
    fns = json.loads(reg['expressionDefinitions'])
    inverses = json.loads(reg['inverseDefinitions'])
    r, z, t, ell, y0, y1 = 17732748, 17732749, 17732750, 17732737, 17745430, 17745431
    full = [ell, r, z, t, y0, y1]
    u = [r,z,t,ell,y0,y1]
    for j, comp, root in [(0,'theta',17754253),(1,'z',17754268)]:
        inv = inverses[j]
        assert inv['name'] == 'GlobalActualTemporal_' + comp and inv['body'] == root
        assert inv['parameters'] == u and inv['Y'] == [y0,y1] and inv['directions'] == [r,z,t,y0,y1]
        assert inv['zeroMode'] == 'The exact normalized Haar mean is projected out.'
    definitions = [
        (-13,19570917,'global_actual_temporal_actual_meridional_potential',full),
        (-14,21374149,'GlobalInitializationAfterTemporal_complete_gr',full),
        (-15,21374485,'GlobalInitializationAfterTemporal_haar_gr',full[:4]),
        (-16,21374489,'GlobalInitializationAfterTemporal_P',[ell,z,t]),
        (-18,21374575,'GlobalInitializationAfterTemporal_Jz',[ell,z,t]),
    ]
    for system, body, name, arguments in definitions:
        record = fns[-1-system]
        assert (record['body'],record['name'],record['parameters']) == (body,name,arguments)

    lo, hi, chi, eps, ci = 17743711,17743713,17743734,17732744,17745449
    def check(node, op, args):
        assert nodes[node] == [op,args], (node,op,args,nodes[node])
    def product(node,*expected):
        pending,result = [node],[]
        while pending:
            at = pending.pop()
            op, args = nodes.get(at, ('opaque', []))
            if op == 'multiply' and at not in expected:
                pending.extend(args)
            else:
                result.append(at)
        assert sorted(result) == sorted(expected), (node,result,expected)

    check(lo,'sqrt_positive',[3617])
    check(17743712,'sqrt_positive',[28826])
    check(hi,'multiply',[24,17743712])
    check(17753400,'m3_aux_indexed_partial',[2,u,[0,0,0,0,0]])
    check(17753987,'add',[y0,17753986])
    check(17753988,'multiply',[17733068,17753986])
    check(17753989,'add',[y1,17753988])
    check(17754185,'m3_aux_indexed_partial',[2,[17753980,z,t,ell,17753987,17753989],[0,2,0,0,0]])
    product(17754187,20,eps,17754185)
    for node,body,right in [(17754191,17754190,r),(17754192,17754190,hi)]:
        check(node,'definite_integral',[body,17753980,lo,right])
    check(17754229,'multiply',[17744145,17753668])
    product(17754233,20,chi,17754192)
    check(17754234,'add',[17754231,17754233])
    product(17754265,eps,17754234)
    check(17754267,'add',[17754265,17754266])
    check(17754268,'add',[17744195,17754267])
    # T1 keeps one r-weighted translated axial inverse, both integrals, R^-1 and chi.
    b = 19570776
    check(19570770,'inverse',[ci])
    check(19570782,'add',[17753501,19570781])
    check(19570783,'add',[y0,19570782])
    check(19570784,'multiply',[17733068,19570782])
    check(19570785,'add',[y1,19570784])
    check(19570809,'m3_aux_inverse_partial',[1,[b,z,t,ell,19570783,19570785],[0]*5])
    product(19570812,20,b,19570770,19570809)
    for node,right in [(19570813,r),(19570814,hi)]:
        check(node,'definite_integral',[19570812,b,lo,right])
    product(19570915,20,chi,19570814)
    check(19570916,'add',[19570813,19570915])
    product(19570917,17733137,19570916)

    check(19570919,'m3_aux_expression_partial',[-13,full,[0,0,1,0,0,0]])
    product(19570921,20,eps,19570919)
    check(21374032,'m3_aux_expression_partial',[-13,full,[0,0,1,1,0,0]])
    product(21374035,20,eps,eps,21374032)
    check(21374036,'multiply',[20,21374035])
    check(21374040,'add',[21374036,21374039])
    check(21374041,'multiply',[20,21374040])
    check(21374067,'multiply',[20,21374066])
    check(21374149,'add',[21374145,21374148])
    # The complete gr additive tree really retains both its time and square branches.
    def sum_atoms(node):
        op, args = nodes.get(node, ('opaque', []))
        return set().union(*(sum_atoms(a) for a in args)) if op == 'add' else {node}
    assert {21374041,21374067,21374090,21374095} <= sum_atoms(21374149)
    check(21374043,'integer_power',[19570921,2])
    check(21374077,'multiply',[19570930,21374076])
    check(21374078,'multiply',[19570921,19570970])
    check(21374092,'integer_power',[19570772,2])

    check(21374483,'m3_aux_expression_partial',[-14,full,[0]*6])
    check(21374484,'definite_integral',[21374483,y0,0,1])
    check(21374485,'definite_integral',[21374484,y1,0,1])
    check(21374488,'m3_aux_expression_partial',[-15,[ell,21374487,z,t],[0]*4])
    check(21374489,'definite_integral',[21374488,21374487,lo,hi])
    check(21374490,'m3_aux_expression_partial',[-16,[ell,z,t],[0]*3])
    # Independently bind Jz's native flux and weighted-Haar branches.
    check(21374536,'m3_aux_indexed_partial',[5,[21374535,z,t,ell,y0,y1],[0]*5])
    product(21374559,21374538,21374558)
    check(21374560,'integer_power',[21374558,2])
    check(21374561,'add',[21374559,21374560])
    check(21374562,'add',[21374536,21374561])
    product(21374563,21374535,21374562)
    check(21374564,'definite_integral',[21374563,y0,0,1])
    check(21374565,'definite_integral',[21374564,y1,0,1])
    check(21374566,'definite_integral',[21374565,21374535,lo,hi])
    check(21374569,'integer_power',[21374568,2])
    check(21374570,'m3_aux_expression_partial',[-15,[ell,21374568,z,t],[0]*4])
    product(21374571,21374569,21374570)
    check(21374572,'definite_integral',[21374571,21374568,lo,hi])
    product(21374574,20,19,21374572)
    check(21374575,'add',[21374566,21374574])
    check(21374576,'m3_aux_expression_partial',[-18,[ell,z,t],[0]*3])
    return {'Wrz':17753400,'earlyShiftedWrzZZ':17754185,'earlyT0Integrals':[17754191,17754192],
            'earlyT0CutoffAndPressureTerm':17754234,'Ez':17754268,'axialInverse':{'system':1,'T1ShiftedApplication':19570809},
            'T1Integrals':[19570813,19570814],'T1Chi':chi,'temporalPsi':19570917,'temporalBeta':19570921,
            'grSlowTimePart':21374035,'completeGr':21374149,'haarGr':[21374484,21374485],
            'radialLimits':[lo,hi],'P0':[21374489,21374490],'Jz0':[21374575,21374576],
            'Jz0FluxIntegral':21374566,'Jz0WeightedHaarGr':21374572,
            'nonlinearGR':[21374043,21374077,21374078,21374092],'nonlinearJzCurrent':21374560}


def source_paths(workspace):
    work = workspace / 'work'
    evidence = work / 'goal-next'
    m3 = evidence / 'continuation30/forced-probe/runtime/research-ide/mathscope-m3/navier'
    goal = work / 'MathScopeCompute-Continuation22/tools/mathscope-cd-axial-bridge-20261029/goal-next'
    paths = {
        'registry': evidence / 'continuation34/hosted-43296617887-n3/witness/original-source-functions.json',
        'directional': goal / 'final67/mean-directional-stress/mean-directional.json',
        'prehaar': evidence / 'continuation73/prehaar-wrz/prehaar-wrz-final.json',
    }
    paths.update({k: m3 / k for k in PINS if k.endswith('.mjs')})
    return paths


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument('workspace',type=Path)
    cli.add_argument('slab',type=Path)
    cli.add_argument('out',type=Path)
    cli.add_argument('--bundle',action='store_true')
    args = cli.parse_args()
    if args.bundle:
        pins = Path(__file__).resolve().parent / 'pinned'
        paths = {name: pins / (name if name.endswith('.mjs') else name+'.json') for name in PINS}
    else:
        paths = source_paths(args.workspace)
    raw = {k: p.read_bytes() for k,p in paths.items()}
    for name, contents in raw.items():
        assert sha256(contents).hexdigest()==PINS[name], name
    check_tokens({k: v.decode('utf8') for k,v in raw.items() if k.endswith('.mjs')})
    slab_bytes = args.slab.read_bytes()
    assert sha256(slab_bytes).hexdigest()=='b63588358fd2ee676ffdbba6104d5f0c644828cdecff4215e0d87f09037f6f2c'
    slab = json.loads(slab_bytes)
    assert slab['nodeCount']==21681493 and slab['nodeBytes']==1000764709
    assert slab['originalStreamSHA256']=='831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a'
    source_ids = read_native(json.loads(raw['registry']),{int(k):v for k,v in slab['nodes'].items()})
    earlier = json.loads(raw['directional'])['selectedUnderlyingCovariancePath']
    assert earlier['covarianceJet']=={'Z':5,'T':2,'totalOrder':7} and earlier['outerTargetJet']=='P0_ZZT'
    assert json.loads(raw['prehaar'])['actualInitialMap']['application']==source_ids['Wrz']
    out = {
        'status': 'VERIFIED_ORIGINAL_NATIVE_P0_JZ0_HIGH_TEMPORAL_LINEAR_HAAR_PROJECTION',
        'sourcePins': PINS,
        'slabSHA256':sha256(slab_bytes).hexdigest(),
        'streamSHA256':slab['originalStreamSHA256'],
        'sourceIDs':source_ids,
        'exactSign': 'gr contains +epsilon*partial_T beta-ci*N beta; selected pre-Haar maximal Wrz leg has -epsilon^4/ci',
        'linearScalarProjection': {
            'inverse':'For every fixed original slow point the registered infinite N^-1 P_perp has zero normalized Haar mean.',
            'shift':'For each radial binder the original common-Y map is translation by (Phi(r)-Phi(R))*vr, so normalized Haar is unchanged.',
            'T1':'Fubini kills each r-weighted inverse integral separately; multiplication by cutoff, inverse ci and inverse R preserves the zero mean.',
            'slow':'Derivative of this pointwise zero identity in Z,T is zero. T0/T1 cutoffs, all slow prefactors and physical normalization remain present before Haar.',
            'limits':'Active whole radial endpoints sqrt(Xa) and 2*sqrt(Xb) are actually fixed. Leibniz terms for a moving generic endpoint also vanish for this pointwise-zero projected integrand.',
            'P0_ZZT':'zero from the entire isolated linear epsilon*partial_T beta term, including every lower cutoff product term and the highest Z^5 T^2 Wrz term',
            'Jz0_ZZT':'same weighted Haar(gr) identity with R^2 and factor -1/2; independently the flux branch contains gamma, gamma^2, Wzz and no beta time term; its linear 2*G0*gamma projects to zero',
            'gamma':'gamma=(partial_R+aL+1/R) psi. Radial differentiation, the integral of the constant vector field L on the torus and multiplication by 1/R preserve zero Haar.',
        },
        'negativeControl':'An inverse may output cos(2*pi*Y0) from its N derivative. Its Haar mean is zero, its square has Haar mean 1/2, so the original gamma^2/v^2/beta^2 product rule cannot be discarded.',
        'remaining':['genuine nonlinear Temporal products through their own directional source joins and inverse bounds',
                     'initial covariance, direct moment terms and all later stages',
                     'source-specific bounds for pointwise pre-Haar uses that retain inverse/cutoff/shift losses'],
        'finalJets':'0/67','release':'HOLD',
    }
    with args.out.open('x',encoding='utf8',newline='\n') as target:
        json.dump(out,target,indent=2)
        target.write('\n')
    print(out['status'])


if __name__=='__main__':
    main()

"""Authenticate the original N3 stream and extract source-native nodes for P0/Jz0."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import gzip
import json

EXPECTED = '831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a'
WINDOWS = (
    (17732730, 17732799), (17733030, 17733130), (17735150, 17735280),
    (17735990, 17736020), (17737050, 17737175), (17740460, 17740593),
    (17743700, 17743736), (17745420, 17745450), (17753390, 17754340),
    (19570700, 19571270), (21373700, 21374620),
)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('out', type=Path)
    args = parser.parse_args()
    digest = sha256()
    size = 0
    rows = {}
    windows = iter(WINDOWS)
    lo, hi = next(windows)
    with gzip.open(args.archive, 'rb') as src:
        header = src.readline()
        assert json.loads(header) == {'schema': 'MathScope.M3.FullNodesJSONL/1', 'node_count': 21681493}
        digest.update(header)
        size += len(header)
        for i, line in enumerate(src):
            digest.update(line)
            size += len(line)
            if i > hi:
                lo, hi = next(windows, (21681493, 21681493))
            if lo <= i <= hi or i < WINDOWS[-1][-1] and line.startswith(b'{"op":"rational"'):
                node = json.loads(line)
                rows[i] = [node['op'], node['args']]
    assert i + 1 == 21681493 and size == 1000764709 and digest.hexdigest() == EXPECTED
    result = {'originalStreamSHA256': EXPECTED, 'nodeCount': i + 1, 'nodeBytes': size,
              'windows': WINDOWS, 'nodes': rows}
    with args.out.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(result, stream, separators=(',', ':'))
        stream.write('\n')
    print(f'Authenticated {i + 1} original source nodes, retained {len(rows)} occurrence records')


if __name__ == '__main__':
    main()

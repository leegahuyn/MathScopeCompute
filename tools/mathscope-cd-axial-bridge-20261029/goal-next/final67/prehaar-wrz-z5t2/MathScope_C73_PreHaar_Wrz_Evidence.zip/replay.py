"""Run the selected Wrz verifier against the preserved workspace inputs."""
from argparse import ArgumentParser
from pathlib import Path
import subprocess
import sys


def source_paths(workspace):
    work = workspace / 'work'
    local = work / 'goal-next'
    goal = work / 'MathScopeCompute-Continuation22/tools/mathscope-cd-axial-bridge-20261029/goal-next'
    witness = local / 'continuation34/hosted-43296617887-n3/witness'
    original = local / 'continuation30/forced-probe/runtime/research-ide'
    m3 = original / 'mathscope-m3/navier'
    inputs = {
        'registry': witness / 'original-source-functions.json',
        'constructor': m3 / 'source-global-pressure.mjs',
        'current': m3 / 'source-global-current.mjs',
        'kernel': m3 / 'source-auxiliary-expressions.mjs',
        'band': m3 / 'source-global-band.mjs',
        'curl': original / 'mathscope-m2/navier/actual-full-curl.mjs',
        'selected': goal / 'final67/selected-covariance-order/selected-audit.json',
        'directional': goal / 'final67/mean-directional-stress/mean-directional.json',
        'w4': goal / 'primary-forced-join/active-n3-c5-binding/mean-c4/common-w4/common-w4-weighted-v4.json',
        'transport': goal / 'final67/n7-n8-target-primary-transport/primary-transport.json',
        'slow_cost': goal / 'final67/local-forced-operator/local-forced-cost.json',
        'khat': local / 'continuation73/conditional-primary-high/external-primary-k-half.json',
    }
    return witness, inputs


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('workspace', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--capture', type=Path, help='rebuild the slab into a new file')
    parser.add_argument('--bundle', action='store_true', help='use the bundled pinned verifier inputs')
    args = parser.parse_args()
    scripts = Path(__file__).resolve().parent
    witness, inputs = source_paths(args.workspace)
    slab = args.capture or scripts / 'source-slab.json'
    if args.capture is not None:
        subprocess.run([sys.executable, scripts / 'capture_original.py', witness, slab], check=True)
    if args.bundle:
        for key in inputs:
            inputs[key] = scripts / 'pinned' / (key + inputs[key].suffix)
    inputs.update(slab=slab, out=args.output)
    command = [sys.executable, scripts / 'verify_prehair_wrz.py']
    for key, path in inputs.items():
        command.extend(['--' + key, path])
    subprocess.run(command, check=True)


if __name__ == '__main__':
    main()

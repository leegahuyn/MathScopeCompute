"""Authenticate the complete hosted graph and extract the selected cover slab."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import gzip
import json


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('witness', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    witness_bytes = (args.witness / 'original-active-mode-two-witness.json').read_bytes()
    registry_bytes = (args.witness / 'original-source-functions.json').read_bytes()
    assert sha256(witness_bytes).hexdigest() == 'a35bd111ef2f60b0e779a85433571db8caa00061616da91372782a28a16859e9'
    assert sha256(registry_bytes).hexdigest() == '364425db9d5bbd317f8aaad681fdfdd3206f97e0f46d2beb78b6e7d5a30a3111'
    metadata = json.loads(witness_bytes)['snapshot']
    registry = json.loads(registry_bytes)
    fields = json.loads(registry['base']['fieldDefinitions'])
    field = fields[2]
    roots = {field['sourceRecipe']['originalCurrentCovariance']}
    for row in field['rows']:
        roots.update(row['values'])
        roots.update(v['coefficient'] for gross in row['derivativeMaps'] for v in gross)
        roots.update(v for guard in row['guards'] for v in guard)
        roots.update([row['coefficient'], row['localBody']])
    low = min(field['parameters']) - 256
    high = max(roots) + 1024
    digest = sha256()
    size = 0
    records = {}
    with gzip.open(args.witness / 'original-source-nodes.jsonl.gz', 'rb') as source:
        header_line = source.readline()
        header = json.loads(header_line)
        assert header == {'schema': 'MathScope.M3.FullNodesJSONL/1', 'node_count': metadata['node_count']}
        digest.update(header_line)
        size += len(header_line)
        for index, line in enumerate(source):
            digest.update(line)
            size += len(line)
            if low <= index <= high or index < low and line.startswith(b'{"op":"rational"'):
                record = json.loads(line)
                records[index] = [record['op'], record['args']]
    assert index + 1 == metadata['node_count'] == 21681493
    assert size == metadata['node_stream_uncompressed_bytes'] == 1000764709
    assert digest.hexdigest() == metadata['node_stream_sha256'] == '831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a'
    result = {'min': low, 'max': high, 'verifiedSourceStream': metadata['node_stream_sha256'], 'nodes': records}
    with args.output.open('x', encoding='utf8', newline='\n') as target:
        json.dump(result, target, separators=(',', ':'))
        target.write('\n')
    print(f'Authenticated {index + 1} source nodes and stored {len(records)} selected records')


if __name__ == '__main__':
    main()

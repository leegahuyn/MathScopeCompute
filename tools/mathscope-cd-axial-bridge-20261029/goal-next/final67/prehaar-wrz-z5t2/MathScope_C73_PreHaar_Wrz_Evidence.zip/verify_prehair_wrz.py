"""Replay original signed Wrz bodies and fixed-label Z^5 T^2 transport."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
from fractions import Fraction as Q
from functools import cache
from hashlib import sha256
from pathlib import Path
import json

PINS = {
    'registry': '364425db9d5bbd317f8aaad681fdfdd3206f97e0f46d2beb78b6e7d5a30a3111',
    'constructor': 'fd93001ad4bbc002d329cba54d1c884cc5e7bfd93444b1d72bd9c331a67b966d',
    'current': '93f86661d67e6bc7b916218cd7af3db72f348ba7fdc876e3618ba3a49edff760',
    'kernel': 'e456b4511adcc997b64267b2229422618b6139955e0c9083f2b83f4739600463',
    'band': 'babe4aceb97d0bdee4084e5f06009e6724128935fffde1647c11e3aab022df60',
    'curl': '4276a850dbff4b5c357c47e1827eb7785b19c7e7c395c94ee4f22ef0c96d58d2',
    'selected': 'e3a75a028749af3815e617743325446d5f4dca817adf609bbefa5fe9f0968b84',
    'directional': '02c7b2d7ea24f43f90444952a03b31eba0a187b0675f765247c931df41ff2001',
    'w4': '9da54bbb2bd959e097c8ef610eabaf8ef8b163e540c73169dd82fcdaa784bc69',
    'transport': 'a6027c998b42336dbeffd5157e443eca485850e9cca3d78c0afcccf29cbff8b9',
    'slow_cost': 'e73562668961cf16705f59f2e4dd9fc4269d1b5bec5de958f9d6fc4307972fac',
    'khat': '5aef7c09a25a84a573ea43047a152461776e3feeb4a4c2fc8308dea5012cb824',
}


def plus(*polys):
    result = defaultdict(Q)
    for poly in polys:
        for key, value in poly.items():
            result[key] += value
    return {key: value for key, value in result.items() if value}


def times(left, right):
    result = defaultdict(Q)
    for a, ca in left.items():
        for b, cb in right.items():
            counts = Counter(a + b)
            key = tuple(sorted(i for i in counts for _ in range(max(0, counts[i] - counts[-i]))))
            result[key] += ca * cb
    return {key: value for key, value in result.items() if value}


def scalar(value):
    return {(): value} if value else {}


def derivative_tools(nodes, directions):
    @cache
    def deps(index):
        if index in directions:
            return frozenset([index])
        if index < min(directions):
            return frozenset()
        op, args = nodes[index]
        if op in ('coordinate', 'rational', 'source_parameter'):
            return frozenset()
        if op == 'ceiling' and index < directions[3]:
            # Nearest slow band/mesh labels are integers on the fixed-label chart.
            # Later ceilings are auxiliary-copy or palette expressions.
            return frozenset()
        if op in ('exp', 'log_positive', 'inverse', 'sqrt_positive', 'ceiling', 'integer_power'):
            children = args[:1]
        else:
            assert op in ('add', 'multiply', 'smooth_piecewise'), (index, op, args)
            children = args
        assert all(i < index for i in children), index
        return frozenset().union(*(deps(i) for i in children))

    @cache
    def algebra(index, inverted=False):
        op, args = nodes.get(index, ('opaque', []))
        if op == 'rational':
            value = Q(*map(int, args))
            return scalar(1 / value if inverted else value)
        if op == 'multiply':
            result = scalar(Q(1))
            for a in args:
                result = times(result, algebra(a, inverted))
            return result
        if op == 'inverse':
            return algebra(args[0], not inverted)
        if op == 'add' and not inverted:
            return plus(*(algebra(a) for a in args))
        return {(-index if inverted else index,): Q(1)}

    @cache
    def dy(index, coord):
        if coord not in deps(index):
            return {}
        if index == coord:
            return scalar(Q(1))
        op, args = nodes[index]
        if op == 'ceiling':
            return {}  # fixed nearest-copy integer on an open copy chart
        if op == 'add':
            return plus(*(dy(a, coord) for a in args))
        assert op == 'multiply', (index, op, args)
        terms = []
        for k, a in enumerate(args):
            term = dy(a, coord)
            for j, b in enumerate(args):
                if j != k and term:
                    assert coord not in deps(b), (index, a, b)
                    term = times(term, algebra(b))
            terms.append(term)
        return plus(*terms)

    return deps, algebra, dy


def read_angular_body(nodes, row):
    index = row['localBody']
    guard_ids = []
    while nodes[index][0] == 'smooth_piecewise':
        _, _, _, left, mid, right = nodes[index][1]
        assert left == right == 0
        guard_ids.append(index)
        index = mid
    assert len(guard_ids) == 7
    op, (one_half, total) = nodes[index]
    assert op == 'multiply' and nodes[one_half] == ['rational', ['1', '2']]
    op, products = nodes[total]
    assert op == 'add' and len(products) == 2
    assert all(nodes[p][0] == 'multiply' and len(nodes[p][1]) == 2 for p in products)
    return {'guardedBody': row['localBody'], 'localSystem': row['localSystem'],
            'nonzeroBranch': index, 'flatGuardNodes': guard_ids, 'productNodes': products}


def source_map(nodes, fields, definitions):
    field = fields[2]
    directions = [17732748, 17732749, 17732750, 17745430, 17745431]
    parameters = directions[:3] + [17732737] + directions[3:]
    local = parameters[:4] + [17733856, 17733857, 17733858, 17733037, 17732751]
    dep, algebra, dy = derivative_tools(nodes, directions)
    assert field['parameters'] == parameters and field['directions'] == directions
    assert field['directionParameterIndices'] == [0, 1, 2, 4, 5]
    assert len(field['rows']) == 162 and field['name'] == 'GlobalCompleteCommonTorus_rz'
    assert nodes[17753400] == ['m3_aux_indexed_partial', [2, parameters, [0, 0, 0, 0, 0]]]
    assert nodes[17753414] == ['m3_aux_indexed_partial', [2, parameters, [0, 1, 0, 0, 0]]]
    assert nodes[17743679] == ['m3_global_indexed_partial', [2, parameters[:4], [0, 0, 0]]]
    recipe = field['sourceRecipe']
    assert recipe['originalCurrentCovariance'] == 17743679
    assert recipe['sourceBodyIsTheOriginalCompleteHarmonicCurl']
    assert recipe['labelsAndNearestCopiesFrozenBeforeDifferentiation']
    assert recipe['physicalCovarianceScale'] == '(Q_ref/Q_label)^(2A)'
    assert recipe['matrix'] == 'Jg^(i_label-i0)'
    bands = defaultdict(set)
    signed = defaultdict(set)
    angular_body = {}
    exact_column_count = 0
    for k, row in enumerate(field['rows']):
        label = row['label']
        key, sign = label['key'], label['sign']
        signed[key].add(sign)
        system = definitions[-1 - row['localSystem']]
        assert system['body'] == row['localBody'] and system['parameters'] == row['localParameters'] == local
        assert system['name'] == f'GlobalCommonTorusOriginalFullCurl_{sign}_rz'
        assert row['values'][3:7] == [label['ell'], *label['grid']]
        for sibling in [fields[j]['rows'][k] for j in (1, 4)]:
            for part in ('coefficient', 'values', 'derivativeMaps', 'guards', 'label'):
                assert row[part] == sibling[part]
        maps = row['derivativeMaps']
        assert [[x['parameter'] for x in dm] for dm in maps] == [[0], [1], [2], [7, 8], [7, 8]]
        scale = [dm[0]['coefficient'] for dm in maps[:3]]
        for a, coord, factor in zip(row['values'][:3], directions[:3], scale):
            assert nodes[a][0] == 'multiply' and sorted(nodes[a][1]) == sorted([coord, factor])
            assert dep(a) == {coord} and not dep(factor)
        rho = scale[2]
        assert nodes[scale[0]] == ['sqrt_positive', [rho]]
        assert nodes[rho][0] == 'multiply' and 17732740 in nodes[rho][1]
        assert nodes[17732740][0] == 'exp' and not dep(rho)
        denom, = set(nodes[rho][1]) - {17732740}
        assert nodes[denom][0] == 'inverse'
        exponent_z, = nodes[scale[1]][1]
        exponent_w, = nodes[row['coefficient']][1]
        assert nodes[scale[1]][0] == nodes[row['coefficient']][0] == 'exp'
        assert nodes[exponent_z][0] == nodes[exponent_w][0] == 'multiply'
        assert 22 in nodes[exponent_z][1] and 5294 in nodes[exponent_w][1]
        log_rho, = set(nodes[exponent_z][1]) - {22}
        assert set(nodes[exponent_w][1]) - {5294} == {log_rho}
        assert nodes[log_rho] == ['log_positive', [rho]]
        assert not dep(row['coefficient'])
        assert all(not dep(v) for v in row['values'][3:7])
        for col, coordinate in zip(maps[3:], directions[3:]):
            for entry in col:
                assert not dep(entry['coefficient'])
                value = row['values'][entry['parameter']]
                assert dep(value) == set(directions[3:])
                assert dy(value, coordinate) == algebra(entry['coefficient']), (k, entry, coordinate)
                exact_column_count += 1
        assert len(row['guards']) == 5 and all(len(g) == 3 for g in row['guards'])
        bands[key.split(':')[0]].add(tuple([rho, *scale[:2], row['coefficient']]))
        if sign not in angular_body:
            angular_body[sign] = read_angular_body(nodes, row)
        else:
            assert row['localBody'] == angular_body[sign]['guardedBody']
    assert len(signed) == 81 and all(pair == {-1, 1} for pair in signed.values())
    assert set(bands) == {'-1', '0', '1'} and all(len(v) == 1 for v in bands.values())
    assert exact_column_count == 648
    selected_order = [0, 5, 2, 0, 0]
    local_order = [0] * 9
    for j, n in enumerate(selected_order):
        if n:
            only_entry, = field['rows'][0]['derivativeMaps'][j]
            local_order[only_entry['parameter']] += n
    assert local_order == [0, 5, 2, 0, 0, 0, 0, 0, 0]
    return {'field': 2, 'application': 17753400, 'firstZApplication': 17753414, 'directionOrder': selected_order,
            'localOrder': local_order, 'rows': 162, 'boxes': 81, 'originalAngularBodies': angular_body,
            'bandFactorNodesRhoSqrtRhoRhoDRho2A': {k: list(next(iter(v))) for k, v in bands.items()},
            'derivativeYColumnEntries': exact_column_count, 'termsPerInteriorRow': 1,
            'selectedRowMultiplier': 'rho^(2A+5D+2)', 'torusDerivativesInSelectedPath': 0}


def arithmetic(hybrid, external, slow_cost):
    assert hybrid['targetPoles'] == [3 * (j + 1) for j in range(9)]
    degree = hybrid['finalDegrees']
    assert degree['primaryCovariance'] == {'power': 2976, 'pole': 44}
    assert degree['covarianceRemainder'] == {'power': 3813, 'pole': 54}
    assert 'All conditional external Khat values are below exp(H/2^128)' in external['smallGrowth']
    assert 'Bnorm <= W^8' in external['unchangedBnormDominance']
    assert external['actualWholePathAssociation'] == 'OPEN'
    assert 'log(S_label)/H < 12/(h sqrt(L)) < 12/Bnorm^255 < 2^-128' in json.dumps(slow_cost)
    kappa = Q(1, 100000)
    for epsilon_power in [Q(1), 2 - 2 * kappa]:
        low_exponent = Q(11, 2) - (3 + epsilon_power) * Q(1, 64)
        assert 0 < low_exponent < Q(11, 2)
    assert 2048**2 == 4**11 and 162 * 2048 < 2**19
    assert 4 * 3813 + 19 + 2**13 < 2**15
    assert 'L=ellMinimum+15 >= Bnorm^512' in slow_cost['sourceScale']
    assert 'Bnorm>=2^128' in slow_cost['sourceScale']
    assert 1 - Q(1, 2**113) - Q(27, 2**128) > Q(1, 2)
    absorb, = [v for v in external.values() if isinstance(v, dict) and 'halfGaussianCompareHOver2Pow115' in v]
    assert absorb['halfGaussianCompareHOver2Pow115'] == -1
    return {'transportPowerWithEpsilon': '11/2-(3+beta)h for beta in {1, 2-2*kappa_s}',
            'maximumGeometricFactor': 2048,
            'weightedBound': '162*2048*zeta*((4*Khat*S_ref)^2976*epsilon_ref*delta_*^-44 + (4*Khat*S_ref)^3813*epsilon_ref^(2-2*kappa_s)*delta_*^-54)',
            'halfGaussianPoleFactor': absorb['halfGaussianBound'],
            'prefactorLogBudget': '(4*3813+19+2^13)*H/2^128 < H/2^113, including half-Gaussian pole factor',
            'epsilonRefLogUpper': '-H + 3H/L using the original q=Q_ref*s, 1/2<=s<=2 and q<=4*tau0',
            'peakAfterEpsilon7': 'epsilon_ref^7 |partial_Z^5 partial_T^2 W_rz| <= exp(-7H)*sqrt(zeta), strict wherever zeta>0'}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in (*PINS, 'slab', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = vars(parser.parse_args())
    raw = {name: args[name].read_bytes() for name in PINS}
    for name, value in raw.items():
        assert sha256(value).hexdigest() == PINS[name], name
    for name, tokens in {
        'constructor': ['body:atRepresentative(row.angularMean[name])',
                        'values=[...b.slow,label.ell,...label.grid,rectangle.xi,rectangle.v]',
                        'coefficient=power(b.ratio,G.mul(q(2),A))',
                        'derivativeScales=[G.sqrt(b.ratio),power(b.ratio,D),b.ratio]',
                        'vJacobian=[0,1].map(j=>G.div(dot(G,vt,matrix.map(row=>row[j])),G.mul(Dgeom,ci)))',
                        'Every local compact rectangle has the original flat auxiliary joins'],
        'current': ['angular=G.mul(q(1,2),G.add(G.mul(curl.leading[a],curl.leading[b]),G.mul(curl.remainder[a],curl.remainder[b])))',
                    'angularMean[name]=aux.body', 'mean[name]=G.share(fixed,localParameters',
                    'sourceBodyDerivativesTakenBeforeRepresentativeSubstitution:true'],
        'kernel': ['const alpha=old.split',
                   'this.materializeExpressionFunction(row.localSystem,row.localParameters,localOrders)',
                   'this.expressionValue(row.localSystem,row.values,localOrders)',
                   'labelsDifferentiated:false,torusNearestCopyDifferentiated:false'],
        'band': ['Q=window.Q,S=G.pow(ell,2),epsilon=power(Q,h)', 'qActual=G.mul(Q,s)',
                 'Original image s in[1/2,2]'],
    }.items():
        assert all(token in raw[name].decode('utf8') for token in tokens), name
    registry = json.loads(raw['registry'])['base']
    fields = json.loads(registry['fieldDefinitions'])
    definitions = json.loads(registry['expressionDefinitions'])
    slab_bytes = args['slab'].read_bytes()
    assert sha256(slab_bytes).hexdigest() == '8152230d5531fd00bb0685fbcb380ad1b7a116d8833ee871d92803663aee19e9'
    slab = json.loads(slab_bytes)
    assert slab['verifiedSourceStream'] == '831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a'
    nodes = {int(i): v for i, v in slab['nodes'].items()}
    source = source_map(nodes, fields, definitions)
    old_selected = json.loads(raw['selected'])['selectedCovariance']
    assert old_selected['jet'] == {'Z': 5, 'T': 2} and 'Ctheta_Z' in old_selected['imaginary']
    path = json.loads(raw['directional'])['selectedUnderlyingCovariancePath']
    assert 'Wrz' in json.dumps(path) and '5' in json.dumps(path)
    assert path['covarianceJet'] == {'Z': 5, 'T': 2, 'totalOrder': 7}
    assert path['explicitEpsilonAfterWeightedSigmaTheta_Dz2_Time'] == 7
    path = {k: v for k, v in path.items() if k != 'actualSelectedJetBounded'}
    transfer, = [t for t in json.loads(raw['transport'])['transfers'] if t['outputOrder'] == 7]
    assert transfer['originalExponents']['exactInitialCovarianceRemainder'] == '2-2*kappa_s'
    result = {'status': 'VERIFIED_ORIGINAL_PREHAAR_WRZ_FIXED_LABEL_MAP_CONDITIONAL_WEIGHTED_BOUND',
              'sourcePins': PINS, 'slabSHA256': sha256(slab_bytes).hexdigest(),
              'actualSourceStreamSHA256': slab['verifiedSourceStream'], 'actualInitialMap': source,
              'conditionalWeightedTransport': arithmetic(transfer['sharperHybridTransfer'], json.loads(raw['khat']), json.loads(raw['slow_cost'])),
              'selectedActualConsumer': path, 'nativeM7SealConstructed': False,
              'premises': ['original fixed-atlas row arguments stay in the admitted pointwise source domains, with 1/2<=s<=2 and q<=4*tau0',
                           'same original Gaussian zeta and boundary distance delta_* at reference and own-label coordinates',
                           'ell_ref<=2L, S_label<=4 S_ref, and 1/4<=rho<=4',
                           'same original local full Primary covariance components under the hybrid m7 target and C73 external Khat',
                           'compact flat joins and reindexing of original label and integer copy choices'],
              'remaining': ['source-family admission of the same initial live and frozen premises on the mapped atlas',
                            'mean transport and downstream T0/T1, L^2, N inverse and later signed stage propagation'],
              'finalJets': '0/67', 'release': 'HOLD'}
    with args['out'].open('x', encoding='utf8', newline='\n') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(result['status'])


if __name__ == '__main__':
    main()

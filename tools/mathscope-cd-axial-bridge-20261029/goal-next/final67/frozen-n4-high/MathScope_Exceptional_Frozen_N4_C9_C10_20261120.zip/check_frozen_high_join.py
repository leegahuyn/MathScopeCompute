"""Join the freshly executed original raw C10 trace to the exceptional frozen cell."""
from argparse import ArgumentParser
from hashlib import sha256
from importlib.util import spec_from_file_location,module_from_spec
from pathlib import Path
from runpy import run_path
import json
if not __debug__:raise RuntimeError('Keep exact assertions enabled.')
PRIOR={'raw-trace.json':'f6f51da9fd48f63ad483f22de6153cc4618ee48200e827ffa5adb78ef417f91a',
 'hosted-binding.json':'f5712f2ada0a78c15b814d2fc385bb4788291621c9c37cb1790c37bbfba70f59',
 'frequency.json':'02cd46103f08c383c1d1701684a71093666606ec3c88bb125b9aaab39c0b7861',
 'frozen-n4-bridge.json':'4459d1098e5e44b09ac395054f031b0cc6130f1c09878ebad1214ddf23fdf410'}
def main():
 p=ArgumentParser(description=__doc__);p.add_argument('goal',type=Path);p.add_argument('prior',type=Path);p.add_argument('directory',type=Path);a=p.parse_args()
 def load(path,pin=None):
  b=path.read_bytes();h=sha256(b).hexdigest()
  if pin:assert h==pin,path
  return json.loads(b),h
 prior={name:load(a.prior/name,pin)[0] for name,pin in PRIOR.items()}
 raw,rawpin=load(a.directory/'raw-trace-high.json')
 assert raw['derivativeOrder']==10 and raw['originalNodes']==127241
 assert raw['actualSystem']==7 and raw['auxiliarySystem']==6
 assert raw['originalPrefix']==prior['raw-trace.json']['originalPrefix']==prior['hosted-binding.json']['originalPrefixSHA256']
 assert raw['sourceProfile']=='e44aab5d21cbe4205d0333d7d73b646444ebaa282d67b2034edfde1e4180f152'
 assert len(raw['rawRoots'])==132 and raw['trace']['nodeCount']==280399
 assert not raw['trace']['nonArithmeticBoundaries']
 oldnodes={r['id']:r['node'] for r in prior['raw-trace.json']['trace']['nodes'] if r['id']<127241}
 newnodes={r['id']:r['node'] for r in raw['trace']['nodes'] if r['id']<127241}
 assert newnodes==oldnodes and len(newnodes)==902
 assert prior['hosted-binding.json']['fullGraphNodes']==7358162
 assert prior['hosted-binding.json']['anchors']==[117782,118573]
 rank,rankpin=load(a.directory/'relative-high.json');atoms,atomspin=load(a.directory/'relative-atoms-high.json')
 assert rank['rawTraceSHA256']==rawpin and atoms['packetSHA']==rankpin
 assert rank['rank']==[2,33127] and rank['rank'][1]<3*16384
 assert rank['anchors']==[117782,118573] and rank['separateFiniteFrequencyAtom']==216322
 assert len(rank['atoms'])==rank['atomCount']==len(atoms['rows'])==80
 assert all(row['status']=='BELOW' and row['compared']==-1 for row in atoms['rows'])
 assert [row['nodeId'] for row in atoms['rows']]==rank['atoms']
 assert atoms['factual']=={'finiteCap':-1,'actualRadialGap':-1}
 assert int(rank['largestRankExponent'])<2**128 and rank['maxRationalBitLength']>=1024
 frequency,freqpin=load(a.directory/'frequency-high.json')
 assert frequency['rawTraceSHA256']==rawpin and frequency['A_ranks']=={'216317':[2,8705]}
 assert frequency['degree']==74 and 51*74+1==3775<4096
 # Independently retain a C8 control and the sole final-guard extension.
 oldpath=a.goal/'whole-k-selector-scales/fourth/close_fourth_selector.py'
 assert sha256(oldpath.read_bytes()).hexdigest()=='95c64384832784fa6f8bdfed94ff6b0c44e24b001b131fd058fd8e80ca5b0bd1'
 old=run_path(str(oldpath));corepath=a.directory/'frequency_rank_core.py'
 assert sha256(corepath.read_bytes()).hexdigest()==frequency['coreSHA256']
 spec=spec_from_file_location('freqcore',corepath);core=module_from_spec(spec);spec.loader.exec_module(core)
 for name in ('DEN','SMALL_PROFILE','RATIONAL','POLYNOMIAL','UNARY'):assert vars(core)[name]==old[name]
 prior_nodes=old['node_table'](prior['raw-trace.json']['trace'])
 assert core.frequency_operand_ranks(prior_nodes,[203224])==old['frequency_operand_ranks'](prior_nodes,[203224])
 assert core.frequency_operand_ranks(prior_nodes,[203224])[0]=={'203224':[2,7394]}
 failed=False
 try:old['frequency_operand_ranks'](old['node_table'](raw['trace']),[216317])
 except AssertionError as error:
  tb=error.__traceback__
  while tb.tb_next:tb=tb.tb_next
  assert tb.tb_frame.f_code.co_name=='frequency_operand_ranks'
  assert tb.tb_frame.f_locals['bounds'][216317][0]==(2,8705)
  failed=True
 assert failed
 selector,selectorpin=load(a.goal/'whole-k-selector-scales/fourth/fourth-selector-maxima.json','5a6ecee45d797d582e3218c36f980d5eb131619c860cec1bfb4d57aea89cdf56')
 assert selector['threshold']['M2Anchors']==[117782,118573]
 assert selector['threshold']['positiveFactorPathChecked'] and selector['exactRatios']['b4*qBig']==64
 flat,flatpin=load(a.directory/'flat-high.json');chart,chartpin=load(a.directory/'high-cutoff-chart.json')
 assert max(map(int,flat['weightedEuler']))<2**128 and len(flat['weightedEuler'])==11
 assert chart['cutoffSHA256']==flatpin and [r['derivativeOrder'] for r in chart['rows']]==[9,10]
 result={'schema':'MathScope.ExceptionalFrozenN4RawC9C10Bridge/1','status':'PASS_ORIGINAL_RAW_C10_RANK_AND_CUTOFF_TRANSPORT_CONDITIONAL_SOURCE_ANALYSIS',
  'priorEvidenceSHA256':PRIOR,'rawTraceSHA256':rawpin,'relativeRankSHA256':rankpin,'relativeAtomsSHA256':atomspin,
  'frequencySHA256':freqpin,'cutoffSHA256':flatpin,'pointwiseChartSHA256':chartpin,'selectorSHA256':selectorpin,
  'originalPrefix':{'nodes':127241,'sha256':raw['originalPrefix'],'retainedPrefixRowsCompared':902,'allEqualArchivedOriginalN4':True,
   'priorCompleteHostedGraphNodes':7358162,'sameActualRawSystem':7,'sameAuxiliarySystem':6},
  'rawC10':{'derivatives':132,'arithmeticRecords':280399,'nonArithmeticBoundaries':0,'rank':[2,33127],'rankDenominator':16384,
   'polynomialDegree':rank['polynomialDegree'],'independentCuts':rank['cutCount'],'independentAtoms':80,'allDirectedStrictlyBelow':True},
  'finiteFrequency':{'newAtom':216322,'newA':216317,'degree':74,'A_rank':[2,8705],'sourceExponentUpper':18,
   'oldExponent16GuardRejected':True,'sameCoreC8ControlPassed':True,'originalRankAlgebraUnchangedExceptFinalGuard':True},
  'chartCutoff':{'eulerOrder':10,'constant':'2^128','pointwiseChartOrder':10,'chartCoefficient':'2^1856*Hchart^143',
   'maximumProfileTerms':286,'logChartCost':'<L^2','logRawCost':'<L','cutoffLogGain':'-2L^6/3'},
  'conclusion':'For the SAME exceptional active frozen n4 representative and every original normalized slow F/G derivative of total order<=10, the fourth summand is bounded by exp(-L^6/3)<1, L=ellMinimum+16, conditional on the original Picard, Cauchy and real radial recurrence analytic majorants and source domain admission. Orders9/10 are included.',
  'domain':'The selected positive fourth representative lies in Xa<Xrep<Xkeep. Actual raw Picard system7 applies on that original real collar; auxiliary system6 is used only for its admitted core bounds, with equality to actual fields restricted to X<=Xa. Original cutoff is zero with all derivatives at/beyond b4*qrep=1. All frozen n>=5 are flat zero by the original selector doubling argument.',
  'remaining':['Independent same-domain first-three full background C9/C10 bounds and their numerical +1 comparison.','Original operator/path admission and transfer, selected pressure/mean/radial dependencies, and complete Primary/Forced/Signed class binding.'],
  'scope':{'exceptionalFrozenN4Through10':True,'allOperatorPaths':False,'fullBackgroundC10Closed':False,'nativeClassSealCreated':False,'finalJets':'0/67','release':'HOLD'}}
 (a.directory/'frozen-high-bridge.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
 print('PASS original raw n4 C9/C10<=exp(-L^6/3)<1; all80 atoms and degree74 frequency bound; C8 control passed')
if __name__=='__main__':main()


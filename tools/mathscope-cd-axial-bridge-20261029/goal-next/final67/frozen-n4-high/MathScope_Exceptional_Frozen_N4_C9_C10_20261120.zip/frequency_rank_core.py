"""Original frequency rank algebra, with the explicit C10 exponent18 guard."""
from fractions import Fraction
DEN=512
SMALL_PROFILE={"Md","T","BOuter","lambda","h","Pstar","logP","XR","Lambda","sigmaStar","CSelected","t1","Tsh","muMoment","Q","rho","K"}
RATIONAL={"rational","source_parameter"}
POLYNOMIAL={"add","multiply","maximum","sqrt_positive"}
UNARY={"exp","log_positive","inverse"}
def node_table(trace):
    rows = trace["nodes"]
    result = {r["id"]: (r["node"]["op"], r["node"]["args"]) for r in rows}
    assert len(result) == len(rows) and list(result) == sorted(result)
    return result

def children(op, args):
    if op in POLYNOMIAL | UNARY:
        return args
    if op == "integer_power":
        return args[:1]
    assert op in RATIONAL
    return []

def dependencies(nodes, roots, stop=()):
    visited, todo = set(), list(roots)
    while todo:
        i = todo.pop()
        if i in visited:
            continue
        visited.add(i)
        if i not in stop:
            operands = children(*nodes[i])
            assert all(0 <= j < i for j in operands)
            todo.extend(operands)
    return sorted(visited)

def rational_rank(value):
    value = abs(value)
    if value <= 1:
        return 0, 0
    # x=S^(1/512)>2^(100000/512), so x^e covers this binary numerator.
    return 0, (value.numerator.bit_length()*DEN+99999)//100000

def frequency_operand_ranks(nodes, roots):
    # Rank (d,e) means exp iterated d times at x^e, x=S^(1/512).
    def combine(ranks):
        level = max(d for d, _ in ranks)
        assert all(0 <= e < 2**90 for _, e in ranks)
        return level, max(e if d == level else 1 for d, e in ranks)

    def product(ranks):
        d, e = combine(ranks)
        return (d, e+1) if d else (0, sum(j for _, j in ranks))

    def power(rank, exponent):
        d, e = rank
        assert 0 <= exponent <= 2**190
        return (0, 0) if not exponent else (d, e+1) if d else (0, e*exponent)

    bounds = {}
    for i in dependencies(nodes, roots):
        op, args = nodes[i]
        assert 1 <= len(args) <= 2**190
        inverse = None
        if op == "rational":
            value = Fraction(*map(int, args))
            direct = rational_rank(value)
            if value:
                inverse = rational_rank(1/value)
        elif op == "source_parameter":
            name, = args
            if name in SMALL_PROFILE:
                direct = inverse = (0, 1)
            else:
                direct, inverse = {
                    "sourceEnvelopeS": ((0, DEN), (0, 0)),
                    "loopMuMax": ((0, 12*DEN), (0, 0)),
                    "loopD0": ((0, 0), (0, DEN+1)),
                    "loopDelta": ((0, 0), (1, 16*DEN)),
                }[name]
        elif op == "add":
            d, e = combine([bounds[j][0] for j in args])
            direct = d, e+1
        elif op == "multiply":
            direct = product([bounds[j][0] for j in args])
            if all(bounds[j][1] is not None for j in args):
                inverse = product([bounds[j][1] for j in args])
        elif op == "maximum":
            direct = combine([bounds[j][0] for j in args])
        elif op == "sqrt_positive":
            direct, inverse = bounds[args[0]]
        elif op == "log_positive":
            assert nodes[args[0]][0] == "source_parameter"
            assert nodes[args[0]][1][0] in {"CSelected", "XR", "Lambda"}
            direct = 0, 1
        elif op == "exp":
            d, e = bounds[args[0]][0]
            direct = inverse = d+1, e
        elif op == "inverse":
            inverse, direct = bounds[args[0]]
            assert direct is not None
        else:
            assert op == "integer_power"
            j, k = args
            direct = power(bounds[j][k < 0], abs(k))
            if bounds[j][k >= 0] is not None:
                inverse = power(bounds[j][k >= 0], abs(k))
        bounds[i] = direct, inverse
    assert all(bounds[i][0][0] == 2 and bounds[i][0][1] < 18*DEN for i in roots)
    return {str(i): list(bounds[i][0]) for i in roots}, len(bounds)

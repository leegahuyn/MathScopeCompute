import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {dirname, relative, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const [goalPath,workPath,output] = process.argv.slice(2);
assert.equal(process.argv.length,5);
const goal=resolve(goalPath),work=resolve(workPath);
const original=resolve(work,'continuation27/original-primary-degree-runtime');
const arithmeticRuntime=resolve(work,'annular-numeric-24/pinned-original-runtime');
const sourceRepo=resolve(goal,'../../..');
const sourceCommit='f8cb4034e86d7b669d52a6f2248aebba156b51b5';
const gitTree=execFileSync('git',['-c','safe.directory='+sourceRepo.replaceAll('\\','/'),
  '-C',sourceRepo,'ls-tree','-r',sourceCommit],{encoding:'utf8',maxBuffer:30*1024*1024});
const gitBlob=new Map(gitTree.split(String.fromCharCode(10)).filter(Boolean).map(row=>{
  const [entry,path]=row.split(String.fromCharCode(9));
  return [path,entry.split(' ')[2]];
}));
const checked=new Set();
const navier=name=>resolve(original,'research-ide/mathscope-m2/navier',name);
const arithmeticNavier=name=>resolve(arithmeticRuntime,'research-ide/mathscope-m2/navier',name);
const sha=body=>createHash('sha256').update(body).digest('hex');
async function pinned(relativeRoot,module){
  if(checked.has(module))return;
  checked.add(module);
  const name=relative(relativeRoot,module).replaceAll('\\','/');
  const data=await readFile(module);
  const object=createHash('sha1').update('blob '+data.length+String.fromCharCode(0)).update(data).digest('hex');
  assert.equal(object,gitBlob.get(name),name);
  for(const match of data.toString('utf8').matchAll(/(?:\bfrom\s+|\bimport\s*(?:\(\s*)?)['"](\.[^'"]+)['"]/g)){
    await pinned(relativeRoot,resolve(dirname(module),match[1]));
  }
}
const sourceModuleNames=['actual-residual-order-induction-source.mjs','actual-residual-order-induction-norms.mjs',
  'actual-continuation-arithmetic.mjs'];
for(const name of sourceModuleNames)await pinned(original,navier(name));
const traceModule=arithmeticNavier('actual-common-selection-arithmetic-trace.mjs');
await pinned(arithmeticRuntime,traceModule);
const mod=path=>import(pathToFileURL(path).href);
console.log('authenticated original source modules',checked.size);
const {prepareActualOrderInduction,assertActualOrderInduction}=await mod(navier('actual-residual-order-induction-source.mjs'));
const {attachActualInductionNorms,assertActualInductionNorms}=await mod(navier('actual-residual-order-induction-norms.mjs'));
const {traceExactArithmeticDependencies}=await mod(traceModule);
const {factorial}=await mod(navier('actual-continuation-arithmetic.mjs'));

const prepared=prepareActualOrderInduction({order:4,maxNodes:3000000});
assert.equal(assertActualOrderInduction(prepared),true);
const {G,bootstrap,records}=prepared;
const n4=records[4];
const originalNodes=G.nodes.length, originalPrefix=sha(JSON.stringify(G.nodes));
const {X,eta}=bootstrap.constants;
const {Xkeep,Xcut,X0,IposRight}=bootstrap.orderOne;
// On X<=Xkeep the local cut branch selects the original raw n4 field,
// and the annular moment-correction branch is zero.
for(const field of ['F','U']){
  const outer=G.nodes[n4.global[field]];
  assert.equal(outer.op,'actual_expression_partial');
  assert.deepEqual(outer.args[1],[X,eta]);
  assert.deepEqual(outer.args[2],[0,0]);
  const body=G.nodes[G.expressionSystems[outer.args[0]].body];
  assert.equal(body.op,'add');
  const branches=body.args.map(i=>G.nodes[i]);
  const local=branches.find(a=>a.op==='smooth_piecewise'&&a.args[1]===Xkeep);
  const annular=branches.find(a=>a.op==='smooth_piecewise'&&a.args[1]===X0);
  assert.deepEqual(local.args.slice(0,4),[X,Xkeep,Xcut,n4.raw[field]]);
  assert.deepEqual(annular.args.slice(0,4),[X,X0,IposRight,G.zero]);
  assert.deepEqual(G.nodes[n4.raw[field]],{op:'actual_background_even_profile',
    args:[n4.raw.system,field==='F'?0:1,X,eta,0,0]});
}
console.log('raw n4 bound roots', n4.raw.system, n4.auxiliary.system, originalNodes);
const n=attachActualInductionNorms(prepared,{derivativeOrder:10,throughOrder:4});
assert.equal(assertActualInductionNorms(n),true);
console.log('original mixed derivative recurrence evaluated symbolically',n.radialAudit.length,G.nodes.length);
const {actual,auxiliary}=n4.norm;
const Lambda=G.parameter('Lambda'), Xa=G.parameter('Xa');
const q=(a,b=1)=>G.q(a,b), max=xs=>G.maximum(...xs);
const etaFactor=(m,s)=>G.mul(q(factorial(m)),G.pow(G.div(q(2),s),m));
const rawRoots={};
for(const field of ['F','U'])for(let r=0;r<=10;r++)for(let m=0;m+r<=10;m++){
  let node;
  if(r<2){
    const etaActual=etaFactor(m,actual.strip);
    const collar=G.mul(actual.solutionNorm,etaActual,r?G.sqrt(Lambda):G.one);
    const core=G.mul(q(factorial(r)),G.pow(Lambda,r),etaFactor(m,auxiliary.strip),auxiliary.solutionNorm);
    node=max([collar,core]);
  }else{
    const receipt=n.radialAudit.find(j=>j.order===4&&j.field===field&&j.radialOrder===r&&j.etaOrder===m);
    assert.ok(receipt&&!receipt.collarAnalyticityAssumed);
    node=receipt.collar;
  }
  rawRoots[field+'_'+r+'_'+m]=node;
}
// The ordinary <=10 derivatives of sqrt(2X) on Xa/2<=X<=Xkeep
// are bounded by 2*r!*(Xa/2)^(-r) since Xkeep<1 and Xa>0.
const rawMax=max(Object.values(rawRoots));
const profileScale=G.mul(q(2n*factorial(10)*(1n<<10n)),G.pow(G.maximum(G.one,G.div(q(2),Xa)),10));
const scaledProfile=G.mul(profileScale,rawMax);
const roots={rawMax,profileScale,scaledProfile,actualNorm:actual.solutionNorm,auxNorm:auxiliary.solutionNorm,
  actualC:actual.C,auxC:auxiliary.C,actualStrip:actual.strip,auxStrip:auxiliary.strip,
  Xkeep,Xcut,t1:G.parameter('t1'),X0,One:G.one};
const trace=traceExactArithmeticDependencies(G,roots,{maxNodes:1000000});
assert.equal(trace.nonArithmeticBoundaries.length,0);
console.log('analytic arithmetic trace', trace.nodes.length,trace.sourceParameters);
await writeFile(output,JSON.stringify({trace,originalNodes,originalPrefix,actualSystem:n4.raw.system,auxiliarySystem:n4.auxiliary.system,rawRoots,derivativeOrder:10,priorProducerSHA256:"8a8617a889aeb4196dc826d9f2a3e17d99283651cc4b823e82995bd29d4b7553",sourceProfile:prepared.program.parameterExpressionSHA256})+String.fromCharCode(10),{flag:'wx'});

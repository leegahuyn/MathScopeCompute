"""Recompute exact cutoff factor bounds through ordinary slow order ten."""

from hashlib import sha256
from math import comb, factorial
from pathlib import Path
import json
import sys


def pinned(path, expected):
    data = path.read_bytes()
    assert sha256(data).hexdigest() == expected, path
    return data


def derivatives(order):
    polynomials = [{0: 1}]
    for _ in range(order):
        current = {}
        for power, coeff in polynomials[-1].items():
            if power:
                current[power + 1] = current.get(power + 1, 0) - power * coeff
            current[power + 2] = current.get(power + 2, 0) + coeff
        polynomials.append({power: coeff for power, coeff in current.items() if coeff})

    bounded = [sum(abs(c) * 2**i for i, c in p.items()) for p in polynomials]
    flat = [sum(abs(c) * 2**i * factorial(i) for i, c in p.items()) for p in polynomials]
    reciprocal = [9]
    for j in range(1, order + 1):
        reciprocal.append(
            9 * sum(comb(j, i) * (bounded[i] + flat[i]) * reciprocal[j-i]
                    for i in range(1, j+1))
        )
    ordinary = [
        2**j * sum(comb(j, i) * flat[i] * reciprocal[j-i] for i in range(j+1))
        for j in range(order + 1)
    ]
    stirling = [[1]]
    for j in range(1, order + 1):
        row = stirling[-1]
        stirling.append([
            (row[i-1] if i else 0) + (i * row[i] if i < len(row) else 0)
            for i in range(j+1)
        ])
    euler = [sum(c*d for c, d in zip(row, ordinary)) for row in stirling]
    weighted = [sum(comb(j, i) * euler[i] for i in range(j+1)) for j in range(order+1)]
    return ordinary, euler, weighted


def main():
    if not __debug__:raise RuntimeError("Keep exact assertions enabled.")
    work, source, output = map(Path, sys.argv[1:])
    one_cell = pinned(work / "whole-k-prefix/n4-single-frozen-cell.json",
                      "bb1ae130e327d5ad3f1fbdc7bf7686f9ca7f67a872ca07f9129de8ff1d55d078")
    baseline = pinned(work / "whole-k-prefix/n4-frozen-cutoff-flat-bound.json",
                      "505015fb4e39793749e696d0b8f1f4ead4d671230c6addf246c9d76aee4ba221")
    band = pinned(source / "research-ide/mathscope-m3/navier/source-global-band.mjs",
                  "babe4aceb97d0bdee4084e5f06009e6724128935fffde1647c11e3aab022df60")
    proof = json.loads(one_cell)
    assert proof["notation"]["w"] == "3/(4*S)"
    assert proof["notation"]["S"] == "L^6"
    assert proof["checked"]["strictRepresentativeLower"] == "sRep>1-w/2+w^2/16"
    assert "1<sUpper<1+w" in proof["exactCriterion"]["preconditions"]
    assert b"b=G.exp(G.neg(G.inv(G.sub(G.one,z))))" in band
    assert b"body=G.choose(x,G.q(1,2),G.one,G.one,G.div(b,G.add(a,b)),G.zero)" in band
    assert b"powerQ=power(q0,G.mul(q(2*n),h))" in band
    ordinary, euler, weighted = derivatives(10)
    audited = json.loads(baseline)
    assert ordinary[:7] == list(map(int, audited["ordinaryDerivativeIntegers"]))
    assert euler[:7] == list(map(int, audited["eulerDerivativeIntegers"]))
    assert max(weighted) < 2**128
    evidence = {
        "schema": "MathScope.N7.ActualExceptionalN4CutoffEuler10Bounds/1",
        "originalOneCell": sha256(one_cell).hexdigest(),
        "originalCutoff": sha256(band).hexdigest(),
        "originalOrderSix": sha256(baseline).hexdigest(),
        "priorOrderEightProducerSHA256": "f87fce36796951a37e296ad3911d8003e5b85c1d0f93c62ef91e2d80f6d48847",
        "derivativeOrder":10,
        "maximumWeightedIntegerBits":max(weighted).bit_length(),
        "ordinary": list(map(str, ordinary)),
        "euler": list(map(str, euler)),
        "weightedEuler": list(map(str, weighted)),
        "weight": "q^(8h) chi(b4 q), 0 < h < 1/64, 0 < q < 1",
        "bound": "All Euler derivatives through ten are below 2^128 q^(8h) exp(-2 L^6 / 3) at an active exceptional frozen representative, L=ellMinimum+16.",
        "geometry": "Xrep/Xa<(1+w)/(1-w/2+w^2/16)<1+2w for w=3/(4 L^6)<=1/4. If L^6>96/t1, then Xrep<Xkeep=Xa exp(t1/64).",
        "allPath": False,
    }
    with output.open("x", encoding="utf-8", newline="\n") as file:
        json.dump(evidence, file, indent=2)
        file.write("\n")
    print("PASS original exceptional frozen n4 Euler cutoff through10, max integer bits",max(weighted).bit_length())


if __name__ == "__main__":
    main()

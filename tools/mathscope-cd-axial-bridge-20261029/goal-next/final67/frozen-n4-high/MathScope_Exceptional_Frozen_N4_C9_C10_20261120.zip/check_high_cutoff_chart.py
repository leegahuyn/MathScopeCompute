"""Check exact order9/10 cutoff and pointwise chart logarithmic budgets."""
from argparse import ArgumentParser
from hashlib import sha256
from math import comb
from pathlib import Path
import json
if not __debug__:raise RuntimeError('Keep exact assertions enabled.')
def translated(poly,shift):
 return [sum(c*comb(i,j)*shift**(i-j) for i,c in enumerate(poly) if i>=j) for j in range(len(poly))]
def main():
 p=ArgumentParser(description=__doc__);p.add_argument('goal',type=Path);p.add_argument('directory',type=Path);a=p.parse_args()
 path=a.goal/'primary-forced-join/active-n3-c5-binding/norm-leading/slow-chart-majorant.json'
 b=path.read_bytes();assert sha256(b).hexdigest()=='f15c6f354276be183238c3d829c335b71e33d3d08f28a0fae49ca17e46d35eb5'
 old=json.loads(b);assert old['coefficientAtomBound']=={'powerOfTwo':156,'powerOfH':13}
 flatbytes=(a.directory/'flat-high.json').read_bytes();flat=json.loads(flatbytes)
 assert flat['derivativeOrder']==10 and len(flat['weightedEuler'])==11
 assert max(map(int,flat['weightedEuler']))<2**128 and flat['maximumWeightedIntegerBits']==106
 rows=[]
 for m in (9,10):
  power2=156+170*m;powerH=13*(m+1);count=(m+1)*(m+2)*(m+3)//6
  reserve=next(k for k in range(30) if 4*count<2**k)
  constant=power2+reserve
  assert all(c>0 for c in translated([-constant,-powerH,1],4096))
  rows.append({'derivativeOrder':m,'coefficientPointwisePowerOfTwo':power2,'coefficientPointwisePowerOfH':powerH,
   'maximumProfileTerms':count,'factorFourReserveBits':reserve,'logChartCostUpper':str(constant)+'+'+str(powerH)+'*L',
   'strictChartLogBudget':'<L^2 for L>=4096'})
 assert all(c>0 for c in translated([-384,-3,-3,0,0,0,1],4096))
 out={'schema':'MathScope.ExceptionalFrozenN4HighCutoffChartBudget/1','status':'PASS_EXACT_CUTOFF_10_AND_POINTWISE_CHART_9_10_BUDGET',
  'cutoffSHA256':sha256(flatbytes).hexdigest(),'priorChartProofSHA256':sha256(b).hexdigest(),'rows':rows,
  'proof':'The original chart atom seminorm through11 bounds every pointwise coefficient through10 via the unchanged recurrence:2^(156+170m)*Hchart^(13(m+1)). No higher FTC faces are inferred. Under the original threshold Hchart<L, the exact profile inventory times factor4 has log<L^2. Combine source cutoff through10, raw profile log<L and L>=4096 to obtain -2L^6/3+L^2+L+128<-L^6/3.',
  'remainingRawPremise':'The actual original scaled raw collar C10 must independently have relative rank(2,e), e<3*16384, with all finite atoms/frequency bounds authenticated. The C8 raw trace does not provide C9/10.',
  'scope':'Cutoff and pointwise chart budget only until the new original raw C10 trace/rank is attached. No all-path, first-three C10, full background or final gate promotion.'}
 (a.directory/'high-cutoff-chart.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
 print('PASS cutoff10 and pointwise chart9/10 budgets; raw-high premise explicit')
if __name__=='__main__':main()


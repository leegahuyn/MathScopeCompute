"""Reduce the original raw n4 collar bound to positive arithmetic relative to Bnorm."""

from hashlib import sha256
from fractions import Fraction
from pathlib import Path
import json
import sys


ANCHORS = (117782, 118573)
SPECIAL = 216322
DENOMINATOR = 16384
POSITIVE_ARITHMETIC = {"add", "multiply", "maximum", "sqrt_positive", "exp"}


def dependencies(nodes, roots, stop=frozenset()):
    found = set()
    remaining = list(roots)
    while remaining:
        node_id = remaining.pop()
        if node_id in found:
            continue
        found.add(node_id)
        if node_id in stop:
            continue
        op, args = nodes[node_id]["op"], nodes[node_id]["args"]
        if op in POSITIVE_ARITHMETIC | {"inverse", "log_positive"}:
            remaining.extend(args)
        elif op == "integer_power":
            remaining.append(args[0])
        else:
            assert op in {"rational", "source_parameter"}, (node_id, op)
    return found


def main():
    if not __debug__:raise RuntimeError("Keep exact assertions enabled.")
    trace_path, output = map(Path, sys.argv[1:])
    raw = trace_path.read_bytes()
    packet = json.loads(raw)
    assert packet["derivativeOrder"]==10
    assert packet["originalPrefix"]=="33217959a1883f5a44e10e7ddd8417ba4b0757b0a4c1c14236e0c8d48a01a6b3"
    trace = packet["trace"]
    nodes = {item["id"]: item["node"] for item in trace["nodes"]}
    root = trace["roots"]["scaledProfile"]
    required = dependencies(nodes, [root], frozenset((*ANCHORS, SPECIAL)))
    # Track exact structural dependence on the two positive Picard M2 caps.
    rank = {}
    independents = set()
    fan_in = 2
    for i in sorted(required):
        op, args = nodes[i]["op"], nodes[i]["args"]
        if i == SPECIAL:
            assert op == "exp"
            rank[i] = (2, DENOMINATOR)
            continue
        if i in ANCHORS:
            assert op == "exp"
            rank[i] = (0, DENOMINATOR)
            continue
        children = args if op in POSITIVE_ARITHMETIC | {"inverse", "log_positive"} else args[:1] if op == "integer_power" else []
        if not any(j in rank for j in children):
            continue
        cut = {j for j in children if j not in rank}
        independents.update(cut)
        provided = [rank.get(j, (0, 1)) for j in children]
        assert op in POSITIVE_ARITHMETIC or op == "integer_power", (i, op, args)
        depth = max(d for d, _ in provided)
        exponent = max(e for d, e in provided if d == depth)
        fan_in = max(fan_in, len(provided))
        if op == "add":
            rank[i] = depth, exponent+1
        elif op == "multiply":
            rank[i] = (depth, exponent+1) if depth else (0, sum(e for _, e in provided))
        elif op == "integer_power":
            assert args[1] > 0
            fan_in = max(fan_in, args[1])
            rank[i] = (depth, exponent+1) if depth else (0, exponent*args[1])
        elif op == "exp":
            rank[i] = depth+1, exponent
        else:
            assert op in {"maximum", "sqrt_positive"}
            rank[i] = depth, exponent

    max_exponent = max(e for _, e in rank.values())
    assert max_exponent < 2**128

    # Expand the independent part into arithmetic with nonnegative integer
    # powers. Inverses, logarithms, exponentials and source parameters are
    # bound as entire signed-magnitude atoms by the separate directed check.
    deg = {}
    atoms = set()
    expanded = dependencies(nodes, independents)
    assert not expanded.intersection((*ANCHORS, SPECIAL))
    stack = list(independents)
    expand = set()
    while stack:
        i = stack.pop()
        if i in expand:
            continue
        expand.add(i)
        op, args = nodes[i]["op"], nodes[i]["args"]
        if op in {"add", "multiply", "maximum", "sqrt_positive"}:
            stack.extend(args)
        elif op == "integer_power" and args[1] >= 0:
            stack.append(args[0])
        else:
            atoms.add(i)
    for i in sorted(expand):
        op, args = nodes[i]["op"], nodes[i]["args"]
        if i in atoms:
            deg[i] = 1
        elif op == "integer_power":
            deg[i] = deg[args[0]]*args[1]
        elif op == "multiply":
            deg[i] = sum(deg[j] for j in args)
        else:
            fan_in = max(fan_in, len(args))
            deg[i] = max(deg[j] for j in args)+(op == "add")
    degree = max(deg[i] for i in independents)
    exact_atoms = {i for i in atoms if nodes[i]["op"] == "rational"}
    max_exact = max(abs(Fraction(*map(int, nodes[i]["args"]))) for i in exact_atoms)
    real_atoms = sorted(atoms-exact_atoms)
    closure = dependencies(nodes, [*real_atoms,*ANCHORS])
    receipt = {
        "schema": "MathScope.N7.RawExceptionalN4HighRelativeRank/1",
        "derivativeOrder":10,
        "priorMethodSHA256":"83bce8815625140e63618d7b4b7d836f2947a5018245a7bd38b23999e0427bcd",
        "rawTraceSHA256": sha256(raw).hexdigest(),
        "root":root, "rank":rank[root],
        "denominator":DENOMINATOR, "anchors":list(ANCHORS),
        "largestRankExponent":str(max_exponent), "relativeNodes":len(rank), "separateFiniteFrequencyAtom":SPECIAL,
        "cutCount":len(independents), "polynomialDegree":str(degree),
        "atomCount":len(real_atoms), "rationalAtomCount":len(exact_atoms),
        "maxRationalBitLength":max(max_exact.numerator.bit_length(),fan_in.bit_length()),
        "fanInAndPowerCap":fan_in,
        "atomExponentDenominator":str(degree*DENOMINATOR),
        "atoms":real_atoms,
        "trace": {
            **trace,
            "roots": {**{f"atom_{i}":i for i in real_atoms}, **{f"anchor_{i}":i for i in ANCHORS}},
            "nodes":[{"id":i,"node":nodes[i]} for i in sorted(closure)],
        },
    }
    print("rank",rank[root], "cuts",len(independents), "degree",degree, "atoms",len(real_atoms),"arithmetic",len(closure))
    with output.open("x", encoding="utf-8", newline="\n") as file:
        json.dump(receipt,file,separators=(",",":"))
        file.write("\n")


if __name__ == "__main__":
    main()

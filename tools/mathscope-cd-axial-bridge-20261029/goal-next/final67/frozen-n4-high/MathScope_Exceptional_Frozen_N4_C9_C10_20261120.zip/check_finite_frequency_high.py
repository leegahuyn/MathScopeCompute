"""Check the single original finite-frequency upper used by the raw n4 bound."""

from hashlib import sha256
from pathlib import Path
from runpy import run_path
from importlib.util import spec_from_file_location,module_from_spec
import ast
import json
import sys


def main():
    if not __debug__:raise RuntimeError("Keep exact assertions enabled.")
    trace_path, prior_checker, output = map(Path, sys.argv[1:])
    trace_bytes = trace_path.read_bytes()
    packet = json.loads(trace_bytes)
    raw = prior_checker.read_bytes()
    assert sha256(raw).hexdigest() == "95c64384832784fa6f8bdfed94ff6b0c44e24b001b131fd058fd8e80ca5b0bd1"
    core=Path(__file__).with_name('frequency_rank_core.py')
    original=ast.parse(raw);changed=ast.parse(core.read_bytes())
    names=['node_table','children','dependencies','rational_rank','frequency_operand_ranks']
    for name in names:
        old=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name==name)
        new=next(n for n in changed.body if isinstance(n,ast.FunctionDef) and n.name==name)
        if name=='frequency_operand_ranks':
            class ExtendFinalGuard(ast.NodeTransformer):
                def visit_Assert(self,node):
                    if '16 * DEN' in ast.unparse(node):
                        class Limit(ast.NodeTransformer):
                            def visit_Constant(self,item):
                                return ast.copy_location(ast.Constant(value=18),item) if item.value==16 else item
                        node=Limit().visit(node)
                    return node
            old=ExtendFinalGuard().visit(old)
        assert ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False),name
    spec=spec_from_file_location('frequency_core',core);module=module_from_spec(spec);spec.loader.exec_module(module)
    prior=vars(module)
    nodes = prior["node_table"](packet["trace"])
    assert nodes[216322] == ("exp", [216321])
    assert nodes[216321] == ("multiply", [7960,216320])
    assert nodes[7960] == ("inverse", [6259])
    assert nodes[6259] == ("source_parameter", ["radialFrequencyN"])
    assert nodes[216320] == ("multiply", [216317,216319])
    assert nodes[216319] == ("integer_power", [216318,74])
    assert nodes[216318] == ("add", [1,6259])
    assert nodes[1] == ("rational", ["1","1"])
    ranks, checked = prior["frequency_operand_ranks"](nodes,[216317])
    assert ranks["216317"][0] == 2
    assert ranks["216317"] == [2,8705]
    assert ranks["216317"][1] < 18*512 < 256*512
    assert 51 * 74 + 1 < 4096
    result = {
        "schema": "MathScope.N7.RawExceptionalN4HighFiniteFrequencyRank/1",
        "priorSourceMethodSHA256":"2675cb122c3b7e86f839c578a92cb037b24770ec44a37eb20b658c07f691d891",
        "rawTraceSHA256": sha256(trace_bytes).hexdigest(),
        "priorMethodSHA256": sha256(raw).hexdigest(),
        "atom":216322,"A":216317,"N":6259,"degree":74,
        "A_ranks":ranks,"checkedRawOperands":checked,
        "explicitGuardExtension":"Original exponent16 guard fails for A rank8705/512. Its exact recurrence is unchanged; exponent18 is sufficient and18<256 closes the same source frequency bound.",
        "coreSHA256":sha256(core.read_bytes()).hexdigest(),
        "inequality": "With S=CSelected^100000 and R=exp(S^256), the exact operand rank gives |A|<exp(exp(S^18))<exp(R). N=1+ceil(R^50) and 1+N<R^51 give |(1+N)^74 A/N|<R^3774 exp(R) <= exp(Bnorm), by Bnorm>=R^4096. Thus atom #216322<exp(exp(Bnorm)).",
    }
    with output.open("x",encoding="utf-8",newline="\n") as file:
        json.dump(result,file,indent=2)
        file.write("\n")
    print(ranks,checked)


if __name__ == "__main__":
    main()

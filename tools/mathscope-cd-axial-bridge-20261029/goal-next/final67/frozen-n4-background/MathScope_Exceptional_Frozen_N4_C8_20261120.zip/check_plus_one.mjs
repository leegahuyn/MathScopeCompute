import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [g,w,o]=process.argv.slice(2).map(t=>resolve(t));
const sha=x=>createHash('sha256').update(x).digest('hex');
const read=async(path,pin)=>{
  const bytes=await readFile(path);
  assert.equal(sha(bytes),pin,path);
  return JSON.parse(bytes);
};
const live=await read(resolve(w,'continuation61/c8-slab/final/c8-slab.json'),
  'e26c62baf924c4209bbac2ebd944bd17a992bfe4599fd1a8fab2cb8c91d7c02b');
const chart=await read(resolve(w,'continuation37/slow-chart-majorant.json'),
  'f15c6f354276be183238c3d829c335b71e33d3d08f28a0fae49ca17e46d35eb5');
const th=await read(resolve(g,'whole-k-selector-scales/historical-scale-arithmetic-result.json'),
  'af666a28520316043b00cacbf0cda14e624f419b857e6b3063ab6fdd6ae8afaf');
assert.equal(chart.faceBound,'Each original nonconstant slow-chart coefficient FTC sum lies in [0,2^1521 H^119].');
const positiveCount=Math.max(...live.literalRows.map(row=>row.positiveCount));
assert.equal(positiveCount,165);
const {sourceArithmetic}=await import(pathToFileURL(resolve(g,'whole-k-annular-initial/numerical/source_arithmetic.mjs')).href);
const {N}=await sourceArithmetic(resolve(w,'annular-numeric-24/pinned-original-runtime'),th.sourcePins,'coarse-upper');
const common=live.localBudget.find(row=>row.which==='common physical slab with three active terms');
assert.ok(common);
const op=N.fromClosed({lower:{rational:'0'},upper:common.unweightedLocalMax.upper});
const doubled=N.toClosed(N.mul(N.point('2'),op));
const firstThreePlusOne=N.toClosed(N.add(N.point('1'),op));
const gates=Object.fromEntries(Object.entries(live.gates).map(([k,v])=>[
  k,{doubled:N.compareEndpoints(doubled.upper,v.lower),
     plusOne:N.compareEndpoints(firstThreePlusOne.upper,v.lower)}]));
assert.equal(gates.smallGrowth128.plusOne,-1);
const result={schema:'MathScope.N7.RawExceptionalN4FrozenSuccessorBudget/1',
  scope:'Independent numerical check of the first-three unweighted envelope plus one. This is conditional on a separate uniform unit upper on the actual fourth correction.',
  maximumChartCoefficientCount:positiveCount,doubled,firstThreePlusOne,gates};
await writeFile(o,JSON.stringify(result,null,2)+String.fromCharCode(10),{flag:'wx'});
console.log(gates);

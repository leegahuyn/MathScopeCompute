"""Check the single original finite-frequency upper used by the raw n4 bound."""

from hashlib import sha256
from pathlib import Path
from runpy import run_path
import json
import sys


def main():
    trace_path, prior_checker, output = map(Path, sys.argv[1:])
    trace_bytes = trace_path.read_bytes()
    packet = json.loads(trace_bytes)
    raw = prior_checker.read_bytes()
    assert sha256(raw).hexdigest() == "95c64384832784fa6f8bdfed94ff6b0c44e24b001b131fd058fd8e80ca5b0bd1"
    prior = run_path(str(prior_checker))
    nodes = prior["node_table"](packet["trace"])
    assert nodes[203229] == ("exp", [203228])
    assert nodes[203228] == ("multiply", [7960,203227])
    assert nodes[7960] == ("inverse", [6259])
    assert nodes[6259] == ("source_parameter", ["radialFrequencyN"])
    assert nodes[203227] == ("multiply", [203224,203226])
    assert nodes[203226] == ("integer_power", [203225,68])
    assert nodes[203225] == ("add", [1,6259])
    assert nodes[1] == ("rational", ["1","1"])
    ranks, checked = prior["frequency_operand_ranks"](nodes,[203224])
    assert ranks["203224"][0] == 2
    assert ranks["203224"][1] < 8192
    assert 51 * 68 + 1 < 4096
    result = {
        "schema": "MathScope.N7.RawExceptionalN4FiniteFrequencyRank/1",
        "rawTraceSHA256": sha256(trace_bytes).hexdigest(),
        "priorMethodSHA256": sha256(raw).hexdigest(),
        "atom":203229,"A":203224,"N":6259,"degree":68,
        "A_ranks":ranks,"checkedRawOperands":checked,
        "inequality": "With S=CSelected^100000 and R=exp(S^256), the exact operand rank gives |A|<exp(exp(S^16))<exp(R). N=1+ceil(R^50) and 1+N<R^51 give |(1+N)^68 A/N|<R^3468 exp(R) <= exp(Bnorm), by Bnorm>=R^4096. Thus atom #203229<exp(exp(Bnorm)).",
    }
    with output.open("x",encoding="utf-8",newline="\n") as file:
        json.dump(result,file,indent=2)
        file.write("\n")
    print(ranks,checked)


if __name__ == "__main__":
    main()

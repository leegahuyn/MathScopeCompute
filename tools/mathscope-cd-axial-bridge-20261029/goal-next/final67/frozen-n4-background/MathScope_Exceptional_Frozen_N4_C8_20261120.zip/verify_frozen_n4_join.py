"""Check the frozen C8 arithmetic join while preserving source proof scope."""

from hashlib import sha256
from pathlib import Path
import json
import sys


def main():
    root, goal, output = map(Path, sys.argv[1:])
    def read(name, parent=root, expected=None):
        data = (parent/name).read_bytes()
        pin = sha256(data).hexdigest()
        if expected is not None:
            assert pin == expected, name
        return json.loads(data), pin
    raw, raw_pin = read("raw-trace.json")
    binding, binding_pin = read("hosted-binding.json")
    assert binding["rawTraceSHA256"] == raw_pin
    assert binding["fullGraphNodes"] == 7358162
    assert binding["identicalOriginalPrefixNodes"] == 127241
    rank, rank_pin = read("relative-separated.json")
    assert rank["rawTraceSHA256"] == raw_pin
    frequency, frequency_pin = read("frequency.json")
    assert frequency["rawTraceSHA256"] == raw_pin
    assert rank["separateFiniteFrequencyAtom"] == frequency["atom"] == 203229
    assert frequency["A_ranks"]["203224"] == [2,7394]
    assert rank["rank"] == [2,33040] and rank["rank"][1] < 3*rank["denominator"]
    assert int(rank["largestRankExponent"]) < 2**128
    atoms, atoms_pin = read("relative-final.json")
    assert atoms["packetSHA"] == rank_pin
    assert len(atoms["rows"]) == rank["atomCount"] == 78
    assert [r["nodeId"] for r in atoms["rows"]] == rank["atoms"]
    assert all(r["status"] == "BELOW" and r["compared"] == -1 for r in atoms["rows"])
    assert atoms["factual"] == {"finiteCap":-1,"actualRadialGap":-1}
    assert rank["maxRationalBitLength"] >= 1024
    geometry, geometry_pin = read(
        "whole-k-selector-scales/fourth/fourth-selector-maxima.json",goal,
        "5a6ecee45d797d582e3218c36f980d5eb131619c860cec1bfb4d57aea89cdf56"
    )
    assert geometry["exactRatios"]["b4*qBig"] == 64
    assert geometry["threshold"]["M2Anchors"] == binding["anchors"] == rank["anchors"]
    assert geometry["threshold"]["positiveFactorPathChecked"]
    flat, flat_pin = read("flat-8.json")
    assert len(flat["weightedEuler"]) == 9 and max(map(int, flat["weightedEuler"])) < 2**128
    successor, successor_pin = read("plus-one.json")
    assert successor["maximumChartCoefficientCount"] == 165
    assert all(r["plusOne"] == -1 for r in successor["gates"].values())
    assert 4*165 < 2**10
    # For all real L>=4096 these differences have positive coefficients
    # after translating L by 4096. This proves the stated logarithmic
    # budget following log L<=L, log 2<1 and H<L.
    from math import comb
    def translated_coefficients(poly, shift):
        return [sum(c*comb(i,j)*shift**(i-j) for i,c in enumerate(poly) if i>=j)
                for j in range(len(poly))]
    assert all(c>0 for c in translated_coefficients([-1531,-119,1],4096))
    assert all(c>0 for c in translated_coefficients([-384,-3,-3,0,0,0,1],4096))
    result = {
        "schema": "MathScope.N7.ExceptionalFrozenRawN4C8Bridge/1",
        "interpretation": "Original total-order <=8 ordinary slow F/G at selected frozen representative of the original N3/N4 cover. Verify the finite arithmetic inputs independently; condition source application on original Picard, Cauchy and radial-derivative norm premises.",
        "rawSourceTraceSHA256":raw_pin,"hostedBindingSHA256":binding_pin,
        "arithmeticRankSHA256":rank_pin,"finiteFrequencySHA256":frequency_pin,
        "directedAtomComparisonSHA256":atoms_pin,"timeCutoffOrderEightSHA256":flat_pin,
        "successorGateSHA256":successor_pin,"originalSelectorSHA256":geometry_pin,
        "arithmetic": "All 78 atoms below max(M2actual,M2aux)^(1/(D*16384)); the single frequency atom < exp(exp(Bnorm)); scaled raw C8 has rank (2,33040/16384) on Bnorm.",
        "chartDomain": "The original positive fourth representative lies in Xa<Xrep<Xkeep. Its qrep is positive and <1; ordinary slow derivatives hold Q fixed. At the cutoff endpoint the n4 jets are exactly zero.",
        "exceptionalFourthBound": "Each original normalized slow F/G order<=8 derivative of the n4 summand is bounded by exp(-L^6/3)<1 with L=ellMinimum+16.",
        "localBackgroundBudget": "Use the authenticated unweighted first three terms on the frozen chart and add one. The directed upper stays below exp(H/2^128)/(64 Xb^2); H=-h log(tau0).",
        "scope": "Full frozen F/G background at original representatives. Remaining original operator-region transport, radial/pressure inputs, analytic-source premises and N7/N8 closure are separate.",
        "M3": "62/64",
        "finalJets": "0/67",
        "release": "HOLD",
    }
    with output.open("x",encoding="utf-8",newline="\n") as file:
        json.dump(result,file,indent=2)
        file.write("\n")
    print("PASS original raw n4 bound and strict frozen successor background gate")


if __name__ == "__main__":
    main()

import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [g,w,p,o,mode] = process.argv.slice(2);
const goal=resolve(g),work=resolve(w);
const dir=resolve(work,'annular-numeric-24/pinned-original-runtime');
const historicalPath=resolve(work,'whole-k-prefix/historical-scale-arithmetic-input.json');
const sha=x=>createHash('sha256').update(x).digest('hex');
async function load(path,pin){
  const raw=await readFile(path);
  const digest=sha(raw);
  if(pin)assert.equal(digest,pin);
  return [JSON.parse(raw),digest];
}
const [packet,packetSHA]=await load(p);
const [history,historicalSHA]=await load(historicalPath,'03806ccc21ae6f759d0f5908d9eaabb24e3972aaedd530d43aea8ade522fa3f0');
const [thresholds,thresholdSHA]=await load(resolve(goal,'whole-k-selector-scales/historical-scale-arithmetic-result.json'),
  'af666a28520316043b00cacbf0cda14e624f419b857e6b3063ab6fdd6ae8afaf');
const {sourceArithmetic}=await import(pathToFileURL(resolve(goal,'whole-k-annular-initial/numerical/source_arithmetic.mjs')).href);
const {N,evaluateClosedArithmeticDefinitions,tracedArithmeticEvaluator}=await sourceArithmetic(dir,thresholds.sourcePins,mode);
const {trace,anchors,atoms}=packet;
const params=evaluateClosedArithmeticDefinitions(history.definitions,N,{names:trace.sourceParameters}).values;
const ev=tracedArithmeticEvaluator(trace,N,{parameters:params});
const M=N.max(anchors.map(i=>ev.value(i)));
const pt=x=>N.point(String(x)), cmp=(a,b)=>N.compareEndpoints(a,b), closed=n=>N.toClosed(n);
const atomCap=closed(N.exp(N.mul(N.log(M),pt('1/'+packet.atomExponentDenominator))));
const finiteCap=closed(N.pow(pt('2'),packet.maxRationalBitLength));
const rows=[];
for(const nodeId of atoms){
  try{
    const n=ev.value(nodeId), magnitude=closed(N.max([n,N.neg(n)]));
    const compared=cmp(magnitude.upper,atomCap.lower);
    rows.push({nodeId,status:compared<0?'BELOW':'UNSEPARATED',compared,upper:magnitude.upper});
  }catch(error){rows.push({nodeId,status:'ERROR',detail:error.message});}
}
const ell= N.fromClosed(history.archivedEllMinimumInterval);
const t1Inv=closed(N.mul(pt(96),N.inverse(params.get('t1'))));
const ell6=closed(N.pow(ell,6));
const factual={finiteCap:cmp(finiteCap.upper,atomCap.lower),actualRadialGap:cmp(t1Inv.upper,ell6.lower)};
const receipt={schema:'MathScope.N7.RawExceptionalN4RelativeAtomsDirected/1',packetSHA,historicalSHA,thresholdSHA,mode:mode??'original',
  atomCap,finiteCap,ell6,t1Inv,factual,rows,trace:ev.report()};
await writeFile(o,JSON.stringify(receipt,null,2)+String.fromCharCode(10),{flag:'wx'});
console.log(factual,rows.filter(row=>row.status!=='BELOW').map(x=>[x.nodeId,x.status,x.detail]));

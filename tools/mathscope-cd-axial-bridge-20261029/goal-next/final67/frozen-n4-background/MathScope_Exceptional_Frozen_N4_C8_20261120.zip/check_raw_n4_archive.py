"""Authenticate the raw n4 prefix against the complete N4 hosted export."""

import gzip
from hashlib import sha256
from pathlib import Path
import json
import sys


def main():
    source, trace_path, output = map(Path, sys.argv[1:])
    trace_bytes = trace_path.read_bytes()
    local = json.loads(trace_bytes)
    prefix_count = local["originalNodes"]
    assert prefix_count == 127241
    graph_hash, prefix_hash = sha256(), sha256()
    prefix_hash.update(b"[")
    count = 0
    nodes = {}
    with gzip.open(source / "original-source-nodes.jsonl.gz", "rb") as stream:
        head = stream.readline()
        graph_hash.update(head)
        assert json.loads(head)["node_count"] == 7358162
        for index, row in enumerate(stream):
            graph_hash.update(row)
            if index < prefix_count:
                if index:
                    prefix_hash.update(b",")
                prefix_hash.update(row.rstrip(b"\r\n"))
                nodes[index] = json.loads(row)
            count += 1
    prefix_hash.update(b"]")
    assert graph_hash.hexdigest() == "ce3238938bd5ed7cd5f1d554eddf2f15e774928388fbc54a978c45fea99731bd"
    assert count == 7358162
    assert prefix_hash.hexdigest() == local["originalPrefix"]
    for row in local["trace"]["nodes"]:
        i = row["id"]
        if i < prefix_count:
            assert nodes[i] == row["node"], i
    registry_bytes = (source / "original-source-functions.json").read_bytes()
    assert sha256(registry_bytes).hexdigest() == "049b05929080b4c8a16a5e2c74a1d6f1ad51232fdfb90222d42ffb4f0bbb22ad"
    registry = json.loads(json.loads(registry_bytes)["base"]["picard"])
    real = registry[local["actualSystem"]]
    aux = registry[local["auxiliarySystem"]]
    assert local["actualSystem"] == 7 and local["auxiliarySystem"] == 6
    assert (real["tail"]["sourceBound"], real["solutionNorm"]) == (125092,125097)
    assert (aux["tail"]["sourceBound"], aux["solutionNorm"]) == (124023,124030)
    for anchor in [117782,118573]:
        assert nodes[anchor]["op"] == "exp"
        assert any(system["solutionNorm"] == anchor for system in registry)
    result = {
        "schema": "MathScope.N7.RawExceptionalN4OriginalArchiveBinding/1",
        "rawTraceSHA256": sha256(trace_bytes).hexdigest(),
        "hostedNodeStreamSHA256": graph_hash.hexdigest(),
        "hostedRegistrySHA256": sha256(registry_bytes).hexdigest(),
        "fullGraphNodes": count,
        "identicalOriginalPrefixNodes": prefix_count,
        "originalPrefixSHA256": prefix_hash.hexdigest(),
        "actualSystem": 7, "auxiliarySystem": 6, "anchors": [117782,118573],
        "sourceBound": 125092, "sourceSolutionNorm": 125097,
    }
    with output.open("x", encoding="utf-8", newline="\n") as file:
        json.dump(result,file,indent=2)
        file.write("\n")
    print("PASS hosted original N4 graph", count, "nodes, identical prefix", prefix_count)


if __name__ == "__main__":
    main()

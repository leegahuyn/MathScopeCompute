"""Verify original active Wrz transverse factorization and selected Z^6 T inverse bound."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from functools import cache
from hashlib import sha256
from pathlib import Path
import json

PINS = {
    'slab': '8152230d5531fd00bb0685fbcb380ad1b7a116d8833ee871d92803663aee19e9',
    'registry': '364425db9d5bbd317f8aaad681fdfdd3206f97e0f46d2beb78b6e7d5a30a3111',
    'prehaar': 'a749056e325accfb2582b6814c1e335cfbcdd46ec1bc8fb911c24e4741ae8ccc',
    'projection': '7172068a3e3a86bb40c04516eaa452d8cf668650b826ddfd7a64b5ee40971af4',
    'cover': '9da54bbb2bd959e097c8ef610eabaf8ef8b163e540c73169dd82fcdaa784bc69',
    'fourier': '12cc99ba7c3b47c88555e5eaca310fab7471d307e720c40340de78e104d9634d',
    'band.mjs': 'babe4aceb97d0bdee4084e5f06009e6724128935fffde1647c11e3aab022df60',
    'binding.mjs': 'dfa10931c2eee87344dff4c95ecbeaf84d21c5ea5891d6452ea1f5fd4a4d9501',
    'current.mjs': '93f86661d67e6bc7b916218cd7af3db72f348ba7fdc876e3618ba3a49edff760',
    'curl.mjs': '4276a850dbff4b5c357c47e1827eb7785b19c7e7c395c94ee4f22ef0c96d58d2',
}
XI, CHI, V = 17733037, 17733045, 17732751
POTENTIALS = {32033:17735323, 32034:17735324, 32035:17735325,
              32042:17738774, 32043:17738775, 32044:17738776}
BODIES = {1:(17737175,17737168), -1:(17740593,17740586)}


def shape(nodes, registry, c73):
    native = json.loads(registry['base']['base']['expression'])
    lookup = json.loads(registry['base']['fieldDefinitions'])
    field = lookup[2]
    assert c73['actualInitialMap']['application'] == 17753400
    assert c73['actualInitialMap']['derivativeYColumnEntries'] == 648
    assert c73['actualInitialMap']['rows'] == len(field['rows']) == 162
    assert field['directions'] == [17732748,17732749,17732750,17745430,17745431]
    for row in field['rows']:
        assert row['localParameters'][7:] == [XI,V]
        assert row['localBody'] == BODIES[row['label']['sign']][0]
        assert [[v['parameter'] for v in dm] for dm in row['derivativeMaps']]==[[0],[1],[2],[7,8],[7,8]]
    assert nodes[CHI] == ['smooth_piecewise',[17733040,847,120836,1,17733044,0]]
    assert nodes[17733044] == ['source_step_derivative',[17733043,0]]
    assert nodes[17733043] == ['add',[656,17733042]]
    assert nodes[17733042] == ['multiply',[20,17733041]]
    assert nodes[17733041] == ['multiply',[24,17733040]]
    assert nodes[17733040] == ['sqrt_positive',[17733039]]
    assert nodes[17733039] == ['integer_power',[17733038,2]]
    assert nodes[17733038] == ['multiply',[157470,XI]]
    def rat(i):
        op, arguments = nodes[i]
        assert op == 'rational'
        return Q(*map(int,arguments))
    assert [rat(i) for i in (847,120836,656,20,24,157470)] == [Q(1,4),Q(3,4),Q(3,2),-1,2,2**34]

    @cache
    def depends(i):
        if i <= XI:
            return i == XI
        op, args = nodes[i]
        if op in ('rational','coordinate','source_parameter'):
            return False
        if op == 'definite_integral':
            kids = args[2:] if args[1] == XI else [args[0],*args[2:]]
        elif op in ('integer_power','source_step_derivative'):
            kids = args[:1]
        elif op in ('actual_expression_partial','m3_aux_expression_partial','m3_aux_indexed_partial','m3_global_indexed_partial'):
            kids = args[1]
        elif op in ('actual_covariance_volterra','m3_global_pulse_jet'):
            kids = [args[2],*args[3]]
        elif op in ('actual_quadratic_root','actual_monotone_root'):
            kids = args[1] if isinstance(args[1],list) else args[1:]
        elif op in ('actual_background_picard','actual_background_even_profile'):
            kids = args[2:4]
        elif op == 'actual_natural_series':
            kids = args[1:3]
        else:
            assert op in ('add','multiply','inverse','sqrt_positive','log_positive','exp',
                          'ceiling','maximum','smooth_piecewise','sine','cosine'), (i,op,args)
            kids = args
        assert all(child<i for child in kids), (i,kids)
        return any(depends(k) for k in kids)

    potential_applications = set()
    @cache
    def monomials(i, allowed):
        if not depends(i):
            return frozenset([(0,0)])
        if i == CHI:
            return frozenset([(1,0)])
        op,args = nodes[i]
        if op == 'actual_expression_partial' and allowed:
            system, values, orders = args
            assert system in POTENTIALS and len(values)==len(orders)==12 and values[3]==XI
            assert all(j==3 or not depends(k) for j,k in enumerate(values))
            transverse = orders[3]
            assert transverse in (0,1)
            potential_applications.add(i)
            return frozenset([(1-transverse,transverse)])
        if op == 'add':
            return frozenset().union(*(monomials(k,allowed) for k in args))
        assert op == 'multiply', (i,op,args)
        result = {(0,0)}
        for child in args:
            result = {(u+x,v+y) for u,v in result for x,y in monomials(child,allowed)}
        return frozenset(result)

    for system, body in POTENTIALS.items():
        record = native[system]
        assert record['name'].startswith('GlobalOriginalPotential_')
        assert record['body']==body and record['parameters'][3]==XI and not record['unspecifiedOracle']
        assert monomials(body,False)=={(1,0)}, (system,body)
    guard_checks = {}
    for sign,(guarded,raw) in BODIES.items():
        cursor = guarded
        xi_guards, slow_guards = [],[]
        while nodes[cursor][0] == 'smooth_piecewise':
            x,left,right,zero,inside,other = nodes[cursor][1]
            assert zero == other == 0 and not depends(left) and not depends(right)
            if depends(x):
                assert x == XI and rat(left)==-Q(1,2**34) and rat(right)==Q(1,2**34)
                xi_guards.append(cursor)
            else:
                slow_guards.append(cursor)
            cursor = inside
        assert cursor == raw and len(xi_guards)==1 and len(slow_guards)==6
        assert monomials(raw,True)=={(2,0),(1,1)}, (sign,raw)
        guard_checks[sign] = {'guarded':guarded,'interior':raw,'xiGuard':xi_guards[0],
                              'otherGuardsIndependentOfXi':slow_guards}
    return {'cutoff':CHI, 'xi':XI, 'sourceCovariance':17753400, 'verifiedBodies':guard_checks,
            'nativePotentialBodies':POTENTIALS,'nativePotentialApplications':sorted(potential_applications),
            'transverseMonomials':['chi^2','chi*chi_prime'], 'chiPrimeSquaredTerm':False,
            'exactCommonYDerivation':'L xi=Lambda^d, L v=0; all original 0<=d<=4',
            'boundXiInTransverseMass':17733048, 'rows':162}


def bounds(old, cover, c73):
    cut = old['fixedCutoff']
    c0,c1,c2,c3 = cut['chiSup']
    assert c0==1
    b2 = 2*c1*c1 + 2*c2
    c2_product = 3*c1*c2 + c3
    assert b2 == cut['localChiSquareSecondSup'] and c2_product == cut['localChiChiPrimeSecondSup']
    assert cover['fixedLabelJacobian']=='L xi=Lambda^delta, N xi=0, L v=0, N v=Tg^delta/ci_label; 0<=delta<=4'
    assert c73['conditionalWeightedTransport']['halfGaussianPoleFactor']=='sqrt(zeta)*delta^-p <= 2^27 * 27! * t1^-54'
    # The seed logarithmic derivatives at 1/2 are +16 and -16.
    t = Q(1,2)
    sigma_mid = Q(1,2)
    sigma_prime_mid = sigma_mid*(1-sigma_mid)*(2/t**3+2/(1-t)**3)
    assert sigma_prime_mid==8
    r0 = Q(1,2**34)
    transition_coefficient = sigma_mid * (-2/r0) * sigma_prime_mid
    assert transition_coefficient == -(2**37)
    collocation = (1+sigma_mid**2)/abs(transition_coefficient)
    assert collocation == Q(5,2**39)
    # Columns (chi^2, chi*chi'); the plateau and transition separate them.
    det = transition_coefficient
    assert det and cut['localChiSquareSup']==1
    local = b2 + collocation*c2_product
    assert Q(7,5)**2 < 2 and 4-Q(7,5) == Q(13,5)
    after_cover = Q(13,5)**8 * local
    c_no = Q(old['fourier']['pointwiseL2Constant'])
    c_l2 = Q(old['fourier']['pointwiseL2TransverseSecondConstant'])
    assert (c_no,c_l2)==(Q(85,6),Q(85,216))
    for beta in [Q(1),Q(2)-Q(2,100000)]:
        exponent_low=Q(5)-(4+beta)*Q(1,64)
        assert 0<exponent_low<5
    rowcount, rho_cost = 162, 4**5
    inverse = rowcount*rho_cost*(c_no+c_l2*after_cover)
    assert inverse < 2**127
    assert 4*3813+127+2**13 < 2**15
    assert 1-Q(1,2**113)-Q(6,2**128) > 0
    return {
        'localCoordinatesHeld':['R','Z','T','ell','three mesh labels','v'],
        'sampleMatrix':[['1','0'],['1/4',str(transition_coefficient)]],
        'coefficientBounds':'If both collocation samples have absolute value <=M, then |B|<=M and |C|<=5*M/2^39.',
        'd2XiMultiplier':str(local),
        'd2LMultiplierPerRowBeforeBandScale':str(after_cover),
        'mixedOrder':[0,6,1,0,0],
        'onlyLocalMixedOrder':[0,6,1,0,0,0,0,0,0],
        'referenceScale':'rho^(2A+6D+1)=rho^(5-4h); including epsilon_label^beta it is rho^(5-(4+beta)h) epsilon_ref^beta',
        'commonBandFactorForEachBeta':rho_cost,
        'commonBoundMref':'Mref=zeta[(4 Khat S_ref)^2976 epsilon_ref delta_*^-44+(4 Khat S_ref)^3813 epsilon_ref^(2-2*kappa_s) delta_*^-54]',
        'fAndL2':'For f=D_Z^6 D_T Wrz, ||f||_2 <=162*1024*Mref and ||L^2 f||_2 <=162*1024*d2LMultiplierPerRowBeforeBandScale*Mref',
        'inverseMultiplier':str(inverse),
        'inverseMultiplierLog2Upper':127,
        'inverseNorm':'||N^-1 P_perp f||_infty < 2^127 Mref at positive Mref, and is zero when Mref=0',
        'pointwiseDirected':'||N^-1 P_perp f||_infty <= 2 sqrt(zeta) exp[(-1+2^-113+6/L)H] on the admitted atlas',
        'radialHighestAllocation':'If every shifted radial input stays in the admitted atlas and chi is the original unit-interval cutoff, the order-zero T1 N^-1 P_perp T0 operator costs at most 4*b*(b-a)^2/a times the radial supremum of the inverse cap, with a=sqrt(Xa), b=2 sqrt(Xb). The original ci^-1 remains outside the radial transfer.',
    }


def source_paths(workspace):
    local=workspace/'work/goal-next'
    goal=workspace/'work/MathScopeCompute-Continuation22/tools/mathscope-cd-axial-bridge-20261029/goal-next'
    rt=local/'continuation30/forced-probe/runtime/research-ide'
    return {
        'slab':local/'continuation73/prehaar-wrz/source-slab.json',
        'registry':local/'continuation34/hosted-43296617887-n3/witness/original-source-functions.json',
        'prehaar':local/'continuation73/prehaar-wrz/prehaar-wrz-final.json',
        'projection':local/'continuation74/time-inverse/temporal-projection.json',
        'cover':goal/'primary-forced-join/active-n3-c5-binding/mean-c4/common-w4/common-w4-weighted-v4.json',
        'fourier':goal/'whole-k-annular-wrz/transverse-wrz-bound.json',
        'band.mjs':rt/'mathscope-m3/navier/source-global-band.mjs',
        'binding.mjs':rt/'mathscope-m2/navier/actual-residual-order-induction-expressions.mjs',
        'current.mjs':rt/'mathscope-m3/navier/source-global-current.mjs',
        'curl.mjs':rt/'mathscope-m2/navier/actual-full-curl.mjs',
    }


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('workspace',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--bundle',action='store_true')
    args=parser.parse_args()
    pins=Path(__file__).resolve().parent/'pinned'
    paths=({name:pins/(name if name.endswith('.mjs') else name+'.json') for name in PINS}
           if args.bundle else source_paths(args.workspace))
    raw={name:p.read_bytes() for name,p in paths.items()}
    for name,content in raw.items():
        assert sha256(content).hexdigest()==PINS[name], name
    for source,clauses in {
        'band.mjs':['G.sqrt(G.pow(G.div(xi,r0),2))','G.step(G.sub(q(3,2),G.mul(q(2),a)))',
                    'G.integral(G.pow(chi,2),xi,G.neg(r0),r0)'],
        'binding.mjs':["this.freeCoordinates(body)].some(v=>!parameters.includes(v))",
                       'unspecifiedOracle:false'],
        'current.mjs':["G.mul(G.sqrt(band.geometry.epsilon),a,band.cutoffs.chi,band.cutoffs.psi,x)",
                       'curl.leading[a],curl.leading[b]','curl.remainder[a],curl.remainder[b]'],
        'curl.mjs':['G.neg(axialDerivatives[1])','G.add(radialDerivatives[1],G.mul(ir,C[1]))'],
    }.items():
        text=raw[source].decode('utf8')
        assert all(clause in text for clause in clauses), source
    slab=json.loads(raw['slab'])
    assert slab['verifiedSourceStream']=='831120617913e89c5bb60976fb26f58c6714decc301097a08f72ee23233e0a6a'
    c73=json.loads(raw['prehaar'])
    prior=json.loads(raw['projection'])
    assert 21374077 in prior['sourceIDs']['nonlinearGR'] and prior['sourceIDs']['Wrz']==17753400
    exact=shape({int(k):v for k,v in slab['nodes'].items()},json.loads(raw['registry']),c73)
    result={
        'status':'VERIFIED_ACTIVE_N3_WRZ_TRANSVERSE_SHAPE_CONDITIONAL_Z6T_INVERSE_BOUND',
        'pins':PINS,'actual':exact,'conditionalArithmetic':bounds(json.loads(raw['fourier']),json.loads(raw['cover']),c73),
        'additionalSlowDerivativesForAnisotropicPart':0,
        'remaining':['same actual N3/N4 live and frozen source-role admission at every original slow mapping and radial binder',
                     'other nonlinear factors, lower cutoff terms, complete radial transport and original ci^-1',
                     'later signed correction stages and actual final jets'],
        'finalJets':'0/67','release':'HOLD',
    }
    with args.output.open('x',encoding='utf8',newline='\n') as target:
        json.dump(result,target,indent=2)
        target.write('\n')
    print(result['status'])


if __name__=='__main__':
    main()

# 원문 대응표

기준 PDF: 첨부 `navier-stokes(20261016-015019).pdf`, 166쪽, 표제 *Finite Time Blowup for Navier–Stokes*, 저자 표기 OPENAI. SHA-256 `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`. 이번에는 외부 공식성·공개 최신판·학계 심사 상태를 확인하지 않았다.

|쪽 / 식·정리|이번 사용|실제 적용 범위|
|---|---|---|
|62–64 / (6.1),(6.6),(6.8)|Q,ε,S,평가 후 Dr/Dz/time,band 지지|q/Q∈[1/2,2], band와 integer는 미분 중고정|
|70–72 / Definition6.5,(6.29),Proposition6.6|W의 sqrtζ·P,같은label합,common torus/Leibniz|계수 미분,물리 미분과 구별|
|74–76 / (7.3)–(7.10)|위상·normal·K·pressure/Eik|동일 source의 homogeneous primary|
|86 / Lemma7.7,(7.38),(7.39)|전체curl과 종방향발산|a=t+r; n·a를0으로 만들지 않음|
|87 / (7.40)|cutoff뒤 +ψ′t,Gaussian tail|별도additiveflat; 수치 τ아님|
|101–102 / Proposition9.1,(9.1),(9.2)|선형주항 소거 및9개상계그룹|supported wave 안전지수1−3κ_s|
|102–103 / Lemma9.2|mean-wave,full same-label quadratic|±1에H0,±2에1−κ_s|
|103–104 / Proposition9.3,(9.3),(9.4)|whole residual=G+F,계수grouping|fullroot를직접W로사용하지 않음|
|106–107 / Definition9.4,Proposition9.5|(9.8)의 B0=.7,C0*=1.2와초기통합목표|이번wave연결과N6-01전체인수구별|
|설계도5쪽|UI/계산/정리별등급|테스트·전칭·시각화개별기록|
|설계도62쪽 / N6-01,N6-02|원래초기finite state,보류범위|56/64승계;N6-02보정substep실행안함|

앞선 평균·세 결함·direct A1의 원문 대응은 inherited/reports를 그대로 보존한다. 이번에 다시 증명하거나 원문판본을 교체하지 않았다.

# MathScope M3 소스 결속 재개 패키지

**M3 56/64 / N6-02 PARTIAL 유지. 원격 변경 없음.**

이번 새 코드·입력·실행 기록·로컬 후보 화면을 묶은 추가 패키지다. 1,260개 초기 원본 증명은 승계만 하며, 모든 원본 증거를 이 ZIP에 다시 넣지는 않았다. 전체 원본 감사가 필요한 경우 기존 v4 + PR30-recovery-handoff.zip을 함께 보존한다.

## 최소 재현

Python 3.10 이상. 검증 환경은 EXECUTION_RECEIPT.json 참조.

```sh
python -m pip install -r requirements.txt
python code/run_all.py
python code/build_ui.py
```

49개 테스트가 통과해야 한다. `run_all.py`는 원본 norm/pressure/PDE 생성기를 재실행하지 않고, 저장된 바이트와 새 소비기만 확인한다. 새 실행 영수증의 시간·플랫폼·로그 경로는 현재 실행에 맞게 갱신된다. 수학 결과 JSON의 exact payload는 동일 입력에서 동일하다.

`index.html`을 연다. 상대 증거 링크까지 사용하려면 ZIP 전체를 같은 구조로 압축 해제한다. 일반 로컬 개발 환경에서는 다음 방식으로 열 수도 있다.

```sh
python -m http.server 8000 --bind 127.0.0.1
```

브라우저 주소는 `http://127.0.0.1:8000/index.html`이다. 이번 실행 환경은 브라우저 URL 탐색 정책이 차단되어 이 탐색 자체를 검수하지 못했다. 아래 검사는 DOM 컴포넌트 검사다.

```sh
python -m pip install -r requirements-browser.txt
# /usr/bin/chromium이 설치된 Linux 검사 환경
python code/browser_check.py
```

## 먼저 열 파일

`reports/RESULTS_KO.md`가 한국어 결과와 정확한 미완료 목록이다.
`evidence/SOURCE_BOUND_NORM_REPORT.json`은 다섯 원본 ID별 결속과 상계식이다.
`evidence/COMMON_TAIL_SOURCE_CONNECTION.json`은 실제 수치화 시도·거부 이유다.
`evidence/temporal_slow_change.json`, `five_slow_change.json`은 이번에 계산한 전체 양의 상계 DAG다.
`INPUT_LOCK.json`은 원본 입력 23개의 해시다.
`FILE_MANIFEST.json`은 최종 추가 패키지 구성원 해시다.

## 범위

source_norm_result의 node 번호는 수치 상수가 아니다. 초기 U0, raw Zj, cutoff/curl 곱을 반영한 hatC는 서로 다른 입력이다. 형식적 단계식이나 유한 테스트를 전칭 W/M/S 증명으로 승격하지 않는다. N6-02 보류 substep은 새로 실행하지 않는다. 외부 사이트와 GitHub에 쓰는 코드는 포함하지 않는다.

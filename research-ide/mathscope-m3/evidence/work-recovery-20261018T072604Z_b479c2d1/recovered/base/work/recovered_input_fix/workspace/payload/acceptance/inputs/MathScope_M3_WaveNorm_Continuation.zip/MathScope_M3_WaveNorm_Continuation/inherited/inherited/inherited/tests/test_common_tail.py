import unittest
from fractions import Fraction as Q
import common_tail as c

class OriginalSixTests(unittest.TestCase):
    def test_log_interval(self):
        lo, hi = c.ln2_interval()
        self.assertLess(lo,hi); self.assertGreater(lo,Q(69,100)); self.assertLess(hi,Q(70,100))
    def test_cutoff_whole_interval_certificate(self):
        r=c.choose_cutoff(1,[c.Envelope(Q(1),0,Q(1))]*2,None,Q(1,2))
        self.assertEqual(r['log2_a'],2);self.assertTrue(all(r['inequality_checks']))
    def test_missing_derivative_envelope_rejected(self):
        with self.assertRaises(ValueError):c.choose_cutoff(2,[c.Envelope(Q(1),0,Q(1))],2,Q(1,2))
    def test_extension_constants_and_minimal_integer(self):
        self.assertEqual(c.extension_constant(2,1,[Q(1),Q(8)]),Q(5))
        r=c.choose_b(2,2,[Q(1),Q(1)],[Q(1),Q(8)])
        self.assertEqual(r['b'],20);self.assertTrue(r['minimal_above_previous'])
    def test_differentiated_extension_tail(self):
        self.assertEqual(c.extension_tail(3,1,1),Q(1,8))
        with self.assertRaises(ValueError):c.extension_tail(2,1,1)
    def test_local_tail_domain_is_enforced(self):
        with self.assertRaises(ValueError):c.local_tail_log2(3,2,Q(11),10,Q(1),Q(2))
        self.assertEqual(c.local_tail_log2(3,2,Q(12),10,Q(1),Q(2)),Q(15))
if __name__=='__main__':unittest.main(verbosity=2)

"""새 연결만 순차 재현. 원격 접근·이전 전체 증명·N6-02 substep 실행 없음."""
from __future__ import annotations
from pathlib import Path
import sys,json,hashlib,subprocess,time,shutil,platform,importlib.metadata
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
PRODUCTS=[
 'evidence/ORIGINAL_POLYNOMIAL.json','evidence/INDEPENDENT_ALGEBRA.json',
 'evidence/SOURCE_BINDINGS.json','evidence/DEFECT_NORM_PROGRAM.json',
 'evidence/ALL_ORDER_EXPONENT_PROOF.json','evidence/CURRENT_DEFECT_APPLICATION.json',
 'evidence/TEST_RECEIPT.json','index.html'
]
def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def main()->int:
 (ROOT/'evidence').mkdir(exist_ok=True)
 node=shutil.which('node')
 if not node:raise RuntimeError('Node.js가 필요합니다. 설치 또는 PATH를 확인하세요. 원격 설치는 수행하지 않습니다.')
 steps=[('original-polynomial',[node,'code/original_polynomial.mjs']),
        ('independent-algebra',[sys.executable,'code/independent_algebra.py']),
        ('defect-norm-bridge',[sys.executable,'code/defect_norm_bridge.py']),
        ('unit-tests',[sys.executable,'code/run_tests.py']),
        ('candidate-ui',[sys.executable,'code/build_ui.py'])]
 start=datetime.now(timezone.utc).isoformat();records=[]
 for label,cmd in steps:
  t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  log=ROOT/'evidence'/('RUN_'+label+'.log');log.write_text(p.stdout,encoding='utf-8')
  record={'name':label,'command':cmd,'cwd':str(ROOT),'exit_code':p.returncode,'seconds':round(time.monotonic()-t,6),'log':log.relative_to(ROOT).as_posix(),'log_sha256':sha(log)}
  records.append(record);print(f'{label}: exit={p.returncode}',flush=True)
  if p.returncode:break
 success=len(records)==len(steps) and all(r['exit_code']==0 for r in records)
 def version(pkg):
  try:return importlib.metadata.version(pkg)
  except importlib.metadata.PackageNotFoundError:return None
 environment={'python':sys.version,'platform':platform.platform(),'node':subprocess.check_output([node,'--version'],text=True).strip(),'sympy':version('sympy'),'playwright_optional':version('playwright')}
 code={p.relative_to(ROOT).as_posix():sha(p) for folder in ['code','tests'] for p in sorted((ROOT/folder).glob('*')) if p.is_file()}
 receipt={'schema':'MathScope.DefectNormExecutionReceipt/1','started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'successful':success,'steps':records,'environment':environment,'code_hashes':code,'input_lock_sha256':sha(ROOT/'INPUT_LOCK.json'),'source_additions_lock_sha256':sha(ROOT/'SOURCE_ADDITIONS_LOCK.json'),'product_hashes':{x:sha(ROOT/x) for x in PRODUCTS if (ROOT/x).is_file()},'original_1260_rerun':False,'N6_02_deferred_substeps_run':False,'remote_writes':0,'M3':'56/64','mathematical_grade':'CONDITIONAL_REFERENCE_APPLICATION_ON_INHERITED_SAME_SOURCE_NORM_PREMISES','browser_check':'별도 code/browser_check.py. 이 영수증은 브라우저 검사 성공을 대신하지 않음.'}
 (ROOT/'evidence/EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'successful':success,'products':len(receipt['product_hashes']),'M3':'56/64'},ensure_ascii=False))
 return 0 if success else 1
if __name__=='__main__':sys.exit(main())

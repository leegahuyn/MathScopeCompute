from pathlib import Path
import json,sys,unittest,time
ROOT=Path(__file__).resolve().parents[1]
def main():
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
    begin=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
    receipt={'schema':'MathScope.FastCutoffTests/1','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'seconds':round(time.monotonic()-begin,6),'passed':result.wasSuccessful(),'old_1260_proofs_rerun':False,
      'scope':'새 원본 연결기·유한 상계식·일반 대수·거부 테스트. 전칭 해석학 또는 운영 페이지의 독립 검증 아님.'}
    (ROOT/'evidence/TEST_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    if not result.wasSuccessful():raise SystemExit(1)
if __name__=='__main__':main()

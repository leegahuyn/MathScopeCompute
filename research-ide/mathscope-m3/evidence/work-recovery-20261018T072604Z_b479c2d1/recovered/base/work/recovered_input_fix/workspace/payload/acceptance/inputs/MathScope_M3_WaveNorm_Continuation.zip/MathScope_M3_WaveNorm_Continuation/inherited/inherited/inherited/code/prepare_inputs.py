"""원본 보존 묶음에서 이 소비기에 필요한 입력만 복사한다. 증명 재실행 없음."""
from __future__ import annotations
import argparse, gzip, hashlib, json, pathlib, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--v4',type=pathlib.Path,required=True);ap.add_argument('--base',type=pathlib.Path,required=True);a=ap.parse_args()
 specpath=a.v4/'pressure-proof/original-norm-scope-audit/ORIGINAL_N6_NORM_TYPED_SPEC.json';spec=json.loads(specpath.read_text())
 out=ROOT/'sources';out.mkdir(exist_ok=True);manifest={};selected={};origins={};conflicts=[]
 keys=['normFamily','cutoff','haar','primaryClass','primaryActual','fgHonesty','domain','initialized','normFamilyCode','normCompositionCode','haarCode','haarKernel','cutoffCode','freshCode','changeCode','meanChangeKernel','globalAngularCode','initializedAngularCode','initialMeanCode','primaryClassCode']
 for key in keys:
  b=spec['inputBindings'][key];p=a.v4/b['path']
  if not p.is_file(): p=a.base/b['path']
  if not p.is_file() or sha(p)!=b['sha256']: raise ValueError('원본 해시 불일치: '+key)
  dst=out/(key+p.suffix);shutil.copyfile(p,dst);manifest[key]={'path':str(dst.relative_to(ROOT)),**b,'path':str(dst.relative_to(ROOT)),'original_path':b['path']}
  if p.suffix=='.json' and key in ['normFamily','cutoff','haar']:
   data=json.loads(p.read_text())
   def walk(x,trail=''):
    if isinstance(x,dict):
     if 'selectedNodeBindings' in x and isinstance(x['selectedNodeBindings'],list):
      for r in x['selectedNodeBindings']:
       if not isinstance(r,dict) or 'id' not in r or 'node' not in r: continue
       i=r['id'];n=r['node']
       if i in selected and selected[i]!=n: conflicts.append([i,key,trail])
       selected[i]=n;origins.setdefault(i,[]).append(key+':'+trail)
     for k,v in x.items():
      if k!='selectedNodeBindings': walk(v,trail+'/'+k)
    elif isinstance(x,list):
     for j,v in enumerate(x): walk(v,trail+'/'+str(j))
   walk(data)
 if conflicts: raise ValueError('저장 증거의 노드 정의 충돌: '+repr(conflicts[:5]))
 extra={i for r in spec['normTargets'] for i in r['originalRequirement']['sourceRoots']}
 extra.update([3676894,3676895,3676896,622830,634227,617515,634228,3615635,3615673,3615848,3614735,3614752,3614740,3614755,3614745,3614717,3614719,3614718,3614789,3614771])
 need=set(selected)|extra;nodes={};archive=a.base/'runtime/source/original-parent.ndjson.gz'
 with gzip.open(archive,'rb') as f:
  header_line=f.readline();header=json.loads(header_line)
  for line in f:
   i=int(line[1:line.find(b',')])
   if i in need:
    pair=json.loads(line);nodes[i]=pair[1]
   if len(nodes)==len(need): break
 if need-set(nodes): raise ValueError('원본 노드 누락: '+repr(need-set(nodes)))
 mismatch=[i for i,n in selected.items() if nodes[i]!=n]
 if mismatch: raise ValueError('원본 대조 불일치: '+repr(mismatch[:20]))
 # 이하 원본 노드들은 원래 해시 고정 아카이브에서 추출된 읽기 전용 스냅샷이다.
 packet={'schema':'MathScope.ActualSelectedSourceNodes/1','original_archive_sha256':sha(archive),'original_header_sha256':hashlib.sha256(header_line.rstrip(b'\n')).hexdigest(),'original_node_count':header['nodeCount'],'selected_evidence_node_count':len(selected),'extra_target_node_count':len(extra-set(selected)),'matched_node_count':len(nodes),'nodes':{str(i):nodes[i] for i in sorted(nodes)},'comparison':'저장 증거 selectedNodeBindings와 원본 NDJSON의 정확한 노드 정의 대조; 기존 PDE 증명 재실행 아님','origins':{str(i):v for i,v in origins.items()}}
 write(out/'actual_source_nodes.json',packet)
 for key,src in [('typedSpec',specpath),('frontier',a.v4/'pressure-proof/PHASE5_CURRENT_SUMMARY.json')]:
  dst=out/(key+'.json');shutil.copyfile(src,dst);manifest[key]={'path':str(dst.relative_to(ROOT)),'sha256':sha(dst),'bytes':dst.stat().st_size,'original_path':str(src.relative_to(a.v4))}
 p=out/'actual_source_nodes.json';manifest['actualNodes']={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size,'original_path':'runtime/source/original-parent.ndjson.gz:selected node extract'}
 write(ROOT/'INPUT_LOCK.json',{'schema':'MathScope.SourceBoundNormInputLock/1','sources':manifest,'raw_source_archive':{'path':'runtime/source/original-parent.ndjson.gz','sha256':sha(archive)},'original_proofs_rerun':False})
 print(json.dumps({'copied_sources':len(manifest),'selected_nodes_compared':len(selected),'total_target_nodes':len(nodes),'mismatches':mismatch,'old_proofs_rerun':False},ensure_ascii=False))
if __name__=='__main__': main()

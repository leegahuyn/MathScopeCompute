# MathScope M3 · 초기 wave 노름 연결

이 묶음의 현재 판정은 M3 56/64, N6-01 OPEN, N6-02 PARTIAL 및 보정 substep 보류다. 기존 초기1260 결과를 다시 실행하지 않는다.

## 읽기

`index.html`은 로컬 후보 화면이다. ZIP 전체를 풀어야 상대 증거 링크와 `inherited/index.html`을 사용할 수 있다. 채팅 미리보기가 JavaScript를 실행하지 않는 경우 로컬 브라우저에서 연다.

`reports/RESULTS_KO.md`에 결과, `reports/ALL_ORDER_PROOF_KO.md`에 정량 적용 논증과 전제, `reports/SOURCE_PAGE_MAP_KO.md`에 원문 쪽/식 대응, `reports/HANDOFF_KO.md`에 다음 재개점이 있다.

## 최소 재현

검사한 환경 버전은 ENVIRONMENT.json에 기록했다. Python+SymPy와 Node.js가 필요하다. 별도 브라우저 검사는 Playwright와 Chromium이 필요하며 기본 실행파일은 `/usr/bin/chromium`이다.

```sh
python -m pip install -r requirements-math.txt
python code/run_all.py
python code/replay.py
# 준비된 Linux Playwright/Chromium 환경에서만:
python code/browser_check.py
```

`run_all.py`는 새 wave 연결, 명시적 합성 JS fixture, 독립 symbolic 비교,32개 테스트와 후보HTML만 재생성한다. 원본1260·후속cycle·보류substep·Lean 재실행이나 원격 게시/병합 명령은 없다. 원래 비공개 source seal을 재생성한 것처럼 표시하지 않는다.

`INPUT_LOCK.json`은 선택한 입력16개, `SOURCE_ADDITIONS_LOCK.json`은 v4에서 좁게 가져온 원본, `HASH_MANIFEST.json`은 이번 묶음 파일 해시다. 실행 영수증의 코드 해시는 그 실행 때의 코드와 일치한다.

## 결과 해석

조건부 동일 소스 노름 적용이며 실제 함수값/수치 C/최종 τ 또는 새 전칭 Lean 증명이 아니다. 전체 root3825348/9/50을 바로W로 승인하지 않고 nonzero projection 및 G+F 분해를 거친다. 360개행은 원본 적용기록이지360개의 신규 수학의무가 아니다. 단위테스트,독립generic알gebra,UI검사는 중복범위가 있으므로 합산하지 않는다.

파일URL은 이번 환경에서 ERR_BLOCKED_BY_ADMINISTRATOR가 반환됐다. 정책을 변경하지 않고 같은 HTML의 DOM을 검사했다. 운영사이트검수/증거페이지왕복은 미완료이며 UI_VALIDATION에 기록돼 있다.

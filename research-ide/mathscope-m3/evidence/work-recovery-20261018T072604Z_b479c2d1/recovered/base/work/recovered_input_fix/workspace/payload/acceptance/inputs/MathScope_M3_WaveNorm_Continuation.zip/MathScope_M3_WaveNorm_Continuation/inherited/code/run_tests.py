"""새 결함 노름 연결 테스트만 실행하고 기계 판독 영수증을 남긴다."""
from pathlib import Path
import json,sys,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_defect_bridge.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
receipt={
 'schema':'MathScope.DefectBridgeTestReceipt/1','tests_run':result.testsRun,
 'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
 'successful':result.wasSuccessful(),'suite':'tests/test_defect_bridge.py',
 'scope':'새 소스 결속·상계 합성·기호 대수·오류 주입 검사. 초기1260 증명 또는 보정 substep 재실행 아님.',
 'failed_tests':[str(t) for t,_ in result.failures+result.errors]
}
(ROOT/'evidence/TEST_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sys.exit(0 if result.wasSuccessful() else 1)

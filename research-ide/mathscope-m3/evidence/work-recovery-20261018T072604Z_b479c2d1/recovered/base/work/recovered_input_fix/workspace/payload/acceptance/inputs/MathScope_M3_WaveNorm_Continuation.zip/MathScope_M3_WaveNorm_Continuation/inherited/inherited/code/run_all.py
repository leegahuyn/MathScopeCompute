"""이번 추가분의 최소 재현. 원래 PDE/Guard/Jet 실행을 호출하지 않는다."""
from pathlib import Path
import datetime,hashlib,json,platform,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    (ROOT/'evidence').mkdir(exist_ok=True);steps=[]
    for script in ['fast_cutoff_bridge.py','run_checks.py','build_ui.py']:
        command=[sys.executable,str(ROOT/'code'/script)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
        p=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=40)
        log='evidence/'+script.replace('.py','.log');(ROOT/log).write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
        steps.append({'command':['python','code/'+script],'started_utc':start,'seconds':round(time.monotonic()-t,6),'exit_code':p.returncode,'log':log,'log_sha256':sha(ROOT/log)})
        print(script,'exit',p.returncode)
        if p.returncode:print(p.stdout,p.stderr);break
    outputs={p.name:sha(p) for p in (ROOT/'evidence').glob('*.json') if p.name not in ['EXECUTION_RECEIPT.json','REPLAY_VERIFICATION.json','UI_VALIDATION.json','TEST_RECEIPT.json']}
    receipt={'schema':'MathScope.FastCutoffExecutionReceipt/1','python':sys.version,'platform':platform.platform(),'steps':steps,
      'success':len(steps)==3 and all(s['exit_code']==0 for s in steps),
      'source_hashes':{str(p.relative_to(ROOT)):sha(p) for f in ['code','tests'] for p in sorted((ROOT/f).glob('*.py'))},
      'outputs':outputs,'input_lock_sha256':sha(ROOT/'BRIDGE_INPUT_LOCK.json'),'old_1260_proofs_rerun':False,
      'N6_02_correction_substeps_run':False,'remote_writes':0,'M3':'56/64'}
    (ROOT/'evidence/EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    if not receipt['success']:raise SystemExit(1)
if __name__=='__main__':main()

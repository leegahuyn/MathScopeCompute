"""Local candidate UI inspection; never modifies navigation policy or the live site."""
from pathlib import Path
import json,hashlib
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
def main():
 checks=[];errors=[];attempts=[]
 def check(name,ok):
  checks.append({'name':name,'pass':bool(ok)})
  if not ok:raise AssertionError(name)
 data=json.loads((ROOT/'evidence/CURRENT_WAVE_APPLICATION.json').read_text());mode='file_navigation'
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1280,'height':1050},device_scale_factor=1,accept_downloads=True)
  page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.goto((ROOT/'index.html').as_uri(),wait_until='load',timeout=10000);attempts.append({'mode':mode,'success':True})
  except Exception as exc:
   attempts.append({'mode':mode,'success':False,'error':str(exc)});mode='DOM_component_set_content'
   page.close();page=browser.new_page(viewport={'width':1280,'height':1050},device_scale_factor=1,accept_downloads=True);page.on('pageerror',lambda e:errors.append(str(e)))
   page.set_content((ROOT/'index.html').read_text(),wait_until='load')
  page.wait_for_selector('html[data-render-ready="true"]',timeout=10000)
  check('원래 M3 상태 유지',page.locator('#m3').inner_text()=='56 / 64')
  check('N6-02 보류 표시','N6-02 PARTIAL' in page.locator('#scope').inner_text())
  check('원본1260과[0,0]승계 표시','1,260' in page.locator('#baseline').inner_text() and '[0,0]' in page.locator('#baseline').inner_text())
  check('전체root와계수구별',page.locator('#root-id').inner_text()=='3825348' and '투영 전' in page.locator('#result').inner_text())
  check('계산된W지수와정확여유',page.locator('#exponent').inner_text()=='99997/100000' and page.locator('#margin').inner_text()=='29997/100000')
  check('모든선형나머지와mean-wave표시',page.locator('#chart circle').count()==10)
  check('그래프가함수크기로오표시안됨','실제 함수 크기 그래프가 아니다' in page.locator('body').inner_text())
  check('수치상수미실현표시','수치 C 미출력' in page.locator('#constant').inner_text())
  check('10개원본lift선택',page.locator('#template option').count()==10)
  page.select_option('#template','4:-1');page.select_option('#mode','-2');page.select_option('#component','2');page.fill('#order','2')
  expected=next(r for r in data['rows'] if r['template']=='4:-1' and r['harmonic']==-2 and r['component']==2 and r['derivative_order']==2)
  check('선택sourceID동기화',page.locator('#real-id').inner_text()==str(expected['actual_coefficient']['real']) and page.locator('#imag-id').inner_text()==str(expected['actual_coefficient']['imaginary']))
  check('전체축root동기화',page.locator('#root-id').inner_text()=='3825350')
  check('제곱harmonic모든4그룹',page.locator('#chart circle').count()==4)
  check('실제2차로그와pole반영','S_*^2173' in page.locator('#bound').inner_text() and 'δ^(−30)' in page.locator('#bound').inner_text())
  check('둘째harmonic정확지수',page.locator('#exponent').inner_text()=='99999/100000')
  page.click('#inspect');inline=json.loads(page.locator('#evidence-json').inner_text())
  check('인라인선택과원본장부일치',inline['selection']==expected)
  check('상수leaf와정의역연결',bool(inline['constant_sources']['source_leaves']) and inline['domain']['oneFinitePrefixClaimedValidAtAllQ'] is False)
  check('Gaussian별도잔차표시',inline['gaussian_tail']['absorbed_into_W_or_deleted'] is False and 'Gaussian cutoff tail은 0이 아니다' in page.locator('body').inner_text())
  page.select_option('#component','1')
  check('열린증거도성분선택에동기화',json.loads(page.locator('#evidence-json').inner_text())['selection']['inspection_root']==3825349)
  page.fill('#order','3');check('미실행고차수요청거부','입력 오류' in page.locator('#error').inner_text() and page.locator('#export').is_disabled())
  check('오류때과거그래프제거',page.locator('#result').is_hidden() and page.locator('#chart circle').count()==0)
  page.fill('#order','1.5');check('비정수차수거부',page.locator('#export').is_disabled())
  page.fill('#order','');check('빈차수거부',page.locator('#export').is_disabled())
  page.locator('#reset').focus();page.keyboard.press('Enter');check('키보드초기화',page.locator('#order').input_value()=='0' and page.locator('#template').input_value()=='0:1' and page.locator('#result').is_visible())
  with page.expect_download() as dd:page.click('#export')
  dd.value.save_as(str(ROOT/'evidence/EXPORTED_SELECTION.json'));ex=json.loads((ROOT/'evidence/EXPORTED_SELECTION.json').read_text())
  check('내보낸선택·원본·등급일치',ex['selection']['inspection_root']==3825348 and ex['M3']=='56/64' and ex['field_values_calculated'] is False)
  links=[]
  for a in page.locator('a[href]').all():
   href=a.get_attribute('href').split('#')[0];links.append({'href':href,'file_exists':(ROOT/href).is_file()})
  check('모든상대증거파일존재',all(r['file_exists'] for r in links))
  navigation_checked=False
  if mode=='file_navigation':
   page.click('#application-link');page.wait_for_load_state('load');check('증거파일실제탐색','CurrentInitialWaveApplication' in page.locator('body').inner_text());page.go_back(wait_until='load');page.wait_for_selector('html[data-render-ready="true"]');navigation_checked=True
  page.screenshot(path=str(ROOT/'evidence/UI_DESKTOP.png'),full_page=True)
  for width,height,name in [(390,844,'MOBILE'),(760,480,'LANDSCAPE')]:
   page.set_viewport_size({'width':width,'height':height});page.locator('#reset').click();
   check(name+'가로넘침없음',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   check(name+'읽을수있는대체수치10행',page.locator('#cards').is_visible() and page.locator('#cards .card').count()==10)
   check(name+'터치대상44px',all((page.locator(s).bounding_box() or {}).get('height',0)>=44 for s in ['#mode','#order','#reset','#export']))
   page.screenshot(path=str(ROOT/'evidence'/f'UI_{name}.png'),full_page=True)
  check('브라우저스크립트오류없음',not errors)
  browser.close()
 out={'schema':'MathScope.WaveBridgeUIValidation/1','checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'mode':mode,'navigation_attempts':attempts,'relative_evidence_file_existence':links,'relative_navigation_round_trip_checked':navigation_checked,'console_errors':errors,'live_site_checked':False,'remote_writes':0,'policy_modified':False,'html_sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),'scope':'같은 후보HTML의 표시/조작 검수. 파일 탐색 허용 여부를 별도 기록한다. 운영 사이트 검수가 아니다.'}
 (ROOT/'evidence/UI_VALIDATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['passed','total','mode','relative_navigation_round_trip_checked']},ensure_ascii=False))
if __name__=='__main__':main()

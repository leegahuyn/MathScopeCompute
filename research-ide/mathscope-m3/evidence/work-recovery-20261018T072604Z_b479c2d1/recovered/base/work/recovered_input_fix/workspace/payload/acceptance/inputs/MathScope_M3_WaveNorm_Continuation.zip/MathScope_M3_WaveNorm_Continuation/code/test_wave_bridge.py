from __future__ import annotations
import copy,json,unittest
from fractions import Fraction as Q
from wave_bridge import *

class WaveBridgeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.d=load();cls.binding=authenticate(cls.d);cls.parent=cls.d['family']['certificates'][1]
  cls.p=compose(cls.parent['program'],cls.parent['graph']['sha256'],2)
  cls.app=application(cls.binding,cls.p)
 def mutated(self,edit):
  d=copy.deepcopy(self.d);edit(d)
  with self.assertRaises(SourceError):authenticate(d)
 def test_source_roots_and_nonzero_projection(self):
  self.assertEqual(self.binding['inspection_roots'],[3825348,3825349,3825350]);self.assertEqual(self.binding['nonzero_modes'],[-2,-1,1,2])
  self.assertTrue(all(r['not_raw_full_residual_W_assertion'] for r in self.app['rows']))
 def test_all_ten_templates_all_modes_components_derivatives(self):
  self.assertEqual(len(self.app['rows']),360);self.assertEqual(len({r['id'] for r in self.app['rows']}),360)
  self.assertEqual({(r['harmonic'],r['component'],r['derivative_order']) for r in self.app['rows']},{(h,c,m) for h in [-2,-1,1,2] for c in range(3) for m in range(3)})
 def test_original_state_not_promoted(self):
  self.assertEqual(self.app['m3']['completed'],56);self.assertFalse(self.app['baseline']['recomputed']);self.assertIn('PARTIAL',self.app['m3']['N6-02'])
 def test_all_linear_groups_present(self):
  self.assertEqual(set(self.p['rows'][0]['linear_groups']),{'slow_transport','phase_defect','base_derivatives_connections','pressure_amplitude_gradient','viscous_amplitude','viscous_mixed','viscous_phase_divergence','viscous_angular_connection','principal_on_curl'})
 def test_exact_final_exponents(self):
  for r in self.p['rows']:
   self.assertEqual(r['linear']['epsilon_exponent'],'99997/100000')
   self.assertEqual(r['mean_wave']['epsilon_exponent'],'99999/100000')
   self.assertEqual(r['same_label_wave_wave']['epsilon_exponent'],'99999/100000')
 def test_actual_input_derivatives_and_weights(self):
  for r in self.p['rows']:
   self.assertEqual(r['primary_input_orders_used'],r['order']+2)
   for b in r['modes'].values():self.assertEqual(b['zeta_power'],'1/2');self.assertEqual(b['pulse_power'],1);self.assertIsNone(b['numerical_constant'])
 def test_scalar_graph_valid_and_no_self_residual_input(self):
  g=PositiveDAG(self.p['scalar_nodes'],self.p['call_graph'],self.p['constant_graph_sha256']);g.validate()
  for cl in self.p['constant_closures'].values():self.assertNotIn('initialized',{r['producer'] for r in cl['source_leaves']})
 def test_node_number_not_numeric_bound(self):
  g=PositiveDAG(self.p['scalar_nodes'],self.p['call_graph'],self.p['constant_graph_sha256'])
  with self.assertRaises(SourceError):g.numeric_constant(self.p['rows'][0]['modes']['1']['constant']['node'])
 def test_large_chart_constants_remain_power_dag(self):
  powers=[n['args'][1] for n in self.p['scalar_nodes'] if n['op']=='integer_power'];self.assertGreater(max(powers),10000)
  self.assertTrue(all(len(n['args'][0])<4300 for n in self.p['scalar_nodes'] if n['op']=='rational'))
 def test_original_domain_kept(self):
  dom=self.binding['same_original_domain'];self.assertFalse(dom['oneFinitePrefixClaimedValidAtAllQ']);self.assertEqual(dom['prefixOrder'],1);self.assertIn('b_(N+1)*q>=1',dom['conditions'])
 def test_gaussian_uses_actual_decay_and_length_nodes(self):
  t=gaussian_binding(self.d['primary']);self.assertEqual(t['gaussian_lower']['node'],617317);self.assertEqual(t['length_ratio_lower']['node'],300173)
  self.assertFalse(t['absorbed_into_W_or_deleted']);self.assertFalse(t['final_resolvable_tau_computed'])
 def test_reject_wrong_full_root(self):self.mutated(lambda d:d['initialized']['global']['assembledResidual'].__setitem__(0,0))
 def test_reject_old_pressure(self):self.mutated(lambda d:d['family']['source']['actualRoots']['initializedPressure'].__setitem__('value',1))
 def test_reject_cutoff_declared_zero(self):self.mutated(lambda d:d['family']['source']['actualRoots']['initializedPressure'].__setitem__('cutoffRemainderDeclaredZero',True))
 def test_reject_missing_template(self):self.mutated(lambda d:d['initialized']['templates'].pop())
 def test_reject_duplicate_template(self):self.mutated(lambda d:d['initialized']['templates'].__setitem__(0,d['initialized']['templates'][1]))
 def test_reject_missing_squared_mode(self):self.mutated(lambda d:d['initialized']['templates'][0]['nonzeroAngularForcing'].pop())
 def test_reject_missing_negative_velocity(self):self.mutated(lambda d:d['initialized']['templates'][0]['waveRows'].pop())
 def test_reject_truncated_modes(self):self.mutated(lambda d:d['initialized']['application'].__setitem__('discardedLabelsOrModes',[2]))
 def test_reject_one_preimage_replacing_full_torus(self):self.mutated(lambda d:d['initialized']['application'].__setitem__('completeYPreimageKept',False))
 def test_reject_differentiated_integer_copy(self):self.mutated(lambda d:d['initialized']['application'].__setitem__('nearestCopiesDifferentiated',True))
 def test_reject_own_background_substitution(self):self.mutated(lambda d:d['initialized']['reference'].__setitem__('ownLabelBackgroundIdentityAssumedInstead',True))
 def test_reject_homogeneous_pressure_omission(self):self.mutated(lambda d:d['initialized']['templates'][0]['sourceFrame']['primaryHomogeneousPressure'].__setitem__('pressureOmitted',True))
 def test_reject_dropped_quadratic(self):self.mutated(lambda d:d['initialized']['templates'][0]['update'].__setitem__('newQuadraticRemainderRetained',False))
 def test_reject_missing_cross_label_evidence(self):self.mutated(lambda d:d['angular_application']['actualAngularPDEConclusions'].__setitem__('allDistinctWaveCrossTensorsAndTheirRequiredDerivativesVanish',False))
 def test_reject_changed_literal_mean_definition(self):self.mutated(lambda d:d['angular_nodes']['records']['3677233'].__setitem__('args',[1,2]))
 def test_reject_changed_parent_program(self):self.mutated(lambda d:d['family']['certificates'][1]['program']['updatedVelocityRows'].pop())
 def test_reject_missing_derivative_order(self):
  with self.assertRaises(SourceError):compose(self.parent['program'],self.parent['graph']['sha256'],3)
 def test_reject_noninteger_order(self):
  for order in [-1,1.5,True]:
   with self.assertRaises(SourceError):compose(self.parent['program'],self.parent['graph']['sha256'],order)
 def test_product_rule_binomial_envelope(self):
  g=PositiveDAG([],[],'test');a=WA(g);x=[a.unit(g.q(n)) for n in [2,3,4,5]];y=[a.unit(g.q(n)) for n in [7,11,13,17]]
  z=a.mulseq(x,y)
  self.assertEqual(g.numeric_constant(z[3].C),2*17+3*3*13+3*4*11+5*7)
 def test_reject_no_pulse_in_W_claim(self):
  g=PositiveDAG([],[],'test');a=WA(g)
  with self.assertRaises(SourceError):a.as_wave(WB(g.q(1),0,0,Q(1),Q(1,2),0))
 def test_reject_negative_constant_or_missing_node(self):
  g=PositiveDAG([],[],'test');a=WA(g)
  with self.assertRaises(SourceError):g.q(-1)
  with self.assertRaises(SourceError):a.read({'constant':9000,'power':0,'pole':0,'epsilonExponent':'1','weight':'zeta'})

if __name__=='__main__':
 import io
 stream=io.StringIO();res=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(WaveBridgeTests))
 text=stream.getvalue();print(text,end='');(ROOT/'evidence/UNIT_TESTS.log').write_text(text)
 dump(ROOT/'evidence/TEST_RESULTS.json',{'tests_run':res.testsRun,'failures':len(res.failures),'errors':len(res.errors),'successful':res.wasSuccessful(),'scope':'새 연결기·입력 거부·정확 상계 대수. 원본1260 재실행 및 전칭 증명 개수가 아님.'})
 raise SystemExit(0 if res.wasSuccessful() else 1)

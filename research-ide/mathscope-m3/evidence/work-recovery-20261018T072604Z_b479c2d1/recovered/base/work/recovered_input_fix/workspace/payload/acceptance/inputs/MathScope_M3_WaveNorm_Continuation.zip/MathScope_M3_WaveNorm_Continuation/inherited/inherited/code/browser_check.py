"""로컬 후보의 실제 탐색과 조작. 운영 사이트/원격 배포 검증과 구별한다."""
from pathlib import Path
import hashlib,json,time,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
def main():
    checks=[];errors=[];attempts=[]
    def check(name,passed):
        checks.append({'name':name,'pass':bool(passed)})
        if not passed:raise AssertionError(name)
    html=(ROOT/'index.html').read_text();url=(ROOT/'index.html').as_uri();mode='file_navigation'
    try:
      with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=browser.new_page(viewport={'width':1280,'height':1000},device_scale_factor=1,accept_downloads=True)
        page.on('pageerror',lambda e:errors.append(str(e)))
        try:
            if '--dom-only' in sys.argv:raise RuntimeError('기존 file URL 정책 차단 기록을 보존하고 이번에는 DOM만 재검사')
            page.goto(url,wait_until='load',timeout=12000)
            attempts.append({'url':url,'success':True})
        except Exception as e:
            attempts.append({'url':url,'success':False,'error':str(e)})
            mode='DOM_component_set_content';page.close();page=browser.new_page(viewport={'width':1280,'height':1000},device_scale_factor=1,accept_downloads=True)
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.set_content(html,wait_until='load')
        page.wait_for_selector('html[data-render-ready="true"]')
        check('M3 분모와 상태 보존',page.locator('#m3').inner_text()=='56 / 64')
        check('초기1260과N602보류 분리','보정 substep 보류' in page.locator('body').inner_text() and '초기 1,260 완료' in page.locator('body').inner_text())
        check('직접A1부호 양수 표시','+A₁(E₀,z' in page.locator('.formula').inner_text())
        check('범위와숫자비인증 표시','조건부 정량' in page.locator('#scope').inner_text())
        check('Ez 실제 소스ID 표시','3615392' in page.locator('#source').inner_text())
        check('Ez 실제 합성149/100',page.locator('#exponent').inner_text()=='149/100')
        check('네 항이 그래프와 표에 연결',page.locator('#chart circle').count()==4 and page.locator('#rows tr').count()==4)
        check('차수 비교가 실제함수크기가 아님 표시','실제 함수 크기 그래프가 아니다' in page.locator('.legend').inner_text())
        check('직접/기존 입력차수 차이','98005' in page.locator('#request').inner_text() and '98010' in page.locator('#request').inner_text())
        page.select_option('#order','1')
        check('차수1과증거 링크 동기화',page.locator('#direct-link').get_attribute('href')=='evidence/IBP_DIRECT_A1_m1_p49001.json' and '98006' in page.locator('#request').inner_text())
        page.select_option('#field','Etheta')
        check('Etheta 원본과상계 동기화','3614976' in page.locator('#source').inner_text() and page.locator('#exponent').inner_text()=='199997/100000')
        check('각성분cutoff 미추가',page.locator('#chart circle').count()==3 and page.locator('#rows tr').count()==3)
        page.fill('#p','49000')
        check('p49000은1.49목표미달','1.49 기준: 아직 낮은 지수' in page.locator('#request').inner_text())
        check('what-if와저장값구별','가정/요청 계산' in page.locator('#request').inner_text())
        page.fill('#p','20001')
        check('원래6/5최소지수계산','6/5 기준: 충족하는 지수' in page.locator('#request').inner_text())
        page.fill('#p','20000')
        check('p20000원래기준미달','6/5 기준: 아직 낮은 지수' in page.locator('#request').inner_text())
        page.fill('#p','0')
        check('잘못된정수오류와오래된요청제거','입력 오류' in page.locator('#error').inner_text() and page.locator('#request').inner_text()=='')
        page.locator('#reset').focus();page.keyboard.press('Enter')
        check('키보드복원',page.locator('#p').input_value()=='49001' and page.locator('#error').inner_text()=='')
        page.select_option('#field','Ez');page.select_option('#order','0')
        with page.expect_download() as d:page.click('#export')
        download=d.value;path=ROOT/'evidence/EXPORTED_REQUEST.json';download.save_as(str(path));state=json.loads(path.read_text())
        check('실제JSON내보내기',state['p']==49001 and state['direct_initial_Ez_order']==98005 and state['cutoff_declared_zero'] is False)
        page.locator('details summary').click()
        check('상계JSON실제열기','3615392' in page.locator('#json').inner_text())
        if mode=='file_navigation':
            page.click('#direct-link');page.wait_for_load_state('load')
            check('실제증거링크탐색','MathScope.DirectCommutedAxialCutoff/1' in page.locator('body').inner_text())
            page.go_back(wait_until='load');page.wait_for_selector('html[data-render-ready="true"]')
            check('증거에서화면복귀',page.locator('#m3').inner_text()=='56 / 64')
            page.reload(wait_until='load');page.wait_for_selector('html[data-render-ready="true"]')
            check('실제새로고침',page.locator('#p').input_value()=='49001')
        page.evaluate('window.scrollTo(0,0)')
        check('데스크톱가로넘침없음',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        page.screenshot(path=str(ROOT/'evidence/UI_DESKTOP.png'),full_page=True)
        for width in [390,768]:
            page.set_viewport_size({'width':width,'height':844});page.evaluate('window.scrollTo(0,0)')
            check(str(width)+'px가로넘침없음',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            page.select_option('#order','1');check(str(width)+'px차수조작','98006' in page.locator('#request').inner_text())
            check(str(width)+'px차트문자높이',page.locator('#chart svg text').first.evaluate('(e)=>e.getBoundingClientRect().height')>=10.5)
            if width==390:page.screenshot(path=str(ROOT/'evidence/UI_MOBILE.png'),full_page=True)
        links=page.locator('a').evaluate_all('(aa)=>aa.map(a=>a.getAttribute("href"))')
        missing=[v for v in links if not(ROOT/v).is_file()]
        check('모든현재증거링크파일존재',not missing)
        check('런타임JS오류없음',not errors)
        version=browser.version;browser.close()
    finally:
        receipt={'schema':'MathScope.LocalFastCutoffUI/1','render_mode':mode,'navigation_attempts':attempts,
         'tested_operating_site':False,'remote_writes':0,'checks':checks,'passed':sum(c['pass'] for c in checks),
         'total':len(checks),'page_errors':errors,'html_sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),
         'note':'URL 탐색 실패 시 정책을 바꾸지 않고 DOM 조작만 검사. 성공/실패는 navigation_attempts에 기록.'}
        (ROOT/'evidence/UI_VALIDATION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'render_mode':mode,'passed':receipt['passed'],'total':receipt['total'],'page_errors':errors},ensure_ascii=False))
if __name__=='__main__':main()

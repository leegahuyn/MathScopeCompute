from __future__ import annotations
import copy,json,sys,unittest,math
from pathlib import Path
from fractions import Fraction as Q
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from defect_norm_bridge import load,authenticate,compose,all_order_proof,build,SourceError,digest,PositiveDAG,NormAlgebra,H0,K,TARGET
from independent_algebra import verify

class DefectBridgeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.d=load();cls.cert=cls.d['family']['certificates'][1];cls.p=cls.cert['program'];cls.h=cls.cert['graph']['sha256']
  cls.binding,cls.out,cls.rest=build(cls.d)
 def mutate(self,fn):
  d=copy.deepcopy(self.d);fn(d)
  with self.assertRaises((SourceError,KeyError,TypeError,ValueError)):authenticate(d)
 def test_current_and_remainder_roots(self):
  self.assertEqual(self.binding['current_defects'],{'P':3615055,'Jtheta':3615101,'Jz':3615147})
  self.assertEqual(self.binding['retained_remainders'],{'P':3615635,'Jtheta':3615673,'Jz':3615848})
 def test_three_by_three_rows(self):self.assertEqual(len(self.rest['application']['rows']),9)
 def test_exact_exponent_margin(self):
  self.assertEqual(self.rest['proof']['result'],'99999/50000');self.assertEqual(self.rest['proof']['exact_margin'],'39999/50000')
 def test_all_actual_output_orders(self):
  for r in self.out['rows']:
   for b in r['defects'].values():self.assertEqual(Q(b['epsilonExponentExact']),2*H0)
 def test_slow_time_one_extra_epsilon(self):
  for r in self.out['rows']:
   self.assertEqual(Q(r['groups']['time']['epsilonExponentExact']),H0+2)
   self.assertEqual(Q(r['stored_parent_groups']['time']['epsilonExponentExact']),H0+1)
 def test_slow_radial_and_viscous(self):
  for r in self.out['rows']:
   for k in ['radial','viscous']:self.assertEqual(Q(r['groups'][k]['epsilonExponentExact']),H0+2)
 def test_all_products_present(self):
  for r in self.out['rows']:
   self.assertEqual([len(r[k]) for k in ['radial_terms','axial_products','angular_terms','viscous_terms','theta_products','z_products']],[3,5,2,4,3,2])
 def test_pressure_half_and_triangle_sign_separate(self):
  for r in self.out['rows']:
   self.assertEqual(r['identity_sign_of_pressure_part'],'-1/2');self.assertIn('pressure_half_R2Rg',r['JzParts'])
 def test_constants_are_graph_references_not_numbers(self):
  r=self.out['rows'][0]['defects']['P'];self.assertIsNone(r['numerical_constant']);self.assertEqual(r['constant']['graph'],self.out['scalar_graph_hash'])
 def test_closure_namespace(self):
  self.assertTrue(all(v['namespace']==self.out['scalar_graph_hash'] for v in self.out['constant_closures'].values()))
 def test_no_circular_final_defect_norms(self):
  for c in self.out['constant_closures'].values():self.assertTrue(all(x['producer']!='initialized' for x in c['source_leaves']))
 def test_graph_roundtrip(self):
  g=PositiveDAG(self.out['scalar_nodes'],self.out['call_graph'],self.out['scalar_graph_hash']);self.assertEqual(digest(g.nodes),self.out['scalar_graph_hash'])
 def test_target_is_not_zero_norm(self):self.assertFalse(self.out['zero_defects_claimed']);self.assertFalse(self.rest['application']['all_three_fresh_defects_set_zero'])
 def test_original_scope_preserved(self):
  a=self.rest['application'];self.assertEqual(a['M3'],'56/64');self.assertIn('PARTIAL',a['N6-02']);self.assertEqual(a['original_M3_items_newly_completed'],[])
 def test_conditional_reference_not_lean(self):
  self.assertIn('CONDITIONAL_REFERENCE',self.rest['proof']['grade']);self.assertFalse(self.rest['proof']['independent_Lean_proof'])
 def test_no_rerun_or_substep(self):
  self.assertFalse(self.binding['original_1260_proofs_rerun']);self.assertFalse(self.binding['new_correction_substeps'])
 def test_parent0_reusable(self):
  c=self.d['family']['certificates'][0];r=compose(c['program'],c['graph']['sha256'],0)
  self.assertEqual(r['rows'][0]['defects']['P']['epsilonExponentExact'],'99999/50000')
 def test_missing_order_rejected(self):
  with self.assertRaises(SourceError):compose(self.p,self.h,3)
 def test_negative_order_rejected(self):
  with self.assertRaises(SourceError):compose(self.p,self.h,-1)
 def test_missing_high_increment_row_rejected(self):
  p=copy.deepcopy(self.p);p['fiveProducts']['rows'].pop()
  with self.assertRaises(SourceError):compose(p,self.h,2)
 def test_missing_old_gamma_rejected(self):
  p=copy.deepcopy(self.p);del p['temporalProducts']['rows'][0]['fields']['gamma']
  with self.assertRaises(KeyError):compose(p,self.h,2)
 def test_projection_pole_not_sufficient_rejected(self):
  p=copy.deepcopy(self.p);p['callGraph']['calls'][6]['request']['pole']=0
  with self.assertRaises(SourceError):compose(p,self.h,2)
 def test_changed_H0_rejected(self):
  p=copy.deepcopy(self.p);p['fiveProducts']['rows'][0]['fields']['v']['epsilonExponent']='1'
  with self.assertRaises(SourceError):compose(p,self.h,2)
 def test_stale_five_target_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['freshInputDefects'].update(P=0))
 def test_stale_pressure_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['initializedPressure'].update(value=3614634))
 def test_cutoff_zero_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['temporalPressure'].update(cutoffRemainderDeclaredZero=True))
 def test_moment_row_deleted_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['exactFiveRows'].pop())
 def test_wrong_moment_target_sign_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['exactFiveRows'][2].update(target=3614714))
 def test_weight_power_reference_confusion_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['exactFiveRows'][0].update(weightPower=2))
 def test_unproven_potential_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['potential']['checks'][0].update(pass_=False,**{'pass':False}))
 def test_covariance_source_change_rejected(self):self.mutate(lambda d:d['family']['family']['source'].update(parameterExpressionSHA256='wrong'))
 def test_no_admissible_continuation_rejected(self):self.mutate(lambda d:d['family']['family']['scope'].update(sameSourceNormContinuationBound=False))
 def test_source_node_changed_rejected(self):self.mutate(lambda d:d['nodes']['nodes']['3614792'].update(args=[1706782,3614767]))
 def test_full_gamma_replaced_by_desired_rejected(self):self.mutate(lambda d:d['family']['source']['actualRoots']['temporalVelocity'].update(gamma=1706625))
 def test_algebra_receipt_false_rejected(self):self.mutate(lambda d:d['algebra']['checks'][0].update(exact_zero=False))
 def test_all_order_term_inequalities(self):
  p=all_order_proof();self.assertEqual(len(p['terms']),19);self.assertTrue(all(Q(x['margin_to_2H0'])>=0 for x in p['terms']))
 def test_multivariate_binomial_leibniz_coefficients(self):
  # 다중지표별 분할을 차수별로 모으면 이항계수 convolution이 된다.
  import itertools
  alpha=(2,1,0,1,1);total=sum(alpha);sums=[0]*(total+1)
  for beta in itertools.product(*(range(a+1) for a in alpha)):
   sums[sum(beta)]+=math.prod(math.comb(a,b) for a,b in zip(alpha,beta))
  self.assertEqual(sums,[math.comb(total,j) for j in range(total+1)])

class AlgebraNegativeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.packet=json.loads((ROOT/'evidence/ORIGINAL_POLYNOMIAL.json').read_text())
 def test_original_kernel_independent_exact_match(self):self.assertTrue(verify(self.packet)['pass'])
 def test_missing_time_fails(self):
  p=copy.deepcopy(self.packet);p['remainder']['Rg']=p['remainder']['terms']['angular']
  with self.assertRaises(ValueError):verify(p)
 def test_wrong_pressure_linear_coefficient_fails(self):
  p=copy.deepcopy(self.packet);p['remainder']['linear']['JzIntegrand']=p['remainder']['linear']['JthetaIntegrand']
  with self.assertRaises(ValueError):verify(p)
 def test_dropped_quadratic_angular_flux_fails(self):
  p=copy.deepcopy(self.packet);p['remainder']['JthetaIntegrand']=0
  with self.assertRaises(ValueError):verify(p)
 def test_dropped_z_square_fails(self):
  p=copy.deepcopy(self.packet);p['remainder']['JzVelocityIntegrand']=0
  with self.assertRaises(ValueError):verify(p)

if __name__=='__main__':unittest.main(verbosity=2)

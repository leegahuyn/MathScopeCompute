# MathScope M3 — 초기 평균의 빠른 시간·cutoff 연결

## 결과와 판정 범위

이번 추가분은 `temporal_slow_change.json`, `five_slow_change.json`을 변경하지 않고 **빠른 시간 소거, 남는 축 cutoff, 전체 초기 평균 상계식**을 같은 원본에 연결한다. 원래 1,260개 증명 또는 보류한 correction substep을 실행하지 않는다. 운영 사이트와 GitHub도 변경하지 않는다.

M3 **56/64**, N6-01 **OPEN**, N6-02 **PARTIAL / 보정 substep 보류**를 유지한다. 초기 1,260개 완료, Guard/Jet/PDE 잔여 0, 정확 비교 [0,0]은 승계다.

이번에 검증한 연결은 다음과 같다.

| 부분 연결 | 판정 |
|---|---|
| 실제 Δv, γd, 전체 T1γd의 원본 인자·좌표·적분 구간 | 원본 선택 노드와 대조 |
| temporal → five의 빠른 시간 소거와 잔차 분해 | 일반 항등식 및 같은 원본 정의 연결 완료 |
| −ci N(A1γd)의 부호와 positive-IBP 표현 | 기존 표현 3개와 정확 일치, m=0·1의 새 합성 완료 |
| N과 A1을 먼저 교환한 직접 cutoff 식 | 별도 유도 및 원래 연산자 조건 연결 |
| 두 slow_change + 초기 Haar + 필요한 cutoff | 4행의 조건부 정량 상계식 생성 |
| 실제 전체 잔차의 수치 노름 포함구간 | 이번에 발급하지 않음 |
| 원래 다섯 노름의 전칭 완료 판정 | 이번 패키지에서는 새 승격 없음 |

마지막 두 줄의 이유는 상수 ID를 숫자로 평가하지 않았기 때문만은 아니다. 현재 입력은 고정 원본 노름 생성기의 정확한 selector와 **기존 all-finite source norm continuation을 참조하는 상계 증거**다. 이번 연결기는 그 전제하의 합성을 검사한다. 상계 생성기 모든 원본 잎의 해석적 유효성을 새 독립 증명으로 발급하지 않는다. 모든 고차 도함수 배열의 계산이나 모든 상수의 소수 출력은 새 합격 조건으로 추가하지 않았다.

## 1. 원본 식과 실제 ID

첨부 `navier-stokes(20261016-015019).pdf`는 표지에 *FINITE TIME BLOWUP FOR NAVIER–STOKES*, 저자 표시 *OPENAI*를 갖는 166쪽 판본이다. 고정 SHA-256은 `0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f`다. 이번 작업은 이 첨부의 식을 사용한다. 외부 공식성·발표·심사 상태는 이번 작업에서 확인하지 않았다.

정규화 좌표는 `(R,Z,T,Y0,Y1)`이고 band와 common covering index는 계수 미분 동안 고정한다. ε=Q^h, κs=1/100000이며 원본 h를 예시값으로 바꾸지 않는다.

| 대상 | 원본 ID |
|---|---:|
| 초기 Eθ / Ez 정의 body | 643868 / 643883 |
| temporal 역연산자 θ / z | 1696799 / 1698945 |
| ci / ci^-1 | 635063 / 1706622 |
| Δv / γd | 1706624 / 1706626 |
| T1γd / 실제 Δγ | 1706770 / 1706782 |
| A1γd / 그 전체 radial integral | 1706796 / 1706666 |
| five 증분 β / v / γ | 3614789 / 3614767 / 3614771 |
| post-temporal 전체 압력 / 최종 전체 압력 | 3614634 / 3615361 |
| 최종 Eθ / Ez | 3614976 / 3615392 |

초기 Haar pressure ID 633758은 전체 비평균 pressure의 대체물이 아니다. 원본 parent 프로그램의 `initialPressure`, `postPressure`, `updatedPressure` 경로를 유지한다.

## 2. 실제로 연결한 소거

`E0,a° = E0,a − <E0,a>Y`로 둔다. 원문 pp.95–96, (8.19)–(8.22)의 같은 inverse와 potential은

```
Δv = -ci^-1 N^-1 E0,θ°
γd = -ci^-1 N^-1 E0,z°
Δγ = γd - A1 γd
ci N Δv = -E0,θ°
ci N Δγ = -E0,z° - ci N(A1 γd)
```

를 준다. 저장된 Fourier inverse가 인자로 전체 E0를 받아도 zero mode는 내부에서 정확히 제거한다. finite Fourier sum을 무한 극한과 같다고 선언하는 입력을 거부한다.

five 증분은 Y와 무관하고, 기존에 확인된 축 moment가 0이다. 따라서 그 fast N 항은 0이고 axial realization의 A1도 정확히 0이다. 이는 temporal A1을 0으로 두어도 된다는 뜻이 아니다.

따라서 원문 (8.3)의 같은 전체 mean residual에 대해

```
Eθ = Haar(E0,θ) + Ltemporal,θ + Lfive,θ
Ez = Haar(E0,z) + Ltemporal,z + Lfive,z - ci N(A1 γd)
```

이다. 두 L은 앞서 보존한 19개 선형·이차 flux, slow time, 가변 Dr의 두 번 미분, 원통 연결항, 전체 압력 차이를 그대로 사용한다. 압력의 cutoff 항 A0는 전체 δp에 이미 포함되어 있으므로 Ez에 다시 가산하지 않는다. 별도 radial residual에는 `−ρP−A0(gr−ρP)`가 남는다.

## 3. 새로 유도한 직접 cutoff 연결

이 단락은 원문을 인용한 동일 문장이나 별도 원문 식 번호가 아니라, 원문 pp.90–96의 정의·교환 성질을 같은 소스에 적용한 이번 유도다.

A1은 torus-independent cutoff와 R^-1, translated full radial integral의 곱이다. torus 방향의 상수계수 미분 N은 translation 및 이 적분과 가환한다. ci는 고정 common chart에서 R,Y에 무관하므로 A1 밖으로 이동한다. 그러므로

```
-ci N(A1 γd)
 = -ci A1(N γd)
 = -ci A1(-ci^-1 E0,z°)
 = +A1(E0,z°).
```

**최종 부호는 양수**다. 이것은 A1을 버리는 소거가 아니라 A1의 입력을 초기 Ez°로 바꾸는 정확한 항등식이다. 이 항등식을 얻은 후 계수 미분을 적용하므로 ∂Z, ∂T를 움직이는 radial integral과 임의 교환할 필요가 없다.

Haar 중심화의 norm은 원래 norm의 2배로 제어하고 그 2를 새 상수 표현에 남겼다. 모든 boundary·torus mode와 compact-support 조건도 유지했다.

## 4. positive-IBP와 정량 결과

원문 Lemma 8.2, (8.8)–(8.10)은 모든 유한 m,p에 대해 유한한 입력 도함수와 같은 원본 계수 상수로 A_e를 상계한다. 기존 코드의 through-order 계약은 `m+2p+3`이다. 초기 residual의 ε 차수는 `1−κs`이고 p회 IBP 후 차수는 `1−κs+pκs`다.

| 출력 차수 m | 기존 A1 입력 γd | 기존 fast A1의 초기 Ez 요구 | 새 직접 A1의 초기 Ez 요구 |
|---:|---:|---:|---:|
| 0 | 98005 | 98010 | **98005** |
| 1 | 98006 | 98011 | **98006** |

위 표는 p=49001이다. 새 경로는 초기 Ez의 요구 차수 5를 절약한다. 고차 source 프로그램을 실제 실행하거나 모든 도함수를 펼쳤다는 뜻은 아니며, runtime speedup을 측정한 결과도 아니다.

κs=1/100000에서 6/5 지수에 필요한 최소 p는 20001, 149/100 지수에 필요한 최소 p는 49001이다. p=49000은 149/100보다 정확히 1/100000 낮으므로 그 목표에는 부족하다. p=49001을 기존보다 낮추어 처리하지 않았다.

| 항 | 같은 원본 입력 상계하의 정확 ε 차수 |
|---|---:|
| 초기 Haar 평균 | 99999/50000 = 1.99998 |
| temporal 느린 변화 | 199997/100000 = 1.99997 |
| five 느린 변화 | 199997/100000 = 1.99997 |
| fast axial cutoff, p=49001 | 149/100 = 1.49 |
| 합성 Eθ, m=0·1 | **199997/100000** |
| 합성 Ez, m=0·1 | **149/100** |

따라서 두 합성 지수는 6/5보다 크다. 이 비교는 normalized M-class 상계식에 대한 결과다. 현재 m=0·1에서 저장한 실제 scalar DAG와 임의의 유한 차수에 적용하는 일반 Leibniz 합성 정리는 구별한다. 모든 차수의 실제 미분값을 계산했다고 하지 않는다.

상수 C는 source-only expression의 합이고, S의 차수 및 경계 δ의 극 차수는 해당 metadata의 최대다. UI와 JSON은 이를 node 번호가 아니라 `graph hash + node + source selector`로 보존한다. 미실현 natural metadata를 숫자나 0으로 대체하지 않는다.

## 5. 실행과 화면

`python code/run_all.py`가 이번 추가분의 합성, 새 테스트, HTML 생성만 실행한다. 실제 테스트 수·종료 코드·시간은 `evidence/TEST_RECEIPT.json`, `evidence/EXECUTION_RECEIPT.json`에 있다. 기존 증명 재실행은 포함하지 않는다.

새 `index.html`은 소거식, 원본 ID, 상계 ε 차수, 미분 차수, p 요청, 오류와 증거 링크를 연결한다. 지수 비교 그래프는 실제 장의 표본 그래프가 아니다. C·S·ζ·δ를 포함한 전체 잔차 값을 그리지 않으며 이를 화면에 명시했다. 이전 후보는 `inherited/index.html`에 그대로 보존한다.

브라우저의 실제 탐색/조작/내보내기/오류/화면 검사 범위는 `evidence/UI_VALIDATION.json`을 따른다. 운영 URL과 전체 M3 UI의 검수로 확대하지 않는다.

## 6. 실패와 보존

첫 연결기 실행은 multiply node를 재귀적으로 분해하는 검사에서 한쪽만 분해하여 false mismatch를 냈다. 같은 원본 인자를 양쪽 모두 같은 규칙으로 분해하여 수정했다. `BUILD_ATTEMPT1.log`와 회귀 테스트를 보존했다. 이 실패는 수학 반례나 기존 증명의 실패가 아니다.

새 파일은 별도 폴더에 생성했고 `inherited/` 입력을 변경하지 않았다. 해시 장부는 파일 무결성 기록이며 수학적 정확성의 대체물이 아니다.


## 최종 실행 확인

- 새 테스트 **37/37** 통과. 기존 49개를 다시 세거나 1260개 증명과 합산하지 않았다.
- 두 증거 묶음에서 겹치는 선택 원본 노드 정의 **1,018건 대조 일치**. 이는 고유 원본 ID 개수 또는 새 수학 의무 개수가 아니다.
- 별도 디렉터리에서 기존 생성 결과를 삭제한 후 다시 실행하여 **결과 JSON 9개와 HTML 1개가 바이트 단위 일치**했다.
- Chromium DOM 컴포넌트 **29/29** 통과: 원본 ID, 차수 변경, p 부등식, 오류, 키보드 복원, 실제 요청 JSON 내보내기, 현재 링크 파일, 390/768px 수평 넘침과 차트 글자 크기 포함.
- file URL 탐색은 `ERR_BLOCKED_BY_ADMINISTRATOR`로 차단되어 **증거 링크 클릭 후 실제 URL 이동·reload는 미검사**다. 정책을 변경하지 않았고 새 about:blank 페이지에 동일한 로컬 HTML을 주입하여 조작만 검사했다. 실제 blob JSON 내보내기는 이 DOM에서 성공했다.
- 최초 차단 직후 같은 페이지에 DOM을 넣으려다 execution context가 사라진 실패도 보존했다. 새 빈 페이지로 DOM 검사 대상을 분리하여 해결했으며 URL 정책을 우회한 것이 아니다.
- 모바일 축소 차트의 글자가 작아지는 점을 확인하여 모바일용 viewBox로 재배치하고 29개 화면 검사를 다시 통과했다.

실제 로그와 수치는 EXECUTION_RECEIPT, TEST_RECEIPT, REPLAY_VERIFICATION, UI_VALIDATION을 최종 기준으로 한다. 해시 장부는 HASH_MANIFEST.json이다.

"""새 디렉터리·새 프로세스에서 이번 추가분만 재현한다."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parents[1]
ARTIFACTS=['SOURCE_BINDINGS.json','FAST_TIME_IDENTITIES.json','IBP_TEMPLATE_COMPARISON.json','INITIAL_HAAR_M0_M1.json',
 'FAST_CUTOFF_MEAN_REPORT.json','IBP_FAST_A1_m0_p49001.json','IBP_FAST_A1_m1_p49001.json',
 'IBP_DIRECT_A1_m0_p49001.json','IBP_DIRECT_A1_m1_p49001.json']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
  with tempfile.TemporaryDirectory(prefix='mathscope-fast-replay-') as t:
    target=Path(t)/'package'
    shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    # 새 결과는 실제로 지운 뒤 재생성한다. 단순 복사된 결과 비교가 아니다.
    for n in ARTIFACTS:(target/'evidence'/n).unlink()
    (target/'index.html').unlink()
    command=[sys.executable,str(target/'code/run_all.py')];start=time.monotonic()
    p=subprocess.run(command,cwd=target,capture_output=True,text=True,timeout=40)
    (ROOT/'evidence/REPLAY.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
    rows=[]
    for name in ['evidence/'+n for n in ARTIFACTS]+['index.html']:
      old=sha(ROOT/name);new=sha(target/name) if (target/name).is_file() else None
      rows.append({'path':name,'expected_sha256':old,'replayed_sha256':new,'byte_identical':old==new})
    r={'schema':'MathScope.FastCutoffIndependentProcessReplay/1','seconds':round(time.monotonic()-start,6),
       'command':['python','code/run_all.py'],'exit_code':p.returncode,'generated_outputs_removed_before_replay':True,
       'checks':rows,'all_byte_identical':all(x['byte_identical'] for x in rows),'old_1260_proofs_rerun':False,
       'meaning':'새 디렉터리 실행 재현. 독립된 별개의 수학적 증명이라고 세지 않음.'}
    (ROOT/'evidence/REPLAY_VERIFICATION.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'exit_code':p.returncode,'matched':sum(x['byte_identical'] for x in rows),'total':len(rows)},ensure_ascii=False))
    if p.returncode or not r['all_byte_identical']:raise SystemExit(1)
if __name__=='__main__':main()

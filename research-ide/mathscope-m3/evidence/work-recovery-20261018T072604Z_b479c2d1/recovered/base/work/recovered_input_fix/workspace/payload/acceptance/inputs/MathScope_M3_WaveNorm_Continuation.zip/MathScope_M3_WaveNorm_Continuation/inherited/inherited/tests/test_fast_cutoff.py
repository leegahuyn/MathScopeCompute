"""새 연결기의 검증. 기존 1260 PDE/Guard/Jet 실행은 포함하지 않는다."""
from __future__ import annotations
import copy, json, sys, tempfile, unittest
from fractions import Fraction as Q
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
import fast_cutoff_bridge as b

class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=b.read_inputs();cls.result=b.build(cls.data)

    def test_narrow_inputs_are_hash_bound(self):
        self.assertEqual(len(self.data),9)
    def test_original_pressure_not_haar_pressure(self):
        r=self.result['bindings']['pressure_sources']
        self.assertEqual(r['initialized_full'],3615361)
        self.assertNotEqual(r['initial_Haar_only'],r['initialized_full'])
    def test_selected_original_nodes_match(self):
        self.assertGreater(self.result['bindings']['selected_overlap_comparisons'],100)
        self.assertTrue(self.result['bindings']['source_body_bindings_pass'])
    def test_no_old_proof_run_or_progress_promotion(self):
        r=self.result['report']
        self.assertFalse(r['old_proofs_rerun']);self.assertFalse(r['correction_substeps_rerun'])
        self.assertEqual(r['remote_writes'],0);self.assertEqual(r['inherited']['M3'],'56/64')
        self.assertEqual(r['inherited']['exact_difference_interval'],['0','0'])
        self.assertIn('deferred',r['inherited']['N6-02'])
    def test_saved_ibp_programs_exactly_preserved(self):
        self.assertEqual(len(self.result['ibp_matches']),3)
        self.assertTrue(all(x['exact_saved_expression_match'] for x in self.result['ibp_matches']))
    def test_cutoff_not_deleted(self):
        self.assertTrue(all(not x['outputs']['fastA1']['cutoffDeclaredZero'] for x in self.result['cutoffs']))
    def test_source_derivative_demand(self):
        self.assertEqual(self.result['cutoffs'][0]['derivative_demand'],
          {'A_e_input_order':98005,'fast_A1_desired_input_order':98006,'fast_A1_initial_Ez_order':98010})
    def test_next_derivative_source_demand(self):
        self.assertEqual(self.result['cutoffs'][1]['derivative_demand']['fast_A1_initial_Ez_order'],98011)
    def test_direct_route_saves_five_not_more(self):
        for m,p in enumerate(self.result['direct_cutoffs']):
            b.verify_direct_program(p,self.data['cutoff']['authority'])
            self.assertEqual(p['derivative_demand']['initial_Ez_order'],m+98005)
            self.assertEqual(p['derivative_demand']['saved_source_derivative_orders'],5)
            self.assertFalse(p['upstream_high_order_program_executed'])
    def test_direct_route_keeps_centering_factor_two(self):
        p=self.result['direct_cutoffs'][0]
        self.assertEqual(p['output']['centering_norm_factor'],2)
        self.assertEqual(p['output']['sign_in_residual'],1)
        self.assertEqual(p['output']['source_expression']['argument']['body'],643883)
    def test_finite_ibp_threshold(self):
        self.assertEqual(b.minimum_ibp(Q(6,5)),20001)
        self.assertEqual(b.minimum_ibp(Q(149,100)),49001)
        self.assertLess(1-b.K+49000*b.K,Q(149,100))
    def test_raw_and_direct_route_same_exponent(self):
        for raw,direct in zip(self.result['cutoffs'],self.result['direct_cutoffs']):
            self.assertEqual(raw['outputs']['fastA1']['epsilonExponent'],direct['output']['epsilonExponent'])
    def test_composed_normalized_exponents(self):
        for row in self.result['report']['rows']:
            expected='199997/100000' if row['field']=='Etheta' else '149/100'
            self.assertEqual(row['composed_bound']['epsilonExponentExact'],expected)
            self.assertGreater(Q(row['margin_over_6_5']),0)
    def test_latest_full_Ez_bound_source(self):
        ids={r['actual_final_source_id'] for r in self.result['report']['rows']}
        self.assertEqual(ids,{3614976,3615392})
    def test_pressure_not_counted_twice(self):
        for row in self.result['report']['rows']:
            terms=row['terms']
            self.assertEqual(len(terms),3 if row['field']=='Etheta' else 4)
            self.assertFalse(any('A0' in name for name in terms))
    def test_uncancelled_axial_cutoff_sign(self):
        for row in self.result['report']['rows']:
            if row['field']=='Ez': self.assertEqual(row['terms']['negative_fast_A1']['sign_in_residual'],-1)
    def test_no_scalar_id_is_a_numeric_constant(self):
        for row in self.result['report']['rows']:
            self.assertIsNone(row['composed_bound']['numerical_constant'])
            self.assertTrue(all(isinstance(x,dict) for x in row['composed_bound']['constant']['args']))
    def test_haar_graph_references_resolve(self):
        h=self.result['haar'];self.assertEqual(b.digest(h['scalar_nodes']),h['new_graph_hash'])
        for row in h['rows']:
            for field in row['fields'].values():
                self.assertEqual(field['constant']['graph'],h['new_graph_hash'])
                self.assertLess(field['constant']['node'],len(h['scalar_nodes']))
                self.assertEqual(field['epsilonExponentExact'],'99999/50000')
    def test_every_slow_group_above_minimum(self):
        r=b.all_order_slow_lemma()
        self.assertTrue(all(Q(v)>=2-3*b.K for v in r['group_exponents'].values()))
    def test_source_files_not_modified_by_build(self):
        again=b.read_inputs()
        self.assertEqual(again['temporal']['new_graph_hash'],self.data['temporal']['new_graph_hash'])
        self.assertEqual(again['five']['new_graph_hash'],self.data['five']['new_graph_hash'])
    def test_wrong_latest_pressure_rejected(self):
        x=copy.deepcopy(self.data);x['cutoff']['authority']['actualRoots']['initializedPressure']['value']=3614634
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_mixed_source_hash_rejected(self):
        x=copy.deepcopy(self.data);x['cutoff']['authority']['source']['sourceNodePrefixSHA256']='0'*64
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_saved_graph_mutation_rejected(self):
        x=copy.deepcopy(self.data);x['temporal']['scalar_nodes'][-1]={'op':'rational','args':['0','1']}
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_dropped_pressure_flag_rejected(self):
        x=copy.deepcopy(self.data);x['five']['pressure_difference_retained']=False
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_double_cancellation_rejected(self):
        x=copy.deepcopy(self.data);x['temporal']['fast_time_cancellation_applied']=True
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_fewer_flux_terms_rejected(self):
        x=copy.deepcopy(self.data);x['five']['flux_terms_retained']=18
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_wrong_inverse_zero_mode_rejected(self):
        x=copy.deepcopy(self.data);x['cutoff']['authority']['bodies']['temporal']['zDefinition']['zeroMode']='kept'
        with self.assertRaises(b.BridgeError):b.validate_sources(x)
    def test_insufficient_haar_order_rejected(self):
        p=self.data['family']['certificates'][1]
        with self.assertRaises(b.BridgeError):b.compose_haar(p['program'],p['graph']['sha256'],3)
    def test_invalid_order_and_ibp_rejected(self):
        a=self.data['cutoff']['authority']
        for m,p in [(True,1),(-1,1),(0,0),(0,1.2),(1,-1)]:
            with self.subTest(m=m,p=p),self.assertRaises(b.BridgeError):b.ibp_program(a,m,p)
    def test_direct_mutation_rejected(self):
        x=copy.deepcopy(self.result['direct_cutoffs'][0]);x['output']['centering_norm_factor']=1
        with self.assertRaises(b.BridgeError):b.verify_direct_program(x,self.data['cutoff']['authority'])
    def test_derivative_loss_mutation_rejected(self):
        x=copy.deepcopy(self.result['cutoffs'][0]);x['derivative_demand']['fast_A1_initial_Ez_order']-=4
        with self.assertRaises(b.BridgeError):b.verify_ibp_program(x,self.data['cutoff']['authority'])
    def test_different_weight_sum_rejected(self):
        with self.assertRaises(b.BridgeError):b.expression_sum([{'weight':'sqrt_zeta'}])
    def test_generic_telescope_is_exact(self):
        r=self.result['identities']
        self.assertTrue(r['all_zero']);self.assertFalse(r['commuted_cutoff_identity']['slow_derivatives_commuted'])
    def test_independent_fourier_multiplier_commutation(self):
        # A1 is diagonal in torus frequencies; J_k below is its full radial integral.
        # This independent calculation includes nonzero mode, projection and two minus signs.
        import sympy as s
        ci,omega,Jk,E=s.symbols('ci omega Jk E',nonzero=True)
        multiplier=s.I*2*s.pi*omega
        gamma=-E/(ci*multiplier)
        direct=s.simplify(-ci*multiplier*Jk*gamma - Jk*E)
        self.assertEqual(direct,0)
        wrong=s.simplify(ci*multiplier*Jk*gamma-Jk*E)
        self.assertNotEqual(wrong,0)
    def test_zero_mode_not_divided(self):
        # The algebraic inverse applies to k !=0 only; Haar projection supplies zero at k=0.
        import sympy as s
        k0,k1=s.symbols('k0 k1',integer=True);v=s.sqrt(2)-1
        for k in [(1,0),(0,1),(1,-1),(-2,3),(-1,0)]:
            self.assertNotEqual(s.simplify(v*k[0]+k[1]),0)
        self.assertEqual(v*0+0,0)
        self.assertEqual(self.data['cutoff']['authority']['bodies']['temporal']['zDefinition']['finiteSumDeclaredEqualToLimit'],False)
    def test_independent_variable_radial_operator(self):
        import sympy as s
        r,y=s.symbols('r y',real=True);a=s.Function('a')(r);f=s.Function('f')(r,y)
        Dr=lambda u:s.diff(u,r)+a*s.diff(u,y)
        expanded=s.expand(Dr(Dr(f)))
        expected=s.diff(f,r,2)+2*a*s.diff(f,r,y)+s.diff(a,r)*s.diff(f,y)+a*a*s.diff(f,y,2)
        self.assertEqual(s.simplify(expanded-expected),0)
        self.assertNotEqual(s.simplify(expanded-(expected-s.diff(a,r)*s.diff(f,y))),0)
    def test_factor_flattening_does_not_change_node_ids(self):
        n={'1':{'op':'multiply','args':[2,3]},'2':{'op':'multiply','args':[4,5]},
           '3':{'op':'variable','args':[]},'4':{'op':'rational','args':['2','1']},'5':{'op':'variable','args':[]}}
        self.assertEqual(b.factors(n,1),[4,5,3])
        self.assertEqual(b.factors(n,2)+b.factors(n,3),b.factors(n,1))

if __name__=='__main__':unittest.main(verbosity=2)

"""후보 화면 검사. 파일 탐색 정책이 차단되면 정책을 변경하지 않고 DOM 검사만 기록."""
from pathlib import Path
import json,hashlib
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
def main():
 checks=[];errors=[];attempts=[]
 def check(name,ok):
  checks.append({'name':name,'pass':bool(ok)})
  if not ok:raise AssertionError(name)
 html=(ROOT/'index.html').read_text();mode='file_navigation'
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1280,'height':1000},device_scale_factor=1,accept_downloads=True)
  page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.goto((ROOT/'index.html').as_uri(),wait_until='load',timeout=10000);attempts.append({'mode':mode,'success':True})
  except Exception as exc:
   attempts.append({'mode':mode,'success':False,'error':str(exc)});mode='DOM_component_set_content'
   page.close();page=browser.new_page(viewport={'width':1280,'height':1000},device_scale_factor=1,accept_downloads=True);page.on('pageerror',lambda e:errors.append(str(e)))
   page.set_content(html,wait_until='load')
  page.wait_for_selector('html[data-render-ready="true"]')
  check('M3 분모와 상태',page.locator('#m3').inner_text()=='56 / 64')
  check('보류 범위 표시','N6-02 PARTIAL · 보정 substep 보류' in page.locator('body').inner_text())
  check('1260 승계와 비교오차 표시','1,260개 검증 완료' in page.locator('body').inner_text() and '[0,0]' in page.locator('#inherited').inner_text())
  check('조건부 정리 적용 표시','입력 노름 전제하' in page.locator('#scope').inner_text())
  check('Jz 실제 ID와 보존 나머지',page.locator('#current-id').inner_text()=='3615147' and page.locator('#remainder-id').inner_text()=='3615848')
  check('Jz 압력 음의 반항 유지','− ½∫ R²' in page.locator('#formula').inner_text())
  check('정확 지수와 여유',page.locator('#exponent').inner_text()=='99999/50000' and page.locator('#margin').inner_text()=='39999/50000')
  check('실제 데이터 다섯 그룹과 열개 표시',page.locator('#rows tr').count()==5 and page.locator('#chart circle').count()==10)
  check('그림과 함수값 구별','실제 함수 크기 그래프가 아니다' in page.locator('body').inner_text())
  check('상수 노드 수치 혼동 방지','수치 C 미출력' in page.locator('#constant').inner_text())
  page.fill('#order','2')
  check('2차 실제 로그차수 동기화','S_*^18168' in page.locator('#bound').inner_text())
  page.select_option('#field','Jtheta')
  check('Jtheta ID 동기화',page.locator('#current-id').inner_text()=='3615101' and page.locator('#remainder-id').inner_text()=='3615673')
  check('Jtheta 미분상계 동기화','S_*^17757' in page.locator('#bound').inner_text())
  check('선택 증거 링크 동기화',page.locator('#application-link').get_attribute('href').endswith('#Jtheta-m2'))
  page.click('#inspect')
  inline=json.loads(page.locator('#evidence-json').inner_text())
  check('인라인 증거가 실제 상계와 연결',page.locator('#evidence-panel').is_visible() and inline['selection']['current_source_id']==3615101 and inline['selection']['bound']['power']==17757 and bool(inline['constant_sources']) and inline['domain']['oneFinitePrefixClaimedValidAtAllQ'] is False)
  page.select_option('#field','P')
  check('열린 증거도 P로 갱신','3615055' in page.locator('#evidence-json').inner_text())
  page.fill('#order','3')
  check('미실행 고차수 입력 거부','입력 오류' in page.locator('#error').inner_text() and page.locator('#export').is_disabled())
  check('잘못된 입력에 오래된 결과 숨김',page.locator('#result').is_hidden() and page.locator('#rows tr').count()==0)
  page.fill('#order','1.5');check('정수가 아닌 차수 거부','입력 오류' in page.locator('#error').inner_text())
  page.fill('#order','');check('빈 입력 거부',page.locator('#export').is_disabled())
  page.locator('#reset').focus();page.keyboard.press('Enter')
  check('키보드 초기화',page.locator('#order').input_value()=='0' and page.locator('#field').input_value()=='Jz' and page.locator('#error').inner_text()=='')
  with page.expect_download() as dd:page.click('#export')
  dd.value.save_as(str(ROOT/'evidence/EXPORTED_SELECTION.json'))
  ex=json.loads((ROOT/'evidence/EXPORTED_SELECTION.json').read_text())
  check('내보낸 수치·원본·범위 일치',ex['selection']['current_source_id']==3615147 and ex['selection']['bound']['epsilonExponentExact']=='99999/50000' and ex['defect_value_is_zero'] is False and ex['M3']=='56/64')
  for a in page.locator('a[href]').all():
   href=a.get_attribute('href').split('#')[0];check('증거 파일 존재:'+href,(ROOT/href).is_file())
  # 실제 파일 이동이 허용된 환경에서만 외부 증거 페이지 왕복을 판정한다.
  if mode=='file_navigation':
   page.click('#application-link');page.wait_for_load_state('load');check('파일 증거 링크 탐색','MathScope.CurrentDefectNormApplication/1' in page.locator('body').inner_text())
   page.go_back(wait_until='load');page.wait_for_selector('html[data-render-ready="true"]');check('화면으로 복귀',page.locator('#m3').inner_text()=='56 / 64')
  page.locator('#inspect').evaluate("el=>{if(el.getAttribute('aria-expanded')==='true')el.click()}")
  page.evaluate('window.scrollTo(0,0)');check('데스크톱 가로 넘침 없음',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  page.screenshot(path=str(ROOT/'evidence/UI_DESKTOP.png'),full_page=True)
  for width in [390,720]:
   page.set_viewport_size({'width':width,'height':844});page.evaluate('window.scrollTo(0,0)')
   check(f'{width}px 가로 넘침 없음',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   check(f'{width}px 읽을 수 있는 비교카드',page.locator('#mobile-chart').is_visible() and page.locator('#mobile-chart .group-card').count()==5)
   check(f'{width}px 좁은 중복표 대신 상계 세부값 제공',page.locator('.table-wrap').is_hidden() and page.locator('#mobile-chart .caption').count()==5 and '경계 극 차수' in page.locator('#mobile-chart').inner_text())
   check(f'{width}px 조작영역44px',all(x.bounding_box()['height']>=44 for x in page.locator('select,input,button').all() if x.is_visible()))
   if width==390:page.screenshot(path=str(ROOT/'evidence/UI_MOBILE.png'),full_page=True)
  check('브라우저 JS 오류 없음',not errors)
  version=browser.version;browser.close()
 result={'schema':'MathScope.DefectBridgeUIValidation/1','mode':mode,'checks':checks,'passed':sum(x['pass'] for x in checks),'total':len(checks),'browser_version':version,
  'html_sha256':hashlib.sha256(html.encode()).hexdigest(),'navigation_attempts':attempts,'errors':errors,
  'operating_site_tested':False,'remote_published':False,'file_links_navigated':mode=='file_navigation','inline_evidence_interaction_tested':True,
  'limitations':['파일 URL 정책 차단 시 상대링크 존재/내용 결속과 인라인 증거만 검사; 운영 URL 탐색 성공으로 표시하지 않음'] if mode!='file_navigation' else []}
 (ROOT/'evidence/UI_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'passed':result['passed'],'total':result['total'],'mode':mode,'remote_published':False},ensure_ascii=False))
if __name__=='__main__':main()

"""새 노름 대수의 독립 다항식 대조. 보류된 실제 correction substep PDE 재검증 아님."""
import unittest
import sympy as s

class IndependentFluxTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.b,cls.V,cls.G,cls.beta,cls.v,cls.gamma,cls.db,cls.dv,cls.dg,cls.W,cls.p,cls.dp=s.symbols('b V G beta v gamma db dv dg W p dp')
 def test_theta_radial_five_terms(self):
  b,V,be,v,db,dv,W=self.b,self.V,self.beta,self.v,self.db,self.dv,self.W
  old=b*v+be*V+be*v+W;new=b*(v+dv)+(be+db)*V+(be+db)*(v+dv)+W
  self.assertEqual(s.expand(new-old-(b*dv+be*dv+V*db+v*db+db*dv)),0)
 def test_theta_axial_five_terms(self):
  G,V,ga,v,dg,dv,W=self.G,self.V,self.gamma,self.v,self.dg,self.dv,self.W
  old=G*v+V*ga+ga*v+W;new=G*(v+dv)+V*(ga+dg)+(ga+dg)*(v+dv)+W
  self.assertEqual(s.expand(new-old-(G*dv+ga*dv+V*dg+v*dg+dg*dv)),0)
 def test_axial_radial_five_terms(self):
  b,G,be,ga,db,dg,W=self.b,self.G,self.beta,self.gamma,self.db,self.dg,self.W
  old=b*ga+be*G+be*ga+W;new=b*(ga+dg)+(be+db)*G+(be+db)*(ga+dg)+W
  self.assertEqual(s.expand(new-old-(b*dg+be*dg+G*db+ga*db+db*dg)),0)
 def test_axial_axial_pressure_four_terms(self):
  G,ga,dg,W,p,dp=self.G,self.gamma,self.dg,self.W,self.p,self.dp
  self.assertEqual(s.expand((2*G*(ga+dg)+(ga+dg)**2+W+p+dp)-(2*G*ga+ga**2+W+p)-(2*G*dg+2*ga*dg+dg**2+dp)),0)
 def test_quadratic_term_omission_detected(self):
  be,v,db,dv=self.beta,self.v,self.db,self.dv
  self.assertEqual(s.expand((be+db)*(v+dv)-be*v-be*dv-v*db),db*dv)
 def test_variable_radial_operator_keeps_coefficient_derivative(self):
  R,y=s.symbols('R y');a=s.Function('a')(R);f=s.Function('f')(R,y)
  D=lambda x:s.diff(x,R)+a*s.diff(x,y)
  expected=s.diff(f,R,2)+2*a*s.diff(f,R,y)+s.diff(a,R)*s.diff(f,y)+a*a*s.diff(f,y,2)
  self.assertEqual(s.expand(D(D(f))-expected),0)
 def test_vector_laplacian_connection_not_scalar(self):
  R=s.symbols('R',positive=True);u=s.Function('u')(R)
  scalar=s.diff(u,R,2)+s.diff(u,R)/R;vector=scalar-u/R**2
  self.assertEqual(s.simplify(scalar-vector),u/R**2)
if __name__=='__main__':unittest.main()

from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as Q
from math import comb, factorial
from typing import Sequence

@dataclass(frozen=True)
class Envelope:
    """|increment| <= C q^(g-loss) (1+|log q|)^P 의 C,P,g."""
    C: Q
    P: int
    g: Q

    def __post_init__(self):
        if not isinstance(self.C, Q) or not isinstance(self.g, Q):
            raise TypeError("C와 g에는 Fraction을 사용하세요.")
        if self.C < 0 or self.g <= 0 or self.P < 0:
            raise ValueError("C>=0, g>0, 정수 P>=0이 필요합니다.")
        if not isinstance(self.P, int):
            raise TypeError("P는 정수여야 합니다.")

def ln2_interval(terms: int = 24) -> tuple[Q, Q]:
    """log(2)=2*atanh(1/3)의 엄밀한 유리수 포함구간."""
    if terms < 1:
        raise ValueError("terms>=1")
    z = Q(1, 3)
    lower = 2 * sum((z**(2*n+1) / (2*n+1)
                     for n in range(terms)), Q(0))
    remainder = 2*z**(2*terms+1) / ((2*terms+1)*(1-z*z))
    return lower, lower + remainder

def power2(exponent: int, bit_budget: int = 1_000_000) -> Q:
    if abs(exponent) > bit_budget:
        raise RuntimeError("계산 비트 예산 초과: 수학적 부등식 실패가 아닙니다.")
    return Q(1 << exponent) if exponent >= 0 else Q(1, 1 << -exponent)

def cutoff_condition(e: Envelope, j: int, k: int) -> bool:
    """전 구간 0<q<=2^-k에서 C log(q)^P q^(g/2)<=2^-j의 충분조건."""
    if j < 1 or k < 0:
        raise ValueError("j>=1, k>=0")
    if e.C == 0:
        return True
    lo, hi = ln2_interval()
    beta = e.g / 2
    # s=-log(q)에서 (1+s)^P exp(-beta*s)가 감소하는 구간.
    if beta * (1 + k*lo) < e.P:
        return False
    x = beta*k
    floor_x = x.numerator // x.denominator
    return e.C * (1+k*hi)**e.P <= power2(floor_x-j)

def choose_cutoff(j: int, envelopes: Sequence[Envelope],
                  previous_k: int | None, q0: Q,
                  max_doublings: int = 256) -> dict:
    """a_j=2^k. 모든 0<=m<=j 입력이 필요하며 누락 상계는 허용하지 않음."""
    if j < 1 or len(envelopes) != j+1:
        raise ValueError("해당 j의 m=0,...,j 상계가 모두 필요합니다.")
    if not isinstance(q0, Q) or not 0 < q0 <= 1:
        raise ValueError("q0는 0<q0<=1인 Fraction이어야 합니다.")
    if (j == 1) != (previous_k is None):
        raise ValueError("j=1만 previous_k=None이며 이후에는 이전 k가 필요합니다.")
    k = max(1, 1 + previous_k) if previous_k is not None else 1
    for _ in range(max_doublings):
        inside = power2(-k) < q0
        checks = [cutoff_condition(e, j, k) for e in envelopes]
        if inside and all(checks):
            return {
                "j": j, "log2_a": k,
                "derivative_orders": list(range(j+1)),
                "all_q_interval": f"0 < q <= 2^(-{k})",
                "inequality_checks": checks,
                "scope": "제공된 C,P,g 상계가 성립한다는 가정 아래의 선택 증명"
            }
        # 충분조건의 계단 효과 때문에 단조성을 가정한 이분 탐색은 하지 않음.
        k *= 2
    raise RuntimeError("반복 예산 초과: 실제 상계 입력과 예산을 확인하세요.")

def extension_constant(j: int, m: int, cutoff_norms: Sequence[Q]) -> Q:
    """(10.12)의 C_{j,m}; cutoff_norms[a]>=||chi^(a)||_infinity."""
    if j < 0 or m < 0 or len(cutoff_norms) <= m:
        raise ValueError("필요한 cutoff 도함수 상계가 누락됐습니다.")
    if any(not isinstance(v, Q) or v < 0 for v in cutoff_norms):
        raise ValueError("cutoff 상계는 음이 아닌 Fraction이어야 합니다.")
    return sum((Q(comb(m,a))*cutoff_norms[a]/factorial(j-m+a)
                for a in range(max(0,m-j), m+1)), Q(0))

def choose_b(j: int, previous_b: int, force_norms: Sequence[Q],
             cutoff_norms: Sequence[Q]) -> dict:
    """전체 공간 ||F_j||_{C^a} 상계로 정의되는 최소 증가 정수 b_j."""
    if j < 1 or previous_b < 1:
        raise ValueError("j>=1, previous_b>=1")
    order = j//2
    if len(force_norms) <= order or len(cutoff_norms) <= order:
        raise ValueError("a,m<=floor(j/2)에 필요한 실제 상계가 없습니다.")
    if any(not isinstance(v, Q) or v < 0 for v in force_norms):
        raise ValueError("force 상계는 음이 아닌 Fraction이어야 합니다.")
    constraints = [
        (a, m, power2(j)*extension_constant(j,m,cutoff_norms)*force_norms[a])
        for a in range(order+1) for m in range(order-a+1)
    ]
    def good(b: int) -> bool:
        return all(Q(b**(j-m)) >= rhs for a,m,rhs in constraints)
    low, high = previous_b, previous_b+1
    for _ in range(256):
        if good(high):
            break
        high *= 2
    else:
        raise RuntimeError("b_j 탐색 예산 초과")
    # 양의 지수 j-m이므로 여기의 판정은 b에 대해 단조적.
    while high-low > 1:
        middle = (low+high)//2
        if good(middle):
            high = middle
        else:
            low = middle
    return {
        "j": j, "b": high, "constraint_count": len(constraints),
        "minimal_above_previous": high == previous_b+1 or not good(high-1),
        "scope": "제공된 전체 F_j 및 cutoff 상계가 성립한다는 가정 아래"
    }

def extension_tail(J: int, spatial_order: int, time_order: int) -> Q:
    """모든 후속 b_j 선택 조건을 전제로 한 혼합 도함수 tail <= 2^-J."""
    if min(J, spatial_order, time_order) < 0:
        raise ValueError("음이 아닌 차수만 허용됩니다.")
    if J+1 < 2*(spatial_order+time_order):
        raise ValueError("생략된 첫 항부터 (10.12)의 차수 조건이 필요합니다.")
    return power2(-J)

def local_tail_log2(J: int, m: int, minus_log2_q: Q,
                    log2_a_J: int, g_next: Q, loss: Q) -> Q:
    """(5.35) 상계의 정확 log2. 전체 후속 항의 상계 가정은 별도 증거."""
    if J < max(1,m) or m < 0 or g_next <= 0 or loss < 0:
        raise ValueError("Lemma 5.4의 차수 및 감쇠 조건 위반")
    if minus_log2_q <= log2_a_J+1:
        raise ValueError("q < 1/(2*a_J) 조건 위반")
    return -Q(J) - minus_log2_q*(g_next/2-loss)

def physical_loss(A: Q, h: Q, m: int) -> Q:
    """원문 p114: ell_m=2A+(m+1)(1+3h/2). 실제 A,h 입력 필요."""
    if A <= 0 or not 0 < h < Q(1,100) or m < 0:
        raise ValueError("원문 매개변수 범위 또는 미분 차수 위반")
    return 2*A + (m+1)*(1+3*h/2)

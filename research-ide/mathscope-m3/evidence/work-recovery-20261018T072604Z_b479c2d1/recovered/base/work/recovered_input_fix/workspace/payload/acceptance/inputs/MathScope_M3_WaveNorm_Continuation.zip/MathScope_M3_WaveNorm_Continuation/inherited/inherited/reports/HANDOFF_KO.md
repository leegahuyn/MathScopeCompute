# 다음 재개점 — Fast/Cutoff 연결 이후

기준: M3 56/64, N6-01 OPEN, N6-02 PARTIAL 및 보정 substep 보류. 초기 1260 / Guard=Jet=PDE=0 / [0,0] 승계. 원격 변경 없음.

## 바로 사용할 결과

- `evidence/FAST_CUTOFF_MEAN_REPORT.json`: m=0,1의 같은 소스 합성 Eθ/Ez 상계.
- `evidence/FAST_TIME_IDENTITIES.json`: 정확한 두 residual 합성식과 cutoff 부호.
- `evidence/IBP_FAST_A1_m{0,1}_p49001.json`: 기존 경로; 원래 3개 저장 IBP 프로그램과 exact match.
- `evidence/IBP_DIRECT_A1_m{0,1}_p49001.json`: **-ci N A1γd = +A1(E0z-Haar E0z)** 직접 경로. 초기 Ez 요구 m+98005, 기존 경로 m+98010.
- `evidence/INITIAL_HAAR_M0_M1.json`: 같은 원본 parent 요청2에 연결된 새 Haar 0·1차 DAG.
- 원래 temporal/five 19항 결과는 `inherited/evidence/`에서 바이트 그대로 유지한다.

## 다음 수학 작업

이번 소거·cutoff 연결을 다시 만들 필요가 없다. 다음은 같은 P3615055/Jθ3615101/Jz3615147의 **현재 결함 = 기존 nonlinear remainder**를 정량 노름 적용에서 소비하고, wave3825348/9/50의 원래 ±1,±2 주항·전체 교차항·tail을 연결하는 것이다.

이번 평균 상계는 same-source norm continuation의 입력 상계를 전제로 한다. 기존 증거로 충족된 전제는 재증명하지 않고 적용 장부에 소비한다. 전칭 mean ID를 최종 판정할 때 누락된 원본 전제가 실제로 있는지 여부를 특정하되, 상수의 소수 출력이나 고차 도함수 배열 전체를 새 완료 조건으로 추가하지 않는다. 이번 패키지는 이 독립 전칭 판정을 자동 승격하지 않았다.

직접 A1 경로를 추가 구현할 때 full E0z를 그대로 쓰지 말고 **zero-Haar projection**을 유지하며 상수의 중심화 인자2를 남긴다. slow derivatives는 T1/Ic와 무조건 commute하지 않는다. pressure A0를 Ez에 추가하면 이미 전체 δp에 포함된 항을 이중계산한다.

## 최소 재현

```
python code/run_all.py
python code/browser_check.py  # Playwright/Chromium이 있는 환경에서 로컬 화면 검사
```

새 생성기/소비기만 실행한다. 기존1260 증명과 N6-02 보정 substep 실행 명령은 포함하지 않는다. 원격 게시·main 병합도 없다.

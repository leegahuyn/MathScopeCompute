"""실제 로컬 Chromium에서 후보 화면을 조작한다. 운영 사이트 테스트가 아니다."""
from __future__ import annotations
from pathlib import Path
import json,hashlib
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
def run():
 checks=[];errors=[]
 html=(ROOT/'index.html').read_text(encoding='utf-8');local_url='about:blank; set_content local HTML (no navigation)'
 def check(name,value):
  ok=bool(value);checks.append({'name':name,'pass':ok})
  if not ok:raise AssertionError(name)
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=browser.new_page(viewport={'width':1280,'height':1000},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html);page.wait_for_selector('html[data-render-ready="true"]')
  check('원래 M3 56/64 표시',page.locator('#m3-count').inner_text()=='56 / 64')
  check('초기1260 승계와 보정substep 보류', '1,260 완료' in page.locator('body').inner_text() and '보정 substep 재검증은 보류' in page.locator('body').inner_text())
  check('실제 SVG 지수 그래프 표시',page.locator('#exponent-chart svg circle').count()==5)
  check('기본 최신압력 원본 ID 표시','3615361' in page.locator('#target-scope').inner_text())
  check('기본 상계표 세 성분',page.locator('#bound-table tbody tr').count()==3)
  page.select_option('#order','2');page.locator('details:has(#bound-json) > summary').click();check('차수2 실제 원자료 반영','"derivative_order": 2' in page.locator('#bound-json').inner_text())
  for target in ['9.8-wave-B0','9.8-mean-C0','9.8-defects-C0','9.9-tangential-and-pressure','9.9-radial']:
   page.select_option('#target',target);check('노름ID 탐색 '+target,page.locator('#target-heading').inner_text().startswith(target))
  check('radial 원본beta 표시','3614790' in page.locator('#target-scope').inner_text())
  page.click('#try-cutoff');check('미실현수치·U0/Zj 혼동 거부 표시','수치 스케줄 생성 보류' in page.locator('#cutoff-result').inner_text())
  page.select_option('#update','five');check('five실제 계산 4행 표시',page.locator('#slow-table tbody tr').count()==4)
  check('five실제 지수199997/100000 표시','199997/100000' in page.locator('#slow-table').inner_text())
  check('증거 링크 선택과동기화',page.locator('#slow-link').get_attribute('href')=='evidence/five_slow_change.json')
  page.fill('#stage-j','99');check('범위오류 표시','입력 오류' in page.locator('#stage-result').inner_text())
  page.fill('#stage-j','2');page.fill('#stage-m','1');check('단계기호수식 실제 갱신','ℓₘ=3+(5)h' in page.locator('#stage-result').inner_text())
  check('23개 고정입력 링크',page.locator('#sources tbody tr').count()==23)
  page.select_option('#target','9.9-tangential-and-pressure');page.select_option('#order','1')
  page.set_content(html);page.wait_for_selector('html[data-render-ready="true"]')
  check('같은 fragment에서 DOM 재주입 상태 복원',page.locator('#target').input_value()=='9.9-tangential-and-pressure' and page.locator('#order').input_value()=='1')
  page.locator('#try-cutoff').focus();page.keyboard.press('Enter');check('키보드 조작','수치 스케줄 생성 보류' in page.locator('#cutoff-result').inner_text())
  page.select_option('#order','0');page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ROOT/'evidence/UI_DESKTOP.png'),full_page=True)
  check('데스크톱 수평넘침없음',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
  for width in [390,768]:
   page.set_viewport_size({'width':width,'height':844});page.evaluate('window.scrollTo(0,0)')
   check(f'{width}px 페이지 수평넘침없음',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
   page.select_option('#target','9.9-radial');check(f'{width}px 선택과원본연결','3614790' in page.locator('#target-scope').inner_text())
   if width==390:
    page.select_option('#target','9.9-tangential-and-pressure');page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(ROOT/'evidence/UI_MOBILE.png'),full_page=True)
  links=page.locator('a').evaluate_all('(aa)=>aa.map(a=>a.getAttribute("href"))')
  missing=[link for link in links if not (ROOT/link).is_file()]
  # 보고서는 최종 패키징 전에 생성한 다음 전체 링크를 다시 검사한다.
  check('JS 런타임오류없음',not errors)
  browser.close()
 result={'schema':'MathScope.LocalCandidateBrowserCheck/1','browser':'Chromium /usr/bin/chromium','url':local_url,'tested_operating_site':False,'navigation_tested':False,'render_mode':'Chromium DOM component test via set_content; URL access blocked by environment policy','checks':checks,'pass_count':sum(x['pass'] for x in checks),'total':len(checks),'page_errors':errors,'missing_local_links_at_test':missing,'html_sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),'remote_publications':0}
 (ROOT/'evidence/UI_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'passed':result['pass_count'],'total':result['total'],'page_errors':errors,'missing_links':missing},ensure_ascii=False))
if __name__=='__main__':run()

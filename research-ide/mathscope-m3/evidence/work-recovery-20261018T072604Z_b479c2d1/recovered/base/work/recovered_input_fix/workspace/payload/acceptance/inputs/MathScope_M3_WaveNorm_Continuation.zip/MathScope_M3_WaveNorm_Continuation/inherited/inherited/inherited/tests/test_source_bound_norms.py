from __future__ import annotations
import copy,json,tempfile,unittest
from pathlib import Path
from fractions import Fraction as Q
from source_bound_norms import (ROOT,SourceError,UnresolvedSourceNorm,PositiveDAG,NormAlgebra,
 load_inputs,verify_source_links,build_report,compose_slow_change,exponent,ibp_demand,stage_contract,digest)

class SourceBoundTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.d=load_inputs();cls.f=cls.d['normFamily'];cls.c=cls.f['certificates'][1];cls.p=cls.c['program'];cls.report=build_report(cls.d)
  cls.temporal=compose_slow_change(cls.p,cls.c['graph']['sha256'],'temporal',1)
  cls.five=compose_slow_change(cls.p,cls.c['graph']['sha256'],'five',1)
 def test_01_exact_saved_program_hashes(self):
  for c in self.f['certificates']:self.assertEqual(digest(c['program']),c['graph']['sha256'])
 def test_02_actual_selected_nodes(self):
  nodes=self.d['actualNodes']['nodes']
  for r in self.f['selectedNodeBindings']:self.assertEqual(nodes[str(r['id'])],r['node'])
  self.assertEqual(len(nodes),155)
 def test_03_latest_pressure_not_previous(self):
  self.assertEqual(self.report['links']['actual_pressure'],3615361)
  self.assertNotEqual(self.report['links']['actual_pressure'],self.f['source']['actualRoots']['temporalPressure']['value'])
 def test_04_all_five_target_ids_retained(self):
  self.assertEqual({t['id'] for t in self.report['targets']},{'9.8-wave-B0','9.8-mean-C0','9.8-defects-C0','9.9-tangential-and-pressure','9.9-radial'})
 def test_05_no_automatic_milestone_promotion(self):
  self.assertEqual(self.report['inherited']['M3'],'56/64');self.assertEqual(self.report['new_original_norm_ids_fully_closed'],[])
  self.assertIn('PARTIAL',self.report['inherited']['N6-02']);self.assertFalse(self.report['inherited']['old_proofs_rerun'])
 def test_06_initial1260_zero_retained(self):
  for k in ['Guard','Jet','PDE']:self.assertEqual(self.report['inherited'][k],0)
  self.assertEqual(self.report['inherited']['exact_difference_interval'],['0','0'])
 def test_07_exact_margins_not_float(self):
  self.assertEqual([t['exact_exponent_margin'] for t in self.report['targets']],['19999/100000','29/100','39999/50000','9999/100000','9999/100000'])
 def test_08_both_actual_updates_keep19_terms(self):
  for data in [self.temporal,self.five]:
   self.assertEqual(data['flux_terms_retained'],19)
   for row in data['rows']:self.assertEqual(sum(len(x) for x in row['flux_products'].values()),19)
 def test_09_slow_exponent_from_full_products(self):
  for data in [self.temporal,self.five]:
   for row in data['rows']:
    for b in row['fields'].values():self.assertEqual(Q(b['epsilonExponentExact']),Q(199997,100000))
 def test_10_pressure_and_four_groups_retained(self):
  for data in [self.temporal,self.five]:
   for row in data['rows']:
    self.assertIn('complete_pressure_difference',row['flux_products']['zAxial'])
    for group in row['groups'].values():self.assertEqual(set(group),{'slowTime','radial','axial','viscous'})
 def test_11_fast_time_not_silently_cancelled(self):
  for data in [self.temporal,self.five]:
   self.assertFalse(data['fast_time_cancellation_applied']);self.assertFalse(data['cutoff_declared_zero'])
 def test_12_new_constant_nodes_use_new_graph_not_parent(self):
  for data in [self.temporal,self.five]:
   self.assertNotEqual(data['new_graph_hash'],data['parent_program_hash'])
   for row in data['rows']:
    for b in row['fields'].values():
     self.assertEqual(b['constant']['graph'],data['new_graph_hash']);self.assertLess(b['constant']['node'],len(data['scalar_nodes']))
 def test_13_new_graph_is_closed(self):
  for data in [self.temporal,self.five]:PositiveDAG(data['scalar_nodes'],data['call_graph'],data['new_graph_hash'])
 def test_14_symbolic_node_is_not_numeric_C(self):
  c=self.f['certificates'][0];g=PositiveDAG(c['program']['scalarProgram']['nodes'],c['program']['callGraph']['calls'],c['graph']['sha256'])
  self.assertGreater(len(g.closure(2283)['source_leaves']),0)
  with self.assertRaises(UnresolvedSourceNorm):g.numeric_constant(2283)
 def test_15_numeric_evaluation_uses_only_reachable_nodes(self):
  g=PositiveDAG([],[],'fixture-not-actual');g.sqrt(g.q(2));x=g.add(g.q(2),g.q(3));self.assertEqual(g.numeric_constant(x),Q(5))
 def test_16_bad_future_node_rejected(self):
  with self.assertRaises(SourceError):PositiveDAG([{'op':'add','args':[1]}],[],'bad')
 def test_17_unbound_producer_rejected(self):
  with self.assertRaises(SourceError):PositiveDAG([{'op':'source_norm_result','args':[0,['constant']]}],[],'bad')
 def test_18_negative_constant_rejected(self):
  with self.assertRaises(SourceError):PositiveDAG([{'op':'rational','args':['-1','1']}],[],'bad')
 def test_19_wrong_weights_rejected(self):
  g=PositiveDAG([{'op':'rational','args':['1','1']}],[],'fixture');A=NormAlgebra(g)
  with self.assertRaises(SourceError):A.read({'constant':0,'power':0,'pole':0,'epsilonExponent':'1','weight':'sqrt_zeta'})
 def test_20_inconsistent_exponent_rejected(self):
  A=NormAlgebra(PositiveDAG([{'op':'rational','args':['1','1']}],[],'fixture'))
  with self.assertRaises(SourceError):A.read({'constant':0,'power':0,'pole':0,'epsilonExponent':'1-kappa_s','epsilonExponentExact':'1','weight':'zeta'})
 def test_21_exact_ibp49001_and_fast_source_demand(self):
  for m in range(3):
   b=ibp_demand(Q(149,100),m);self.assertEqual(b['ibp_order'],49001);self.assertEqual(b['A_e_source_derivative_order'],m+98005);self.assertEqual(b['fast_NA1_initial_Ez_derivative_order'],m+98010)
 def test_22_ibp_minimality(self):
  for target in [Q(6,5),Q(149,100),Q(2),Q(3)]:
   b=ibp_demand(target,0);p=b['ibp_order'];self.assertGreaterEqual(Q(b['achieved_exponent']),target)
   if p>1:self.assertLess(Q(99999+p-1,100000),target)
 def test_23_symbolic_h_never_replaced(self):
  s=stage_contract(2,1,self.report['links']['source_parameter_hash']);self.assertIsNone(s['h']['numerical_value']);self.assertEqual(s['ell'],{'constant':'3','h_coefficient':'5'});self.assertFalse(s['common_domain_changed'])
 def test_24_later_stage_constants_not_invented(self):
  for s in self.report['stage_contracts']:
   self.assertIsNone(s['K_m']);self.assertIsNone(s['C_jm']);self.assertIsNone(s['P_jm']);self.assertFalse(s['actual_later_stage_bounds_certified'])
 def test_25_missing_full_pressure_derivative_rejected(self):
  p=dict(self.p);p['updatedPressure']=self.p['updatedPressure'][:1]
  with self.assertRaises(SourceError):compose_slow_change(p,self.c['graph']['sha256'],'five',1)
 def test_26_source_byte_mutation_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'bad.json').write_text('{}');(p/'INPUT_LOCK.json').write_text(json.dumps({'sources':{'bad':{'path':'bad.json','sha256':'0'*64,'bytes':2}}}))
   with self.assertRaises(SourceError):load_inputs(p)
 def test_27_old_pressure_mutation_rejected(self):
  d=dict(self.d);d['normFamily']=copy.deepcopy(self.f);d['normFamily']['source']['actualRoots']['initializedPressure']['value']=3614634
  with self.assertRaises(SourceError):verify_source_links(d)
 def test_28_bad_original_source_node_rejected(self):
  d=dict(self.d);d['actualNodes']=copy.deepcopy(self.d['actualNodes']);d['actualNodes']['nodes']['622933']={'op':'rational','args':['0','1']}
  with self.assertRaises(SourceError):verify_source_links(d)
 def test_29_stage_boolean_rejected(self):
  with self.assertRaises(SourceError):stage_contract(True,0,'x')
 def test_30_affine_kappa_arithmetic(self):
  self.assertEqual(exponent('2-3*kappa_s'),Q(199997,100000));self.assertEqual(exponent('3/2-2*kappa_s'),Q(74999,50000))

if __name__=='__main__':unittest.main()

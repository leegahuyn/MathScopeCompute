/** Original finite harmonic kernel on a declared synthetic algebra fixture.
 * No actual original residual or correction-substep proof is run here.
 */
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {completeAngularHarmonicConvolution,exactAngularHarmonicPDE,exactHarmonicComplexAlgebra} from '../inputs/source-harmonic-assembly.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
class Graph {
 constructor(){this.nodes=[];this.cache=new Map();this.dc=new Map();this.fc=new Map();this.zero=this.q(0);this.one=this.q(1);}
 emit(op,args){const k=JSON.stringify([op,args]);if(!this.cache.has(k)){this.cache.set(k,this.nodes.length);this.nodes.push({op,args});}return this.cache.get(k);}
 q(n,d=1){n=BigInt(n);d=BigInt(d);if(d===0n)throw Error('division by zero');if(d<0n){d=-d;n=-n;}let a=n<0n?-n:n,b=d;while(b){[a,b]=[b,a%b];}return this.emit('rational',[String(n/a),String(d/a)]);}
 coord(s){return this.emit('coordinate',[s]);}
 add(...a){a=a.filter(x=>x!==this.zero);return a.length? a.length===1?a[0]:this.emit('add',a):this.zero;}
 mul(...a){if(a.includes(this.zero))return this.zero;a=a.filter(x=>x!==this.one);return a.length?a.length===1?a[0]:this.emit('multiply',a):this.one;}
 neg(a){return this.mul(this.q(-1),a);} sub(a,b){return a===b?this.zero:this.add(a,this.neg(b));}
 pow(a,n){if(n===0)return this.one;if(n===1)return a;return this.emit('power',[a,n]);}
 inv(a){return this.pow(a,-1);} div(a,b){return this.mul(a,this.inv(b));}
 derivative(id,x){const key=id+':'+x;if(this.dc.has(key))return this.dc.get(key);const {op,args:a}=this.nodes[id];let v;
 if(op==='coordinate')v=id===x?this.one:this.zero;
 else if(op==='rational')v=this.zero;
 else if(op==='add')v=this.add(...a.map(t=>this.derivative(t,x)));
 else if(op==='multiply')v=this.add(...a.map((t,j)=>this.mul(this.derivative(t,x),...a.filter((_,i)=>i!==j))));
 else if(op==='power')v=this.mul(this.q(a[1]),this.pow(a[0],a[1]-1),this.derivative(a[0],x));
 else throw Error(op);this.dc.set(key,v);return v;}
 freeCoordinates(id){if(this.fc.has(id))return this.fc.get(id);const {op,args}=this.nodes[id];const s=new Set(op==='coordinate'?[id]:[]);if(op==='add'||op==='multiply'||op==='power')for(const a of op==='power'?args.slice(0,1):args)for(const x of this.freeCoordinates(a))s.add(x);this.fc.set(id,s);return s;}
}
const G=new Graph(),C=exactHarmonicComplexAlgebra(G),[R,Z,T,theta,xi,v]=['R','Z','T','theta','xi','v'].map(x=>G.coord(x));
const eps=G.q(1,7),k=G.q(2),rho=G.pow(R,2),geometry={R,Z,T,theta,xi,v,epsilon:eps,radialFast:rho};
const dr=x=>G.add(G.derivative(x,R),G.mul(rho,G.derivative(x,xi))),dz=x=>G.mul(eps,G.derivative(x,Z));
const phi=G.add(theta,G.mul(G.q(7,3),Z),G.mul(G.q(2),R),G.neg(G.mul(v,G.add(R,G.mul(G.q(1,3),Z)))));
const n=[dr(phi),G.inv(R),dz(phi)];
const pot=[G.mul(R,Z),G.add(R,xi,v),G.add(T,Z)];
const curl=[G.neg(dz(pot[1])),G.sub(dz(pot[0]),dr(pot[2])),G.add(dr(pot[1]),G.div(pot[1],R))];
const cross=[G.sub(G.mul(n[1],pot[2]),G.mul(n[2],pot[1])),G.sub(G.mul(n[2],pot[0]),G.mul(n[0],pot[2])),G.sub(G.mul(n[0],pot[1]),G.mul(n[1],pot[0]))];
const a=curl.map((x,j)=>C.value(x,G.mul(k,cross[j]))),p=C.value(G.add(R,Z),G.mul(R,T));
const mean=[G.div(R,G.q(2)),G.add(G.neg(Z),T),G.mul(G.q(-7),Z)];
const rows=[{m:0,velocity:mean.map(x=>C.value(x)),pressure:C.value(G.mul(R,Z))},{m:1,velocity:a,pressure:p},{m:-1,velocity:a.map(C.conjugate),pressure:C.conjugate(p)}];
const result=exactAngularHarmonicPDE(G,{geometry,phase:phi,k,rows});
const cosine=[{m:-1,value:C.value(G.q(1,2))},{m:1,value:C.value(G.q(1,2))}];
const cos2=completeAngularHarmonicConvolution(G,{left:cosine,right:cosine});
let duplicateRejected=false,truncationRejected=false;
try{completeAngularHarmonicConvolution(G,{left:[cosine[0],cosine[0]],right:cosine});}catch{duplicateRejected=true;}
try{completeAngularHarmonicConvolution(G,{left:cosine,right:cosine,discardThreshold:1});}catch{truncationRejected=true;}
const out={schema:'MathScope.GenericWaveKernelFixture/1',scope:'synthetic exact algebra fixture; not original1260 or deferred correction substeps',nodes:G.nodes,geometry,phase:phi,k,rows,result,cos2,negative_controls:{duplicateRejected,truncationRejected},original_source_authenticated:false};
fs.writeFileSync(path.join(root,'evidence','GENERIC_KERNEL_FIXTURE.json'),JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({nodes:G.nodes.length,modes:result.generatedModes,duplicateRejected,truncationRejected}));

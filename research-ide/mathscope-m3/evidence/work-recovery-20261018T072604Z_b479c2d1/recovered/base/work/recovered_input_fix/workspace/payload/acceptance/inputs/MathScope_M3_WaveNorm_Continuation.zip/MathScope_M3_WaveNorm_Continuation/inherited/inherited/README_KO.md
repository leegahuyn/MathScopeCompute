# MathScope M3 Fast/Cutoff 추가 패키지

`reports/RESULTS_KO.md`와 `reports/HANDOFF_KO.md`가 결과와 재개점이다. `inherited/`는 직전 SourceBound 패키지의 보존본이다.

## 실행

Python 3.10 이상과 requirements.txt의 SymPy가 필요하다. 설치된 버전은 ENVIRONMENT.json에 기록했다.

```
python code/run_all.py
python code/replay.py
```

첫 명령은 새 연결기·37개 테스트·HTML만 실행한다. 두 번째는 결과 9개와 HTML을 새 디렉터리에서 다시 생성하고 바이트를 비교한다. 원본 1260개 검증은 실행하지 않는다.

`index.html`은 standalone 추가 화면이다. 압축을 풀어 전체 폴더 구조를 보존하면 상대 증거 링크가 함께 열린다. 운영 페이지에는 게시하지 않았다.

선택 화면 검증에는 requirements-ui.txt의 Playwright와 Chromium이 필요하다.

```
python code/browser_check.py
```

이 환경은 file URL 탐색을 관리자 정책으로 차단했다. 정책은 변경하지 않고 같은 로컬 HTML의 DOM 컴포넌트만 실제 Chromium에서 검사했다. `--dom-only`는 이 DOM 검사만 반복한다. 운영 페이지 탐색/게시 검사는 아니다.

정량 결과는 같은 원본의 기존 노름 입력 상계를 전제로 한다. 해시·테스트·지수 비교를 전칭 수학 증명과 혼동하지 않는다. 초기1260완료 / M3 56/64 / N6-02보류를 보존한다.

"""기존 PDE 증명을 재실행하지 않는 최소 재현 진입점."""
from __future__ import annotations
import os,sys,subprocess,json,hashlib,platform,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 start=datetime.now(timezone.utc).isoformat();t=time.monotonic();env=os.environ.copy();env['PYTHONPATH']=str(ROOT/'code')
 steps=[]
 for name,command in [('source_bound_composition',[sys.executable,'code/source_bound_norms.py']),('common_tail_source_adapter',[sys.executable,'code/source_tail_adapter.py']),('tests',[sys.executable,'-m','unittest','discover','-s','tests','-v'])]:
  r=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=45)
  p=ROOT/'evidence'/(name+'.log');p.write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr)
  steps.append({'name':name,'command':command,'exit_code':r.returncode,'log':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  if r.returncode:break
 receipt={'schema':'MathScope.SourceBoundContinuationExecution/1','started_utc':start,'ended_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-t,4),'python':sys.version,'platform':platform.platform(),'steps':steps,'success':all(x['exit_code']==0 for x in steps),'old_1260_proofs_rerun':False,'original_correction_substep_verification_run':False,'remote_writes':0,'baseline_common_tail_sha256':hashlib.sha256((ROOT/'baseline/common_tail.py').read_bytes()).hexdigest(),'code_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'code').glob('*.py'))},'mathematical_scope':'기존 원본 노름식과 새 정확 대수 소비기·부정 대조. 실제 수치 상수와 전칭 W/M/S 정리 완료 아님.'}
 (ROOT/'evidence/EXECUTION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 return 0 if receipt['success'] else 1
if __name__=='__main__':sys.exit(main())

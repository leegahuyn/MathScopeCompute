"""결과를 지운 새 폴더에서 새 연결만 재생성하고 바이트 일치를 확인한다."""
from __future__ import annotations
from pathlib import Path
import tempfile,shutil,subprocess,sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from run_all import PRODUCTS

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
 before={x:sha(ROOT/x) for x in PRODUCTS}
 with tempfile.TemporaryDirectory(prefix='mathscope-defect-replay-') as tmp:
  dst=Path(tmp)/'package'
  shutil.copytree(ROOT,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  for x in PRODUCTS:(dst/x).unlink()
  (dst/'evidence/EXECUTION_RECEIPT.json').unlink(missing_ok=True)
  p=subprocess.run([sys.executable,'code/run_all.py'],cwd=dst,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  (ROOT/'evidence/REPLAY.log').write_text(p.stdout,encoding='utf-8')
  comparisons=[]
  for x in PRODUCTS:
   actual=sha(dst/x) if (dst/x).is_file() else None
   comparisons.append({'path':x,'before_sha256':before[x],'recreated_sha256':actual,'byte_identical':actual==before[x]})
  replay_receipt=json.loads((dst/'evidence/EXECUTION_RECEIPT.json').read_text()) if (dst/'evidence/EXECUTION_RECEIPT.json').is_file() else None
  out={'schema':'MathScope.DefectNormFreshDirectoryReplay/1','command':[sys.executable,'code/run_all.py'],'exit_code':p.returncode,'files':comparisons,'matched':sum(x['byte_identical'] for x in comparisons),'compared':len(comparisons),'fresh_processes':True,'generated_products_deleted_before_run':True,'successful':p.returncode==0 and all(x['byte_identical'] for x in comparisons),'replay_execution':replay_receipt,'scope':'새 폴더/새 프로세스의 동일 코드 재현. 별도 수학 알고리즘의 독립 증명이라고 부르지 않음. 초기1260 및 보류된 substep 재실행 없음.'}
  (ROOT/'evidence/REPLAY_VERIFICATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:out[k] for k in ['exit_code','matched','compared','successful']},ensure_ascii=False))
 return 0 if out['successful'] else 1
if __name__=='__main__':sys.exit(main())

"""Independent SymPy checks: symbolic identities plus original JS kernel fixture.
The kernel fixture is synthetic; it does not rerun the original1260 proofs.
"""
from pathlib import Path
import json, sympy as s
from wave_bridge import ROOT,dump,require,sha

def differential_checks():
 R,Z,T,xi,v,th,k,m,p,pz,x0,eps=s.symbols('R Z T xi v theta k m p pz x0 epsilon',nonzero=True)
 coords=(R,Z,T,xi,v);omega=k*m
 b,F,G=[s.Function(x)(R,Z,T) for x in ['b','F','G']]
 rho=s.Function('rho')(R);a=s.Matrix([s.Function(x)(*coords) for x in ['ar','at','az']]);pi=s.Function('pi')(*coords)
 dr=lambda x:s.diff(x,R)+rho*s.diff(x,xi)
 dz=lambda x:eps*s.diff(x,Z)
 dt=lambda x:-eps*s.diff(x,T)+s.diff(x,v)
 phi=p*th+pz*Z/eps+x0*R-v*(p*F+pz*G)
 n=s.Matrix([dr(phi),s.diff(phi,th)/R,dz(phi)]);V=R*F;U=s.Matrix([b,V,G])
 hd=lambda x,d,nc:d(x)+s.I*omega*nc*x
 Hr=lambda x:hd(x,dr,n[0]);Hz=lambda x:hd(x,dz,n[2]);Ht=lambda x:hd(x,dt,dt(phi))
 Htheta=lambda x:s.I*omega*p*x
 lap=lambda x:Hr(Hr(x))+Hr(x)/R+Hz(Hz(x))+Htheta(Htheta(x))/R**2
 vlap=s.Matrix([lap(a[0])-a[0]/R**2-2*Htheta(a[1])/R**2,lap(a[1])-a[1]/R**2+2*Htheta(a[0])/R**2,lap(a[2])])
 full=s.Matrix([Ht(x)+b*Hr(x)+V*(s.I*omega*n[1]*x)+G*Hz(x) for x in a])
 full+=a[0]*U.diff(R)+a[2]*eps*U.diff(Z)+s.Matrix([-2*V*a[1]/R,(V*a[0]+b*a[1])/R,0])-eps*vlap+s.Matrix([Hr(pi),s.I*omega*n[1]*pi,Hz(pi)])
 K=s.Matrix([[0,-2*F,0],[2*F+R*s.diff(F,R),0,0],[s.diff(G,R),0,0]])
 principal=a.diff(v)+K*a+eps*omega**2*(n.dot(n))*a+s.I*omega*n*pi
 eik=dt(phi)+b*n[0]+V*n[1]+G*n[2]
 remainder=s.Matrix([-eps*s.diff(x,T)+b*dr(x)+G*dz(x)+s.I*omega*eik*x for x in a])
 remainder+=s.Matrix([a[0]*s.diff(b,R),b*a[1]/R,0])+a[2]*eps*U.diff(Z)+s.Matrix([dr(pi),0,dz(pi)])
 visc=s.Matrix([dr(dr(x))+dr(x)/R+dz(dz(x)) for x in a])-s.Matrix([a[0],a[1],0])/R**2
 visc+=2*s.I*omega*s.Matrix([n[0]*dr(x)+n[2]*dz(x) for x in a])
 visc+=s.I*omega*(dr(n[0])+n[0]/R+dz(n[2]))*a
 visc+=2*s.I*omega*n[1]/R*s.Matrix([-a[1],a[0],0])
 remainder-=eps*visc
 rows=[]
 def check(name,x):
  val=s.expand(x);ok=val==0
  require(ok,'독립 기호식 불일치: '+name);rows.append({'id':name,'exact_zero':ok,'scope':'formal differential identity under stated fixed-chart conditions'})
 check('phase_transport_7_9',eik-(eps*v*(s.diff(p*F+pz*G,T)-G*s.diff(p*F+pz*G,Z))+b*n[0]))
 for j in range(3):check('linear_remainder_9_2_component_'+str(j),full[j]-principal[j]-remainder[j])
 # 압력 부호 및 움직이는 normal. n·t=0을 지정한 이상적 좌표에서 검증.
 nx,ny,nz,tx,ty,ux,uy,uz=s.symbols('nx ny nz tx ty ux uy uz',nonzero=True)
 nn=s.Matrix([nx,ny,nz]);tt=s.Matrix([tx,ty,-(nx*tx+ny*ty)/nz]);np=s.Matrix([ux,uy,uz]);KK=s.Matrix(3,3,s.symbols('K0:9'));norm=nn.dot(nn)
 pp=s.I*((nn.T*KK-np.T)*tt)[0]/(omega*norm)
 td=-KK*tt+nn*((nn.T*KK-np.T)*tt)[0]/norm
 for j in range(3):check('principal_pressure_normal_'+str(j),s.cancel(td[j]+(KK*tt)[j]+s.I*omega*nn[j]*pp))
 check('moving_normal_tangency',s.cancel(nn.dot(td)+np.dot(tt)))
 # 실제 full amplitude의 종방향은 0이 아니다. 정확한 divergence 치환.
 z,md,sdiv,aa=s.symbols('z mprime divamp aprime',nonzero=True)
 check('full_longitudinal_ratio',s.I*k*md*(-sdiv/(s.I*k*m))*aa+(md/m)*sdiv*aa)
 # cutoff product rule; derivative of full potential also retained.
 psi=s.Function('psi')(v);amp=s.Function('t')(v)
 check('cutoff_principal_positive_psi_prime',s.diff(psi*amp,v)-psi*s.diff(amp,v)-s.diff(psi,v)*amp)
 X,Y,Q=s.symbols('x y z');cut=s.Function('chi')(X,Y,Q);pot=s.Matrix([s.Function('C'+str(j))(X,Y,Q) for j in range(3)])
 curl=lambda A:s.Matrix([s.diff(A[2],Y)-s.diff(A[1],Q),s.diff(A[0],Q)-s.diff(A[2],X),s.diff(A[1],X)-s.diff(A[0],Y)])
 grad=s.Matrix([s.diff(cut,q) for q in (X,Y,Q)])
 for j in range(3):check('cutoff_curl_product_'+str(j),(curl(cut*pot)-cut*curl(pot)-grad.cross(pot))[j])
 cc=curl(pot);check('div_curl_full',sum(s.diff(cc[j],q) for j,q in enumerate((X,Y,Q))))
 # 어느 연결항이라도 빠지면 일반식이 달라진다.
 mutations={'remove_viscous_angular_connection':s.expand(2*s.I*omega*eps*n[1]*a[1]/R)!=0,
 'drop_radial_second_derivative_coefficient':s.expand(s.diff(rho,R)*s.diff(a[0],xi))!=0,
 'declare_full_normal_zero':sdiv!=0,
 'wrong_cutoff_time_sign':s.expand(2*s.diff(psi,v)*amp)!=0}
 require(all(mutations.values()),'기호 오류 주입 검출 실패')
 return {'checks':rows,'mutations_detected':mutations,'input':{'source_equations':['7.9','7.38','7.39','7.40','9.1','9.2'],'rho':'rho(R), retained Dr rho','amplitude':'ar,at,az(R,Z,T,xi,v)','label_frozen':True,'new_original_source_proof':False}}

def kernel_checks():
 f=json.loads((ROOT/'evidence/GENERIC_KERNEL_FIXTURE.json').read_text());vals=[]
 for n in f['nodes']:
  op,a=n['op'],n['args']
  if op=='rational':v=s.Rational(int(a[0]),int(a[1]))
  elif op=='coordinate':v=s.Symbol(a[0],real=True,nonzero=True)
  elif op=='add':v=s.Add(*(vals[x] for x in a))
  elif op=='multiply':v=s.Mul(*(vals[x] for x in a))
  elif op=='power':v=vals[a[0]]**a[1]
  else:raise ValueError(op)
  vals.append(v)
 cv=lambda c:vals[c['real']]+s.I*vals[c['imaginary']]
 R,Z,T,th,xi,v=[vals[f['geometry'][k]] for k in ['R','Z','T','theta','xi','v']]
 q=s.Symbol('phase_exponential',nonzero=True);eps=vals[f['geometry']['epsilon']];k=vals[f['k']];phi=vals[f['phase']];rho=vals[f['geometry']['radialFast']]
 # Laurent series first, then independent SymPy chain-rule differentiation.
 U=s.Matrix([sum(cv(r['velocity'][j])*q**r['m'] for r in f['rows']) for j in range(3)]);P=sum(cv(r['pressure'])*q**r['m'] for r in f['rows'])
 deriv=lambda z,x:s.diff(z,x)+s.I*k*s.diff(phi,x)*q*s.diff(z,q)
 dr=lambda z:deriv(z,R)+rho*deriv(z,xi)
 dz=lambda z:eps*deriv(z,Z)
 dt=lambda z:-eps*deriv(z,T)+deriv(z,v)
 angular=lambda z:deriv(z,th)/R
 lap=lambda z:dr(dr(z))+dr(z)/R+dz(dz(z))+deriv(deriv(z,th),th)/R**2
 vlap=s.Matrix([lap(U[0])-U[0]/R**2-2*deriv(U[1],th)/R**2,lap(U[1])-U[1]/R**2+2*deriv(U[0],th)/R**2,lap(U[2])])
 adv=s.Matrix([U[0]*dr(x)+U[1]*angular(x)+U[2]*dz(x) for x in U])+s.Matrix([-U[1]**2/R,U[0]*U[1]/R,0])
 grad=s.Matrix([dr(P),angular(P),dz(P)]);div=dr(U[0])+U[0]/R+angular(U[1])+dz(U[2])
 residual=s.Matrix([dt(x) for x in U])+adv-eps*vlap+grad+U*div
 checks=[]
 for key,expected in [('conservativeResidual',residual),('vectorLaplacian',vlap),('pressureGradient',grad)]:
  bymode={r['m']:r['value'] for r in f['result'][key]}
  for j in range(3):
   exp=s.expand(expected[j])
   for m in bymode:
    delta=s.expand(exp.coeff(q,m)-cv(bymode[m][j]));ok=delta==0
    require(ok,f'JS/SymPy mismatch {key}:{m}:{j}')
    checks.append({'id':f'{key}:{m}:{j}','exact_zero':True})
 require(s.expand(div)==0,'curl-generated fixture not divergence-free')
 checks.append({'id':'divergence_independent','exact_zero':True})
 for r in f['cos2']['rows']:
  expected=s.Rational(1,2) if r['m']==0 else s.Rational(1,4)
  require(s.expand(cv(r['value'])-expected)==0,'cos²의 절반 인자 누락')
  checks.append({'id':f"cosine_square:{r['m']}",'exact_zero':True})
 require(f['negative_controls']['duplicateRejected'] and f['negative_controls']['truncationRejected'],'원래 커널 입력 오류 미검출')
 return {'original_JS_kernel_sha256':sha(ROOT/'inputs/source-harmonic-assembly.mjs'),'fixture_sha256':sha(ROOT/'evidence/GENERIC_KERNEL_FIXTURE.json'),
 'checks':checks,'scope':'synthetic fixed geometry, all generated finite harmonics; not actual PDE proof or N6-02 substeps','shared_implementation':False,'shared_source_formula':True}

def main():
 out={'schema':'MathScope.WaveIndependentAlgebra/1','differential_identities':differential_checks(),'kernel_comparison':kernel_checks(),'original1260_reexecuted':False}
 dump(ROOT/'evidence/INDEPENDENT_ALGEBRA.json',out)
 print(json.dumps({'formal_identities':len(out['differential_identities']['checks']),'JS_SymPy_exact_comparisons':len(out['kernel_comparison']['checks']),'symbolic_mutations_detected':len(out['differential_identities']['mutations_detected'])}))
if __name__=='__main__':main()

"""원본 노름 표현과 common_tail 사이의 적용 범위·수치 입력 연결.

초기 상태 U0의 M/S 노름을 단계 증가분 Z_j의 Lemma5.4 입력으로 바꾸지 않는다.
수치 스케줄은 실제 Z_j 상계와 h의 인증값이 준비된 경우에만 계산한다.
"""
from __future__ import annotations
from fractions import Fraction as Q
from pathlib import Path
from source_bound_norms import ROOT,PositiveDAG,SourceError,UnresolvedSourceNorm,load_inputs,dump
from common_tail import Envelope,choose_cutoff

def schedule_from_realized_increments(*,role:str,j:int,envelopes:list[Envelope],previous_k:int|None,q0:Q)->dict:
 if role!='cutoff_product_increment_envelope':raise SourceError('Lemma5.4 (5.37)는 Z_j에 cutoff·curl 교환항을 반영한 hat-C 상계가 필요함. 초기 U0 또는 raw Z_j 노름으로 대체 불가.')
 return choose_cutoff(j,envelopes,previous_k,q0)

def inspect_connection(data:dict)->dict:
 f=data['normFamily'];records=[]
 for c in f['certificates']:
  p=c['program'];G=PositiveDAG(p['scalarProgram']['nodes'],p['callGraph']['calls'],c['graph']['sha256'])
  for r in p['rows']:
   for name,b in [('v',r['velocity']['v']),('gamma',r['velocity']['gamma']),('beta',r['velocity']['beta']),('pm',r['fullPressure'])]:
    closed=G.closure(b['constant'])
    try:value=str(G.numeric_constant(b['constant']));error=None
    except UnresolvedSourceNorm as e:value=None;error=str(e)
    records.append({'name':name,'derivative_order':r['order'],'program_request_order':p['request']['order'],'graph':c['graph']['sha256'],'constant_node':b['constant'],'source_role':'finite_initial_state_U0','numeric_value':value,'unmaterialized_source_leaf_count':len(closed['source_leaves']),'source_producers':sorted({x['producer'] for x in closed['source_leaves']}),'numeric_evaluator_observation':error})
 role_rejected=False
 try:schedule_from_realized_increments(role='finite_initial_state_U0',j=1,envelopes=[],previous_k=None,q0=Q(1,2))
 except SourceError:role_rejected=True
 return {'schema':'MathScope.CommonTailActualSourceAdapter/1','consumer':'code/common_tail.py','records':records,'initial_state_as_increment_rejected':role_rejected,'actual_numeric_cutoff_schedule_generated':False,'numerical_blockers':['단계 증가분 Z_j의 C_jm/P_jm과 실제 원본 h의 수치 포함구간이 연결되어 있지 않음.','source_norm_result의 실제 생성기 결과를 임의 상수나 AST 노드 번호로 대체하지 않음.'],'reference_theorem_application_does_not_require_decimal_materialization':True,'N6-02_deferred_substeps_added_as_new_prerequisite':False,'source_mapping':{'initial_five_norms':'Definition9.4, Proposition9.5: finite initialization U0','later_increment_norms':'Lemma9.8: Z_j=(A_j,B_j,p_j), j>=1; 이후 Lemma5.4 Step1의 cutoff/curl 곱 상계 hat-C를 생성','cutoff_application':'Lemma5.4, Proposition9.9 Step1–2, (9.21)'},'scope':'실제 저장 노름의 수치화 시도 및 범위 거부 검사를 수행. 전칭 노름 정리 또는 수치 tail 완료 아님.'}

def main():
 out=inspect_connection(load_inputs());dump(ROOT/'evidence/COMMON_TAIL_SOURCE_CONNECTION.json',out)
 print('실제 소스 상수 연결 검사:',len(out['records']),'건; 실제 수치 스케줄 생성:',out['actual_numeric_cutoff_schedule_generated'])
if __name__=='__main__':main()

"""실제 초기 소스에 결속되는 노름 소비기와 정확한 양의 상계 대수.

이 모듈은 저장된 source_norm_result를 수치로 가장하지 않는다.
상계식 생성·노드 연결, 수치 상계 실현, 모든 차수 정리는 서로 다른 상태다.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as Q
from math import comb, factorial
from pathlib import Path
from typing import Any
import copy, hashlib, json, re
ROOT=Path(__file__).resolve().parents[1]
KAPPA=Q(1,100000)
class SourceError(ValueError): pass
class UnresolvedSourceNorm(SourceError): pass

def canonical(x: Any)->bytes:
 return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(x: Any)->str: return hashlib.sha256(canonical(x)).hexdigest()
def dump(path: Path,x: Any)->None:
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def natural(x: Any)->bool: return type(x) is int and x>=0

def exponent(s: str)->Q:
 if not isinstance(s,str) or len(s)>100: raise SourceError('정확한 유리수 지수 필요')
 if 'kappa_s' not in s:
  try:return Q(s)
  except (ValueError,ZeroDivisionError):raise SourceError('잘못된 지수')
 m=re.fullmatch(r'([+-]?\d+(?:/\d+)?)?([+-])?(?:(\d+(?:/\d+)?)\*)?kappa_s',s)
 if m is None or (m[1] and not m[2]):raise SourceError('원본 kappa_s의 유리수-아핀 식 필요')
 return Q(m[1] or '0') + (Q(-1) if m[2]=='-' else Q(1))*Q(m[3] or '1')*KAPPA

class PositiveDAG:
 """수치 상수와 노드 참조를 구분하는, 원본 그래프별 양의 상계 DAG."""
 def __init__(self,nodes: list[dict],calls: list[dict],namespace: str):
  self.nodes=copy.deepcopy(nodes);self.calls=copy.deepcopy(calls);self.namespace=namespace
  self._intern={canonical(n):i for i,n in enumerate(self.nodes)}
  self.validate()
 def validate(self)->None:
  for i,c in enumerate(self.calls):
   if c.get('id')!=i or any(not natural(k) or k>=i for k in c.get('dependencies',[])):raise SourceError('생성기 순서/의존성 오류')
   if c.get('callerCallableSupplied') is True:raise SourceError('임의 호출자 노름은 원본 증거가 아님')
  for i,n in enumerate(self.nodes):
   op,args=n.get('op'),n.get('args')
   if not isinstance(args,list):raise SourceError('노드 인자 오류')
   if op=='rational':
    if len(args)!=2 or Q(int(args[0]),int(args[1]))<0:raise SourceError('양의 상계에 음수 상수')
   elif op=='source_norm_result':
    if len(args)!=2 or not natural(args[0]) or args[0]>=len(self.calls) or not isinstance(args[1],list) or not args[1]:raise SourceError('결속되지 않은 노름 생성기')
   elif op in ['add','multiply','sqrt_positive','integer_power']:
    refs=args[:1] if op in ['sqrt_positive','integer_power'] else args
    if not refs or any(not natural(r) or r>=i for r in refs):raise SourceError('미래/없는 상계 노드 참조')
    if op=='integer_power' and (len(args)!=2 or not natural(args[1])):raise SourceError('음수가 아닌 정수 거듭제곱 필요')
    if op=='sqrt_positive' and len(args)!=1:raise SourceError('제곱근 인자 수 오류')
   else:raise SourceError('지원하지 않는 노름 연산: '+str(op))
 def emit(self,op: str,args: list)->int:
  n={'op':op,'args':args};key=canonical(n)
  if key not in self._intern:self._intern[key]=len(self.nodes);self.nodes.append(n)
  return self._intern[key]
 def q(self,x: Q|int)->int:
  x=Q(x)
  if x<0:raise SourceError('음수 상계 불허')
  return self.emit('rational',[str(x.numerator),str(x.denominator)])
 def add(self,*xs: int)->int:return self.emit('add',list(xs))
 def mul(self,*xs: int)->int:return self.emit('multiply',list(xs))
 def pow(self,x: int,n: int)->int:return self.emit('integer_power',[x,n])
 def sqrt(self,x: int)->int:return self.emit('sqrt_positive',[x])
 def source(self,call: int,path: list)->int:return self.emit('source_norm_result',[call,path])
 def closure(self,root: int)->dict:
  if not natural(root) or root>=len(self.nodes):raise SourceError('없는 노름 상수 노드')
  seen=set();todo=[root];leaves=[]
  while todo:
   i=todo.pop()
   if i in seen:continue
   seen.add(i);n=self.nodes[i];a=n['args'];op=n['op']
   if op=='source_norm_result':leaves.append({'node':i,'call':a[0],'producer':self.calls[a[0]]['producer'],'selector':a[1]})
   elif op in ['add','multiply']:todo.extend(a)
   elif op in ['integer_power','sqrt_positive']:todo.append(a[0])
  return {'namespace':self.namespace,'root':root,'node_count':len(seen),'source_leaves':sorted(leaves,key=lambda x:x['node']),'numerical_value_materialized':False}
 def numeric_constant(self,root:int)->Q:
  """미실현 source_norm_result가 있으면 수치 cutoff 입력으로 사용하지 않는다."""
  c=self.closure(root)
  if c['source_leaves']:raise UnresolvedSourceNorm(f"실제 원본 생성기 결과 {len(c['source_leaves'])}개가 수치 포함구간으로 실현되지 않음")
  vals={};needed=set();todo=[root]
  while todo:
   i=todo.pop()
   if i in needed:continue
   needed.add(i);n=self.nodes[i];op=n['op'];a=n['args']
   if op in ['add','multiply']:todo.extend(a)
   elif op in ['integer_power','sqrt_positive']:todo.append(a[0])
  from math import isqrt
  for i in sorted(needed):
   n=self.nodes[i];a=n['args'];op=n['op']
   if op=='rational':vals[i]=Q(int(a[0]),int(a[1]))
   elif op=='source_norm_result':continue
   elif op in ['add','multiply']:
    if any(k not in vals for k in a):continue
    v=Q(0) if op=='add' else Q(1)
    for k in a:v=v+vals[k] if op=='add' else v*vals[k]
    vals[i]=v
   elif op=='integer_power' and a[0] in vals:vals[i]=vals[a[0]]**a[1]
   elif op=='sqrt_positive' and a[0] in vals:
    v=vals[a[0]];sn,sd=isqrt(v.numerator),isqrt(v.denominator)
    if sn*sn!=v.numerator or sd*sd!=v.denominator:raise UnresolvedSourceNorm('비유리 제곱근의 인증 포함구간 필요')
    vals[i]=Q(sn,sd)
  return vals[root]

@dataclass(frozen=True)
class Bound:
 constant:int
 power:int
 pole:int
 eps:Q
 weight:str
 def json(self,namespace: str)->dict:
  return {'constant':{'kind':'source_bound_expression','graph':namespace,'node':self.constant},'power':self.power,'pole':self.pole,'epsilonExponentExact':str(self.eps),'weight':self.weight,'gaussian':'1','numerical_constant':None}

class NormAlgebra:
 def __init__(self,dag:PositiveDAG):self.g=dag
 def read(self,x:dict)->Bound:
  if not natural(x.get('constant')) or x['constant']>=len(self.g.nodes):raise SourceError('원본 노름 참조 오류')
  if not natural(x.get('power')) or not natural(x.get('pole')) or x.get('weight') not in ['1','zeta'] or x.get('gaussian','1')!='1':raise SourceError('원본 노름 가중치/로그/극 차수 오류')
  e=exponent(x['epsilonExponent'])
  if 'epsilonExponentExact' in x and Q(x['epsilonExponentExact'])!=e:raise SourceError('기호 지수와 유리수 지수 불일치')
  return Bound(x['constant'],x['power'],x['pole'],e,x['weight'])
 def unit(self,c:int,eps:Q=Q(0),weight='1')->Bound:return Bound(c,0,0,eps,weight)
 def add(self,*b:Bound)->Bound:
  if not b:raise SourceError('생략된 항')
  return Bound(self.g.add(*(x.constant for x in b)),max(x.power for x in b),max(x.pole for x in b),min(x.eps for x in b),'zeta' if all(x.weight=='zeta' for x in b) else '1')
 def mul(self,a:Bound,b:Bound)->Bound:return Bound(self.g.mul(a.constant,b.constant),a.power+b.power,a.pole+b.pole,a.eps+b.eps,'zeta' if 'zeta' in [a.weight,b.weight] else '1')
 def scale(self,a:Bound,c:int,eps:Q=Q(0))->Bound:return Bound(self.g.mul(a.constant,c),a.power,a.pole,a.eps+eps,a.weight)
 def seqadd(self,*ss:list[Bound])->list[Bound]:return [self.add(*(s[j] for s in ss)) for j in range(min(map(len,ss)))]
 def seqmul(self,a:list[Bound],b:list[Bound])->list[Bound]:return [self.add(*(self.scale(self.mul(a[j],b[m-j]),self.g.q(comb(m,j))) for j in range(m+1))) for m in range(min(len(a),len(b)))]
 def seqscale(self,s:list[Bound],c:int,eps:Q=Q(0))->list[Bound]:return [self.scale(v,c,eps) for v in s]

def load_inputs(root:Path=ROOT)->dict:
 lock=json.loads((root/'INPUT_LOCK.json').read_text());data={}
 for key,item in lock['sources'].items():
  p=root/item['path'];raw=p.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=item['sha256'] or len(raw)!=item['bytes']:raise SourceError('입력 바이트 변조: '+key)
  data[key]=json.loads(raw) if p.suffix=='.json' else raw.decode()
 return data

def verify_source_links(d:dict)->dict:
 family=d['normFamily'];source=family['source'];actual=source['actualRoots'];nodes=d['actualNodes']['nodes']
 expected={'beta':3614790,'v':3614791,'gamma':3614792}
 if actual['initializedVelocity']!=expected or actual['initializedPressure']['value']!=3615361:raise SourceError('현재 초기 소스/최신 압력이 아님')
 if actual['initializedDefects']!={'P':3615055,'Jtheta':3615101,'Jz':3615147}:raise SourceError('신규 결함과 과거 결함 혼동')
 for c in family['certificates']:
  if digest(c['program'])!=c['graph']['sha256']:raise SourceError('저장 노름 프로그램 해시 불일치')
  if c['program']['savedSourceBinding']['source']!=source['source'] or c['program']['savedSourceBinding']['actualRoots']!=actual:raise SourceError('서로 다른 원본 노름 연결')
  PositiveDAG(c['program']['scalarProgram']['nodes'],c['program']['callGraph']['calls'],c['graph']['sha256'])
 for b in family['selectedNodeBindings']:
  if nodes.get(str(b['id']))!=b['node']:raise SourceError('원본 소스 노드와 저장 증거 불일치')
 hc=d['haar']['fixture']['actual']['certificate'];h=hc['program']
 if digest(h)!=hc['graph']['sha256']:raise SourceError('Haar 노름 프로그램 해시 불일치')
 if h['source']!=source['source'] or d['cutoff']['source']['source']!=source['source']:raise SourceError('Haar/cutoff가 다른 원본 파라미터를 사용함')
 for cc in d['cutoff']['certificates']:
  if digest(cc['program'])!=cc['graph']['sha256']:raise SourceError('cutoff 노름 프로그램 해시 불일치')
 if h['sourceBinding']['actualCovarianceRoots']!=actual['covariance'] or h['sourceBinding']['actualOriginalStress']!=actual['originalStress']:raise SourceError('Haar 공분산 또는 고정 응력의 원본 변경')
 pressure=actual['initializedPressure']
 if pressure.get('cutoffRemainderDeclaredZero') is not False or pressure.get('allAuxiliaryModesRetained') is not True:raise SourceError('실제 압력 cutoff/전체 torus 누락')
 target=d['typedSpec']['sameOriginalDomain']
 return {'actual_velocity':expected,'actual_pressure':3615361,'actual_mean_residuals':[3614976,3615392],'actual_defects':actual['initializedDefects'],'source_parameter_hash':source['source']['parameterExpressionSHA256'],'source_node_prefix_hash':source['source']['sourceNodePrefixSHA256'],'domain':target,'same_fixed_covariance':actual['covariance'],'same_fixed_stress':actual['originalStress'],'stored_source_nodes_matched':d['actualNodes']['matched_node_count'],'private_runtime_rehydrated':False,'old_1260_proofs_rerun':False}

def compose_slow_change(program:dict,namespace:str,stage:str,m:int=1)->dict:
 """실제 입력의 temporal/five 전체 느린 평균 변화 상계. 빠른 시간항은 따로 둔다."""
 if stage not in ['temporal','five'] or not natural(m):raise SourceError('초기 구성의 temporal/five 및 유한 차수 필요')
 g=PositiveDAG(program['scalarProgram']['nodes'],program['callGraph']['calls'],namespace);A=NormAlgebra(g)
 radial=next(c['id'] for c in g.calls if c['producer']=='radial');B=g.source(radial,['geometry','B']);one=g.q(1);two=g.q(2);sqrt2=g.sqrt(two)
 def readseq(rows,key,n,fields=False):
  if len(rows)<n:raise SourceError('필요한 실제 노름 차수 누락: '+key)
  return [A.read((r['fields'] if fields else r)[key]) for r in rows[:n]]
 bgraw=program['inputRows']['backgroundRows'];bg={k:readseq(bgraw,k,m+2) for k in ['b','G']}
 bg['V']=[A.scale(A.read(r['F']),g.mul(g.q(2**j),B)) for j,r in enumerate(bgraw[:m+2])]
 incraw=program['temporalProducts']['rows'] if stage=='temporal' else program['fiveProducts']['rows']
 inc={k:readseq(incraw,k,m+3,True) for k in ['beta','v','gamma']}
 if stage=='five':old={k:readseq(program['temporalProducts']['rows'],k,m+2,True) for k in inc}
 else:old={k:[A.unit(g.q(0),Q(2)-KAPPA if k=='beta' else Q(1)-KAPPA,'zeta') for _ in range(m+2)] for k in inc}
 prior=program['initialPressure'] if stage=='temporal' else program['postPressure'];updated=program['postPressure'] if stage=='temporal' else program['updatedPressure']
 if min(len(prior),len(updated))<m+2:raise SourceError('최신 전체 압력의 미분 상계 누락')
 p=[A.add(A.read(prior[j]['pressure']),A.read(updated[j]['pressure'])) for j in range(m+2)]
 def inv(n):return [A.unit(g.mul(g.q(factorial(j)),g.pow(B,j+1))) for j in range(n)]
 def fast(n):return [A.unit(g.mul(g.q(factorial(j+4)),g.pow(B,j+4)),-KAPPA) for j in range(n)]
 def Dr(s):return A.seqadd(s[1:],A.seqscale(A.seqmul(fast(len(s)-1),s[1:]),sqrt2))
 def De(s,e):return A.seqadd(Dr(s),A.seqscale(A.seqmul(inv(len(s)-1),s),g.q(e)))
 def Dz(s):return A.seqscale(s[1:],one,Q(1))
 def lap(s,vector):
  ds=Dr(s);terms=[Dr(ds),A.seqmul(inv(len(ds)-1),ds),A.seqscale(s[2:],one,Q(2))]
  if vector:terms.append(A.seqmul(A.seqmul(inv(len(s)-2),inv(len(s)-2)),s))
  return A.seqadd(*terms)
 mul=A.seqmul;sc=A.seqscale
 products={
 'thetaRadial':{'b_dv':mul(bg['b'],inc['v']),'old_beta_dv':mul(old['beta'],inc['v']),'V_dbeta':mul(bg['V'],inc['beta']),'old_v_dbeta':mul(old['v'],inc['beta']),'dbeta_dv':mul(inc['beta'],inc['v'])},
 'thetaAxial':{'G_dv':mul(bg['G'],inc['v']),'old_gamma_dv':mul(old['gamma'],inc['v']),'V_dgamma':mul(bg['V'],inc['gamma']),'old_v_dgamma':mul(old['v'],inc['gamma']),'dgamma_dv':mul(inc['gamma'],inc['v'])},
 'zRadial':{'b_dgamma':mul(bg['b'],inc['gamma']),'old_beta_dgamma':mul(old['beta'],inc['gamma']),'G_dbeta':mul(bg['G'],inc['beta']),'old_gamma_dbeta':mul(old['gamma'],inc['beta']),'dbeta_dgamma':mul(inc['beta'],inc['gamma'])},
 'zAxial':{'2G_dgamma':sc(mul(bg['G'],inc['gamma']),two),'2old_gamma_dgamma':sc(mul(old['gamma'],inc['gamma']),two),'dgamma_squared':mul(inc['gamma'],inc['gamma']),'complete_pressure_difference':p}}
 rows=[]
 groups={}
 for name,vel,rad,ax,e,vec in [('Etheta','v','thetaRadial','thetaAxial',2,True),('Ez','gamma','zRadial','zAxial',1,False)]:
  groups[name]={'slowTime':Dz(inc[vel]),'radial':De(A.seqadd(*products[rad].values()),e),'axial':Dz(A.seqadd(*products[ax].values())),'viscous':sc(lap(inc[vel],vec),one,Q(1))}
 for j in range(m+1):
  r={'order':j,'fields':{},'groups':{},'flux_products':{}}
  for name,ss in groups.items():
   total=A.add(*(s[j] for s in ss.values()));r['fields'][name]=total.json(namespace);r['groups'][name]={k:s[j].json(namespace) for k,s in ss.items()}
  r['flux_products']={k:{t:s[j].json(namespace) for t,s in group.items()} for k,group in products.items()}
  rows.append(r)
 g.validate();new_hash=digest(g.nodes)
 def relabel(x):
  if isinstance(x,dict):
   if x.get('kind')=='source_bound_expression':x['graph']=new_hash
   for v in x.values():relabel(v)
  elif isinstance(x,list):
   for v in x:relabel(v)
 relabel(rows)
 return {'schema':'MathScope.FreshSourceBoundSlowMeanChange/1','stage':stage,'parent_program_hash':namespace,'new_graph_hash':digest(g.nodes),'rows':rows,'scalar_nodes':g.nodes,'call_graph':g.calls,'algebra':'원본 입력에 대한 정확 유리수 지수 및 양의 상계식 계산','required_bound_premises':['0<epsilon<=1; Sstar>=1; 0<delta<=1; 0<=zeta<=1','source radius bound B>=1 and R>=1/B','each source_norm_result supplies the indicated same-source through-order upper bound','same covariance/stress before and after this initial update'], 'flux_terms_retained':sum(map(len,products.values())),'pressure_difference_retained':True,'variable_radial_viscosity_retained':True,'fast_time_cancellation_applied':False,'cutoff_declared_zero':False,'numerical_norm_values_materialized':False,'universal_source_class_proved_by_this_execution':False}

def ibp_demand(target:Q,m:int)->dict:
 if not isinstance(target,Q) or not natural(m):raise SourceError('유리수 목표 지수와 유한 자연수 차수 필요')
 gap=(target-(1-KAPPA))/KAPPA;p=max(1,-(-gap.numerator//gap.denominator))
 return {'target':str(target),'output_derivative_order':m,'ibp_order':p,'achieved_exponent':str(1-KAPPA+p*KAPPA),'A_e_source_derivative_order':m+2*p+3,'fast_NA1_initial_Ez_derivative_order':m+2*p+8,'all_demand_is_finite':True,'derivative_tables_materialized':False,'use':'기존 all-finite positive-IBP 재귀의 정확한 요청 계약; 수치 tail 인증값 아님'}

def stage_contract(j:int,m:int,parameter_hash:str)->dict:
 if not natural(j) or not natural(m):raise SourceError('j,m은 자연수')
 return {'j':j,'m':m,'sigma':str(Q(1,5)+Q(j,10)),'B':str(Q(7,10)+Q(j,10)),'Cstar':str(Q(6,5)+Q(j,10)),'g':{'h_coefficient':str(Q(j,10))},'ell':{'constant':str(Q(m+2)),'h_coefficient':str(Q(3*m+7,2))},'h':{'source_parameter_hash':parameter_hash,'constraint':'0<h<1/100; A=1/2+h','numerical_value':None},'K_m':None,'C_jm':None,'P_jm':None,'common_domain_changed':False,'actual_later_stage_bounds_certified':False,'paper':'pp.113–115, (9.17)–(9.21)'}

def build_report(d:dict)->dict:
 links=verify_source_links(d);family=d['normFamily'];caps=[]
 for c in family['certificates']:
  p=c['program'];g=PositiveDAG(p['scalarProgram']['nodes'],p['callGraph']['calls'],c['graph']['sha256']);A=NormAlgebra(g)
  for row in p['rows']:
   caps.append({'requested_order':p['request']['order'],'derivative_order':row['order'],'namespace':g.namespace,'source_demand':p['sourceDemand'],'targets':{'9.9-tangential-and-pressure':{k:A.read(v).json(g.namespace) for k,v in [('v',row['velocity']['v']),('gamma',row['velocity']['gamma']),('pm',row['fullPressure'])]},'9.9-radial':{'beta':A.read(row['velocity']['beta']).json(g.namespace)},'9.8-defects-C0':{k:A.read(v).json(g.namespace) for k,v in row['freshDefects'].items()}},'constant_closures':{k:g.closure(row['fullPressure']['constant'] if k=='pm' else row['velocity'][k]['constant']) for k in ['v','gamma','beta','pm']}})
 targets=[]
 remaining_notes={
 '9.8-wave-B0':'실제 ±1,±2 grouped harmonic에서 principal cancellation·모든 교차항·Gaussian/cutoff tail을 하나의 상계식으로 합성하는 소비기 필요.',
 '9.8-mean-C0':'새 느린 평균 변화식은 연결됨. 실제 빠른 Fourier 소거 및 positive-IBP cutoff 출력까지 결속하는 마지막 합성 필요.',
 '9.8-defects-C0':'원본 P/J와 비선형 remainder 노름식을 연결함. 실제 다섯 선형 방정식의 소거와 현재 결함=remainder를 노름 적용 단계에서 함께 소비해야 함.',
 '9.9-tangential-and-pressure':'원본 v/gamma/최신 전체 pm과 상계식을 연결함. 참조된 실제 노름 생성기 결과의 유한성/상계 증거를 수치 또는 적용 정리로 실현해야 함.',
 '9.9-radial':'원본 beta와 추가 epsilon, cutoff가 남은 상계식을 연결함. 참조된 실제 노름 생성기 결과의 유한성/상계 증거를 수치 또는 적용 정리로 실현해야 함.'}
 for t in d['typedSpec']['normTargets']:
  if t['id'] not in remaining_notes:continue
  required=Q(t['targetExponent']);available=Q(t['availableSourceCompositionExponent'])
  if available-required!=Q(t['margin']):raise SourceError('기존 명세 지수 여유 불일치')
  roots=t['originalRequirement']['sourceRoots']
  if any(str(i) not in d['actualNodes']['nodes'] for i in roots):raise SourceError('실제 원본 목표 노드 누락')
  targets.append({'id':t['id'],'source_roots':roots,'class':t['class'],'target_exponent':str(required),'available_composition_exponent':str(available),'exact_exponent_margin':str(available-required),'source_link':'CONNECTED','bound_recipe':'LINKED' if t['id'] in ['9.9-tangential-and-pressure','9.9-radial','9.8-defects-C0'] else 'PARTIALLY_COMPOSED','universal_mathematical_status':'OPEN','numerical_constant':None,'remaining':remaining_notes[t['id']]})
 return {'schema':'MathScope.M3.SourceBoundNormBridge/1','links':links,'targets':targets,'finite_bound_records':caps,'ibp_demands':[ibp_demand(Q(149,100),m) for m in range(3)],'stage_contracts':[stage_contract(j,m,links['source_parameter_hash']) for j in range(5) for m in range(3)],'inherited':{'original_1260':'COMPLETE_IN_DECLARED_CURRENT_SOURCE_SCOPE','Guard':0,'Jet':0,'PDE':0,'exact_difference_interval':['0','0'],'M3':'56/64','N6-02':'PARTIAL; correction substeps deferred','old_proofs_rerun':False},'new_original_norm_ids_fully_closed':[],'remote_writes':0,'note':'원본 ID 결속·정확 상계 대수 실행과 전칭 노름 인증은 별도. 미실현 상수에 임의 숫자를 넣지 않음.'}

def main():
 d=load_inputs();report=build_report(d);p=d['normFamily']['certificates'][1]
 for stage in ['temporal','five']:
  out=compose_slow_change(p['program'],p['graph']['sha256'],stage,1)
  dump(ROOT/'evidence'/f'{stage}_slow_change.json',out)
  report[stage+'_slow_change']={k:v for k,v in out.items() if k not in ['scalar_nodes','call_graph']}
 dump(ROOT/'evidence'/'SOURCE_BOUND_NORM_REPORT.json',report)
 print(json.dumps({'source_links':len(report['targets']),'source_nodes':report['links']['stored_source_nodes_matched'],'bound_records':len(report['finite_bound_records']),'slow_change_orders':[0,1],'slow_change_flux_terms_each':19,'M3':'56/64','new_full_norm_claims':0},ensure_ascii=False))
if __name__=='__main__':main()

import unittest
from fractions import Fraction as Q
from common_tail import Envelope
from source_bound_norms import load_inputs,SourceError
from source_tail_adapter import inspect_connection,schedule_from_realized_increments
class TailSourceAdapterTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.result=inspect_connection(load_inputs())
 def test_actual_norm_constants_not_node_numbers(self):
  self.assertTrue(all(r['numeric_value'] is None and r['unmaterialized_source_leaf_count']>0 for r in self.result['records']))
 def test_initial_U0_is_not_increment_Zj(self):
  self.assertTrue(self.result['initial_state_as_increment_rejected'])
 def test_role_rejection_occurs_before_selector(self):
  with self.assertRaises(SourceError):schedule_from_realized_increments(role='finite_initial_state_U0',j=1,envelopes=[],previous_k=None,q0=Q(1,2))
 def test_valid_mathematical_fixture_still_reaches_common_module(self):
  # 연결 배선만 검사하는 별도 유리수 fixture. MathScope 실제 장의 노름이 아니다.
  out=schedule_from_realized_increments(role='cutoff_product_increment_envelope',j=1,envelopes=[Envelope(Q(1),0,Q(1))]*2,previous_k=None,q0=Q(1,2))
  self.assertEqual(out['log2_a'],2)
 def test_no_numeric_schedule_or_extra_deferred_gate(self):
  self.assertFalse(self.result['actual_numeric_cutoff_schedule_generated']);self.assertFalse(self.result['N6-02_deferred_substeps_added_as_new_prerequisite']);self.assertTrue(self.result['reference_theorem_application_does_not_require_decimal_materialization'])

 def test_raw_Zj_bound_is_not_cutoff_product_hatC(self):
  with self.assertRaises(SourceError):schedule_from_realized_increments(role="physical_increment_Z_j",j=1,envelopes=[Envelope(Q(1),0,Q(1))]*2,previous_k=None,q0=Q(1,2))

"""새 파동 연결만 실행한다. 이전 원본 증명/원격 변경 없음."""
from pathlib import Path
import subprocess,sys,json,hashlib,time,platform,datetime
ROOT=Path(__file__).resolve().parents[1]
PRODUCTS=['evidence/'+s+'.json' for s in ['SOURCE_BINDINGS','WAVE_NORM_PROGRAM','CURRENT_WAVE_APPLICATION','GAUSSIAN_TAIL_CONNECTION','HARMONIC_INVENTORY','GENERIC_KERNEL_FIXTURE','INDEPENDENT_ALGEBRA','TEST_RESULTS']]+['index.html']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 commands=[[sys.executable,'code/wave_bridge.py'],['node','code/emit_kernel_fixture.mjs'],[sys.executable,'code/symbolic_check.py'],[sys.executable,'code/test_wave_bridge.py'],[sys.executable,'code/build_ui.py']];runs=[]
 for j,cmd in enumerate(commands):
  t=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45)
  log=f'evidence/RUN_{j+1}.log';(ROOT/log).write_text(p.stdout)
  runs.append({'command':cmd,'exit_code':p.returncode,'seconds':round(time.monotonic()-t,6),'log':log,'log_sha256':sha(ROOT/log)})
  if p.returncode:break
 import sympy
 out={'schema':'MathScope.WaveContinuationExecution/1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':runs,'successful':len(runs)==len(commands) and all(r['exit_code']==0 for r in runs),
 'environment':{'python':sys.version,'platform':platform.platform(),'sympy':sympy.__version__,'node':subprocess.check_output(['node','--version'],text=True).strip()},
 'products':[{'path':x,'sha256':sha(ROOT/x),'bytes':(ROOT/x).stat().st_size} for x in PRODUCTS if (ROOT/x).is_file()],
 'code_hashes':{p.name:sha(p) for p in sorted((ROOT/'code').glob('*')) if p.is_file()},'input_lock_sha256':sha(ROOT/'INPUT_LOCK.json'),'old_1260_executed':False,'correction_substeps_executed':False,'remote_writes':0,'original_M3':'56/64'}
 (ROOT/'evidence/EXECUTION_RECEIPT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'successful':out['successful'],'commands':len(runs),'products':len(out['products'])}));return 0 if out['successful'] else 1
if __name__=='__main__':sys.exit(main())

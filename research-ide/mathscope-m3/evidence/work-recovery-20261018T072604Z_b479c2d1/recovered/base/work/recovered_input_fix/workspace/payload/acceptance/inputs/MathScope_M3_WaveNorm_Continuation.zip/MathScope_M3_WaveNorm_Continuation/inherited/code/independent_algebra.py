"""원래 JS 생성식과 독립 SymPy 미분/전개로 확인하는 유한 다항식 항등식."""
from __future__ import annotations
from pathlib import Path
import json,hashlib
import sympy as s
ROOT=Path(__file__).resolve().parents[1]

def decode(packet:dict):
 vals=[]
 for n in packet['nodes']:
  op,a=n['op'],n['args']
  if op=='rational':v=s.Rational(*map(int,a))
  elif op=='symbol':v=s.sqrt(2) if a[0]=='sqrt2' else s.Symbol(a[0],positive=True) if a[0]=='R' else s.Symbol(a[0],real=True)
  elif op=='field':v=s.Function(a[0])(*(vals[i] for i in a[1]))
  elif op=='add':v=s.Add(*(vals[i] for i in a))
  elif op=='multiply':v=s.Mul(*(vals[i] for i in a))
  elif op=='divide':v=vals[a[0]]/vals[a[1]]
  elif op=='power':v=vals[a[0]]**a[1]
  elif op=='derivative':v=s.diff(vals[a[0]],vals[a[1]])
  else:raise ValueError(op)
  vals.append(v)
 return vals

def verify(packet:dict)->dict:
 v=decode(packet);old,now,rem=packet['old'],packet['now'],packet['remainder'];R=v[packet['geometry']['R']]
 equations={
  '8.26_gr_difference':v[now['gr']]-v[old['gr']]-v[rem['linear']['PIntegrand']]-v[rem['Rg']],
  '8.27_theta_flux_difference':v[now['fluxTheta']]-v[old['fluxTheta']]-v[rem['linear']['JthetaIntegrand']]-v[rem['JthetaIntegrand']],
  '8.27_z_velocity_difference':v[now['fluxZ']]-v[old['fluxZ']]-2*R*v[packet['background']['G']]*v[packet['increment']['gamma']]-v[rem['JzVelocityIntegrand']],
  '8.27_z_linear_pressure_half':v[rem['linear']['JzIntegrand']]-(2*R*v[packet['background']['G']]*v[packet['increment']['gamma']]-R**2*v[rem['linear']['PIntegrand']]/2),
 }
 results=[]
 for key,expr in equations.items():
  reduced=s.expand(expr)
  results.append({'id':key,'exact_zero':reduced==0,'expanded_remainder':str(reduced)})
 eps=v[packet['geometry']['epsilon']];T=v[packet['geometry']['T']];db=v[packet['increment']['beta']]
 slow=s.expand(v[rem['terms']['time']]-eps*s.diff(db,T))
 results.append({'id':'five_slow_time_has_no_fast_torus_term','exact_zero':slow==0,'expanded_remainder':str(slow)})
 # 임의의 선형 적분에 따른 공통 항등식. 수치 표본 검사가 아니다.
 P,Lp,Qg,Jt,Lt,Qt,Jz,Lz,Qz,QR=s.symbols('P LP Qg Jtheta LTheta Qtheta Jz Lz Qz QR2g')
 new={'P':P+Lp+Qg,'Jtheta':Jt+Lt+Qt,'Jz':Jz+Lz+Qz-QR/2}
 expected={'P':Qg,'Jtheta':Qt,'Jz':Qz-QR/2}
 for name,x in new.items():
  zero=s.expand(x.subs({Lp:-P,Lt:-Jt,Lz:-Jz})-expected[name])
  results.append({'id':f'five_rows_then_integral_{name}','exact_zero':zero==0,'expanded_remainder':str(zero)})
 # 독립 Leibniz 전개에서 가변 a의 미분이 남는지 확인한다.
 f=v[packet['previous']['beta']];a=v[packet['geometry']['radialFast']];Y=[v[i] for i in packet['geometry']['Y']]
 def L(x):return s.diff(x,Y[0])+(1-s.sqrt(2))*s.diff(x,Y[1])
 def Dr(x):return s.diff(x,R)+a*L(x)
 expanded=s.diff(f,R,2)+s.diff(a,R)*L(f)+2*a*L(s.diff(f,R))+a*a*L(L(f))
 zero=s.expand(Dr(Dr(f))-expanded)
 results.append({'id':'variable_radial_second_derivative_retained','exact_zero':zero==0,'expanded_remainder':str(zero)})
 if not all(r['exact_zero'] for r in results):raise ValueError('원래 식과 독립 대수 경로 불일치: '+str(results))
 return {'schema':'MathScope.IndependentDefectAlgebra/1','checks':results,'pass':True,'arithmetic':'exact symbolic function differentiation and polynomial expansion; no sampled fields','symbolic_variables':'임의 매끄러운 이전 장; 고정 b,V,G,W; 보조 토러스와 무관한 five 증분','source_kernel_sha256':hashlib.sha256((ROOT/'source_additions/source-full-mean-equations.mjs').read_bytes()).hexdigest(),'premises_not_proved_by_algebra':['동일 원본에서 8.25의 다섯 행 성립 (승계)','적분/미분의 교환과 끝점 정칙성 (승계)','source_norm_result의 원본 노름 상계 (승계)'],'old_1260_rerun':False,'new_N6_02_substeps':False}

def main():
 p=json.loads((ROOT/'evidence/ORIGINAL_POLYNOMIAL.json').read_text());out=verify(p)
 (ROOT/'evidence/INDEPENDENT_ALGEBRA.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'exact_identities':len(out['checks']),'pass':out['pass']},ensure_ascii=False))
if __name__=='__main__':main()

# MathScope M3 — 현재 세 결함의 정량 노름 연결

**M3 56/64 유지 · N6-01 전체 OPEN · N6-02 PARTIAL/보정 substep 보류 · 원격 변경 없음**

이번 결과는 현재 P3615055/Jθ3615101/Jz3615147에 보존된 nonlinear remainder와 같은 소스 정량 노름을 연결한 델타다. 기존 mean·직접 A₁ cutoff 결과 및 앞선 소스는 `inherited/`에 바이트 그대로 보존한다. 초기1260의 완료 증명은 재실행하지 않는다.

## 먼저 볼 파일

- `reports/RESULTS_KO.md`: 실행 결과 및 원래 기준별 판정.
- `reports/ALL_ORDER_PROOF_KO.md`: 항등식, 모든 고정 유한 미분 차수에서의 지수 증명 및 정확한 적용 전제.
- `index.html`: 실제 계산된 상계식 9행에 연결된 후보 화면. 압축 해제 후 연다. 운영 사이트에 게시한 파일이 아니다.
- `reports/HANDOFF_KO.md`: 다음 재개점.

## 최소 재현

검사 환경: Python3.13.5, Node22.16.0, SymPy1.14.0. 브라우저 검사는 선택 사항이며 Playwright1.57.0 / Chromium144.0.7559.96 / Linux `/usr/bin/chromium`에서 검사했다. 다른 환경에서의 바이트 재현은 별도로 확인해야 한다.

```sh
# SymPy가 없는 환경에서만 필요한 의존성을 설치한다.
python -m pip install -r requirements.txt

# 이 델타의 새 생성기·독립 대수·노름 연결·42개 테스트·화면 생성
python code/run_all.py

# 결과를 지운 새 폴더에서 재현하고 8개 파일 비교
python code/replay.py

# 위 Linux 브라우저 환경이 준비된 경우만
python code/browser_check.py
```

계산 프로그램은 네트워크 다운로드·GitHub 쓰기·사이트 게시를 하지 않는다. `run_all.py`는 새 델타 결과를 재생성하며 이전 기록 `inherited/`는 수정하지 않는다. Python이 만드는 캐시 파일은 패키지 manifest 대상에서 제외한다.

## 결과 의미

같은 원본 입력 노름을 전제로 **(P,Jθ,Jz)∈S_(99999/50000)⊂S_(6/5)**를 얻었다. 0·1·2차 상계식은 실행 산출물이고, 임의 유한 차수의 적용은 원문 정리·입력 노름과 유한 곱법칙에 대한 별도 논증이다. 수치 표본, 상수의 숫자값, 독립 Lean 증명으로 표시하지 않는다. 기존 [0,0]은 초기 두 잔차 표현의 비교 오차이며, 현재 세 결함이 0이라는 뜻이 아니다.

전체 입력·코드·증거 해시는 `HASH_MANIFEST.json`, 실제 명령과 종료 코드는 `evidence/EXECUTION_RECEIPT.json`을 본다. `SOURCE_PAPER_MAP.json`은 첨부 판본의 페이지와 식을 가리키며 원 PDF의 공식성·심사 상태를 인증하지 않는다.

/** 원래 8.3/8.26 생성기를 새 기호 대수 입력에 적용. 실제 장의 재생성 아님. */
import {exactFullAuxiliaryMeanPDE,exactFullMeanMomentRemainders} from '../source_additions/source-full-mean-equations.mjs';
import fs from 'node:fs';
class Graph {
 constructor(){this.nodes=[];this.memo=new Map();this.zero=this.q(0);this.one=this.q(1);}
 emit(op,args){const k=JSON.stringify([op,args]);if(this.memo.has(k))return this.memo.get(k);const n=this.nodes.length;this.nodes.push({op,args});this.memo.set(k,n);return n;}
 q(n,d=1){return this.emit('rational',[String(n),String(d)]);}
 symbol(n){return this.emit('symbol',[n]);}
 field(n,coords){return this.emit('field',[n,coords]);}
 add(...xs){return this.emit('add',xs);}
 mul(...xs){return this.emit('multiply',xs);}
 neg(x){return this.mul(this.q(-1),x);}
 sub(x,y){return this.add(x,this.neg(y));}
 div(x,y){return this.emit('divide',[x,y]);}
 pow(x,n){return this.emit('power',[x,n]);}
 derivative(x,y){return this.emit('derivative',[x,y]);}
}
const g=new Graph(),R=g.symbol('R'),Z=g.symbol('Z'),T=g.symbol('T'),Y=[g.symbol('Y0'),g.symbol('Y1')],
 epsilon=g.symbol('epsilon'),ci=g.symbol('ci'),a=g.field('a',[R]),rt=g.symbol('sqrt2'),
 geometry={R,Z,T,Y,epsilon,ci,radialFast:a,vr:[g.one,g.sub(g.one,rt)],vt:[g.sub(rt,g.one),g.one]},
 slow=[R,Z,T],all=[...slow,...Y],
 background={b:g.field('b',slow),V:g.field('V',slow),G:g.field('G',slow)},
 previous=Object.fromEntries(['beta','v','gamma'].map(n=>[n,g.field(n,all)])),
 increment=Object.fromEntries(['beta','v','gamma'].map(n=>[n,g.field('d'+n,slow)])),
 updated=Object.fromEntries(['beta','v','gamma'].map(n=>[n,g.add(previous[n],increment[n])])),
 covariance=Object.fromEntries(['rr','rtheta','rz','thetatheta','thetaz','zz'].map(n=>[n,g.field('W_'+n,all)])),
 stress=[g.field('Sigma_theta',all),g.field('Sigma_z',all)],
 old=exactFullAuxiliaryMeanPDE(g,{geometry,background,velocity:previous,covariance,stress}),
 now=exactFullAuxiliaryMeanPDE(g,{geometry,background,velocity:updated,covariance,stress}),
 remainder=exactFullMeanMomentRemainders(g,{geometry,background,previous,increment});
const out={schema:'MathScope.OriginalDefectPolynomialInstantiation/1',nodes:g.nodes,geometry,background,previous,increment,updated,covariance,old,now,remainder,scope:'고정 원본 JS 생성기의 기호 인스턴스. 원본1260 재실행/수치 PDE 실행 아님.'};
fs.writeFileSync(new URL('../evidence/ORIGINAL_POLYNOMIAL.json',import.meta.url),JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({symbolicNodes:g.nodes.length,sourceKernelUsed:'source-full-mean-equations.mjs'}));
